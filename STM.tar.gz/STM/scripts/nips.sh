#!/bin/bash

#  
#
#  Created by Du Lan on 28/02/12.
#  Copyright (c) 2012 __MyCompanyName__. All rights reserved.

TRSETTING=tr_setting.txt

DATA=nips
DIR=results/$DATA/
mkdir -p $DIR

echo "Run STM on ${DATA} with both b and alpha being optimised!"

K=50
A=0.20
ALPHA=0.50
GAMMASUM=200.0
TR=data/${DATA}/training.dat
V=data/${DATA}/vocabulary.dat
B="1 5 10 50 100 200"
CMD=""

for b in ${B}; do
     echo "-->b = ${b}"
     CMD="src/stm -O 2 -v ${V} -d ${TR} -o ${DIR} -s ${TRSETTING} -k ${K} -a ${A} -b ${b} -A ${ALPHA} -G ${GAMMASUM}"
     ${CMD} > ${DIR}/k-${K}-b-${b}.log;
done
