/*
 * stm.h
 *
 *  Created on: Jan 14, 2011
 *      Author: dulan
 */

#ifndef STM_H_
#define STM_H_

#include <time.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include "model.h"
#include "corpus.h"
#include "params.h"
#include "util.h"

void inference(Corpus* c, char* mroot, int heldout, int doOpt);
void estimate(Corpus* c, vocabulary* v, char* root, int doOpt);

void stm_gibbs_sampling(Model*, Cts*, int***, Corpus*, int inf);
void gibbs_heldout(Model* t_model, Cts* n_cts, int*** n_ass, Corpus* c1);
double gibbs_likelihood_stm(int i, int samples, Model* model, doc* d);

#endif /* STM_H_ */
