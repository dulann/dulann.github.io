/*
 * estimate.c
 *
 * Training and testing routines for the Segmented Topic Model (STM)
 *
 * Copyright (C) 2012 Lan Du
 * All rights reserved.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * Author: Lan Du (Lan.Du@mq.edu.au)
 *
 */
#include <string.h>
#include <gsl/gsl_sf.h>
#include <gsl/gsl_math.h>

#include "util.h"
#include "gibbs.h"
#include "stm.h"

extern stm_params PARAMS;
struct Args{
     int doInf;
     int doOpt;
     int run_num;
     int heldout;
     
     double a;
     double b;
     double alpha;
     double gamma;
     double k;
     
     char* setting;
     char* data;
     char* v_data;
     char* mod_file;
     char* o_file;
}Args;
/*
 * Command line processing
 */
void initialize_args()
{
     Args.doInf = 0;
     Args.doOpt = 0;
     Args.run_num = 0;
     Args.heldout = 1;
     
     Args.k = 0;
     Args.a = GSL_NEGINF;
     Args.b = GSL_NEGINF;
     Args.alpha = GSL_NEGINF;
     Args.gamma = GSL_NEGINF;
     
     Args.setting = NULL;
     Args.data = NULL;
     Args.v_data = NULL;
     Args.mod_file = NULL;
     Args.o_file = NULL;
}
/*
 * Reset params with the command line input
 */
void reset_params()
{
     if(Args.k != 0){
          if(Args.k > 0){
               PARAMS.k = Args.k;
          }else{
               fprintf(stderr, "ERROR: No. of topics should be greater than 0!!!\n");
               exit(1);
          }
     }
     
     if(Args.a != GSL_NEGINF){
          if(Args.a >= 0 && Args.a < 1){
               PARAMS.a = Args.a;
          }else{
               fprintf(stderr, "ERROR: Args.a should be >= 0 & < 1 !!!\n");
               exit(1);
          }
     }
     
     if(Args.b != GSL_NEGINF){
          if(Args.a != GSL_NEGINF){
               if(Args.b > -Args.a){
                    PARAMS.b = Args.b;
               }else{
                    fprintf(stderr, "Error: Args.b should be > -Args.a!!!\n");
                    exit(1);
               }
          }else{
               fprintf(stderr, " Error: please enter Args.a!!!\n");
               exit(1);
          }
     }
     
     if(Args.alpha != GSL_NEGINF){
          if(Args.alpha > 0){
               PARAMS.alpha = Args.alpha;
          }else{
               fprintf(stderr, "ERROR: Args.alpha should be > 0!!!\n");
               exit(1);
          }
     }
     
     if(Args.gamma != GSL_NEGINF){
          if (Args.gamma > 0){
               PARAMS.gamma = Args.gamma;
          }else{
               fprintf(stderr, "ERROR: Args.gamma_sum should be > 0!!!\n");
               exit(1);
          }
     }
}
/*
 *
 */
static const char* optString = "IO:s:n:v:d:o:m:a:b:A:G:k:h?";

int main(int argc, char* argv[])
{
     int opt = 0;
     initialize_args();
     opt = getopt(argc, argv, optString);
     while(opt != -1)
     {
          switch(opt){
               case 'I': // command "-I": to do inference
                    Args.doInf = 1;
                    break;
               case 'O':
                    Args.doOpt = atoi(optarg);
                    break;
               case 'n': // command "-n": the n-th run of the experiment
                    Args.run_num = atoi(optarg);
                    break;
                    ////////////////////////////////////////////////
               case 'd': // command "-d": for training/testing data
                    Args.data = optarg;
                    break;
               case 's': // command "-s": for training/testing settings
                    Args.setting = optarg;
                    break;
               case 'v': // for vocabulary file
                    Args.v_data = optarg;
                    break;
                    ////////////////////////////////////////////////
               case 'k': // command "-k": number of topics
                    Args.k = atoi(optarg);
                    break;
               case 'a': // command "-a": discount paramter for the PDP
                    Args.a = atof(optarg);
                    break;
               case 'b': // command "-b": strength paramter for the PDP
                    Args.b = atof(optarg);
                    break;
               case 'A': // command "-A": alpha value
                    Args.alpha = atof(optarg);
                    break;
               case 'G': // command "-G": the gamma value
                    Args.gamma = atof(optarg);
                    break;
                    ///////////////////////////////////////////////
               case 'o': // command "-o": output file directory
                    Args.o_file = optarg;
                    break;
               case 'm': // command "-m": trained model directory
                    Args.mod_file = optarg;
                    break;
               case 'h': // for command help
                    printf("Command line arguments:\n");
                    printf("\t \'-I\'\t do inference, otherwise do not use it.\n");
                    printf("\t \'-O\' [arg]\t Optimise hyperparameters\n");
                    printf("\t\t 1 \t only optimise the concentration parameter \'b\'\n");
                    printf("\t \t 2 \t only optimise the Dirichlet parameter \'alpha' \n");
                    printf("\t \t 3 \t optimise both parameters\n");
                    printf("\t \'-d\' [arg] input the traning or testing dataset\n");
                    printf("\t \'-s\' [arg] input the training or testing setting\n");
                    printf("\t \'-v\' [arg] input the vocabulary file\n");
                    printf("\t \'-k\' [arg] the number of topics\n");
                    printf("\t \'-a\' [arg] the discount parameter\n");
                    printf("\t \'-b\' [arg] the concentration parameter\n");
                    printf("\t \'-A\' [arg] the Dirichlet parameter \'alpha\'\n");
                    printf("\t \'-G\' [arg] the Dirichlet parameter \'gamma\'\n");
                    printf("\t \'-o\' [arg] the output directory\n");
                    printf("\t \'-m\' [arg] the trained model directory\n");
                    printf("\t \'-n\' [arg] the n-th number of run\n");
                    break;
               default:
                    break;
          }
          opt = getopt(argc, argv, optString);
     }
     
     vocabulary* v;
     Corpus* c;
     char str[BUFSIZ];
     char root[BUFSIZ];
     
     if(!Args.doInf){
          read_params(Args.setting);
          reset_params();
          sprintf(root, "%s/%d-%.2lf-%.2lf-%.2lf-r%d", Args.o_file, PARAMS.k, PARAMS.a,
              PARAMS.b, PARAMS.alpha, Args.run_num);
          mkdir(root, S_IRUSR | S_IWUSR | S_IXUSR);
          sprintf(str, "%s/README", root);
          write_params(str);
          print_params();
          printf("Reading vocabulary ...\n");
          v = read_vocabulary(Args.v_data);
          printf("Reading training corpus ...\n");
          c = read_data(Args.data);
          printf("Begin Training the model ...\n");
          estimate(c, v, root, Args.doOpt);
          printf("End Training model ...\n");
     }else{
          if(Args.mod_file == NULL){
               fprintf(stderr, "Error: enter trained model file by -m !!!\n");
               exit(1);
          }
          printf("Begin Testing ...\n");
          read_params(Args.setting);
          printf("Reading Testing corpus ... \n");
          c = read_data(Args.data);
          printf("mode file : %s\n", Args.mod_file);
          inference(c, Args.mod_file, Args.heldout, Args.doOpt);
          printf("End Testing ...\n");
     }
     
     return (0);
}
