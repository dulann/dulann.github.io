/*
 * optimization.h
 *
 * Copyright (C) 2010 Lan Du
 * All rights reserved.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * Author: Lan Du (Lan.Du@nicta.com.au)
 *
 */

#ifndef OPTIMIZATION_H_
#define OPTIMIZATION_H_

#include <stdlib.h>
#include <stdio.h>

#include "model.h"
#include "util.h"

#define NEWTON_THRESH 1e-5

/*
 * optimising alpha for STM
 */
void alpha_opt(Cts* cts, Model* model, Corpus* c);
void alpha_opt_newton(Cts* cts, Model* model, Corpus* c);
/*
 * Three ways to optimise b for STM, the first two methods only optimise b for the whole corpus,
 * the last method optimises b for each document.
 *
 */
double sample_posteriorPDP_b(Cts* cts, Corpus* c, Model * model);
void ars_b(int rep, Cts* cts, Model* model, Corpus* c);
void saveb(Cts* cts, char* file, int ite);
#endif /* OPTIMIZATION_H_ */
