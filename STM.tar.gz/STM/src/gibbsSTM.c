/*
 * gibbsSTM.c
 *
 * Gibbs sampling routines for segmented topic model
 *
 * Copyright (C) 2012 Lan Du
 * All rights reserved.
 *
 * Author: Lan Du (Lan.Du@mq.edu.au)
 *
 */

#include <math.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_sf.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>

#include "stm.h"

#define WINDOW 5

static gsl_vector* tProbs;

static double topic_prob(int i, int j, int k, int w,
		Cts* cts, Model* model, double b, int inf)
{
	double prob;

	if(cts->t[i][j][k] == 0){
		prob = (b + model->a * cts->TJ[i][j])
				  *(cts->TK[i][k] + vget(model->alpha, k))
				  /(cts->sumT[i] + model->alphaSum);
//		assert(prob > 0);
		prob = gsl_sf_log(prob);
	}else{
		prob = stirling((cts->n[i][j][k]+1), cts->t[i][j][k], model->a)
						- stirling(cts->n[i][j][k], cts->t[i][j][k], model->a);
	}

	if(inf){
		prob += gsl_sf_log(mget(model->phi, k, w));
	}else{
		prob += gsl_sf_log((vget(model->gamma, w) + cts->M[k][w])
				/(model->gammaSum + cts->m[k]));
	}

	if(!gsl_finite(prob)){
		fprintf(stderr, "i = %d, j = %d, k = %d, Oops: word prob "
				"goes to infinte or NaN!!!\n", i, j, k);
		exit(1);
	}
	return prob;
}

static int sample_topic(int i, int j, int l, int w, int*** ass,
		Cts* cts, Model* model, gsl_vector* vector, double b, int inf)
{
	double log_prob;
	int k;

	int oldK = ass[i][j][l];
	int n = cts->n[i][j][oldK]; //assert(n>=0);
	int t = cts->t[i][j][oldK]; //assert(t>=0);
	if(n == t && n > 0){
		cts->t[i][j][oldK]--;
		cts->TJ[i][j]--;
		cts->TK[i][oldK]--;
		cts->sumT[i]--;
	}
	cts->n[i][j][oldK]--;
	cts->M[oldK][w]--;
	cts->m[oldK]--;

	for(k = 0; k < model->k; k++)
	{
		log_prob = topic_prob(i, j, k, w, cts, model, b, inf);
		vset(vector, k, log_prob);
	}
	double max = gsl_vector_max(vector);
	double sum_v = 0;
	for(k = 0; k < model->k; k++)
	{
		double tmp = vget(vector, k) - max;
		if(tmp > -20)
			sum_v += gsl_sf_exp(tmp);
	}
	for(k = 0; k < model->k; k++)
	{
		double tmp = vget(vector, k) - max;
		if(tmp > -20){
			vset(vector, k, (gsl_sf_exp(tmp)/sum_v));
		}else{
			vset(vector, k, 0);
		}
	}
	int newK = next_discrete_normalised(vector);

	ass[i][j][l] = newK;
	cts->M[newK][w]++;
	cts->m[newK]++;
	cts->n[i][j][newK]++;
	if(cts->n[i][j][newK] == 1){
		cts->t[i][j][newK]++;
		cts->TJ[i][j]++;
		cts->TK[i][newK]++;
		cts->sumT[i]++;
	}
	return newK;
}

static double log_t_prob(int k, int nt, int ot, int n, int TJ,
		int TK, int sumT, Model* model, double b)
{
	int change = nt-ot;
	double log_prob = stirling(n, nt, model->a) +
			log_poch_sym(b, model->a, (TJ+change));
	log_prob += gsl_sf_lngamma((vget(model->alpha, k)+TK+change));
	log_prob -= gsl_sf_lngamma(model->alphaSum+sumT+change);

	if(!gsl_finite(log_prob)){
		fprintf(stderr, "Oops: k = %d, t = %d; table prob goes to "
				"infinite or NaN!!!\n", k, nt);
		exit(1);
	}
	return log_prob;
}

static void sample_table(int i, int j, int k, Cts* cts, Model* model, double b)
{
	int m;
	double logProb;

	int upBound = cts->t[i][j][k]+WINDOW;
	int lowBound = cts->t[i][j][k]-WINDOW;
	if(upBound > cts->n[i][j][k])
		upBound = cts->n[i][j][k];
	if(lowBound < 1)
		lowBound = 1;
	double windowSize = upBound-lowBound+1;

	tProbs = gsl_vector_alloc(windowSize);
	for(m = 0; m < windowSize; m++)
	{
		logProb = log_t_prob(k, (lowBound+m),
				cts->t[i][j][k], cts->n[i][j][k], cts->TJ[i][j], cts->TK[i][k],
				cts->sumT[i], model, b);
		vset(tProbs, m, logProb);
	}
	double sum_v = 0;
	double max = gsl_vector_max(tProbs);
	for(m = 0; m < windowSize; m++)
	{
		double tmp = vget(tProbs, m) - max;
		if(tmp > -20)
			sum_v += gsl_sf_exp(tmp);
	}
	for(m = 0; m < windowSize; m++)
	{
		double tmp = vget(tProbs, m) - max;
		if(tmp > -20)
			vset(tProbs, m, (gsl_sf_exp(tmp)/sum_v));
		else
			vset(tProbs, m, 0);
	}
	m = next_discrete_normalised(tProbs);
	int nt = lowBound+m;

    int change = nt - cts->t[i][j][k];
	cts->sumT[i] += change;
	cts->TK[i][k] += change;
	cts->TJ[i][j] += change;
	cts->t[i][j][k] = nt;

	gsl_vector_free(tProbs);
}

/*
 * gibbs sampling function for segmented topic model estimation
 */
void stm_gibbs_sampling(Model* model, Cts* cts, int*** ass, Corpus* c, int inf)
{
	int i, j, l;
	int newK;
	gsl_vector* vector = gsl_vector_calloc(model->k);

	for(i = 0; i < c->ndocs; i++)
	{
		double b = vget(cts->B, i);
		for(j = 0; j < c->docs[i].nparas; j++)
		{
			for(l = 0; l < c->docs[i].paras[j].total; l++)
			{
				newK = sample_topic(i, j, l, c->docs[i].paras[j].words[l], ass,
						cts, model, vector, b, inf);
				if(cts->n[i][j][newK] > 1){
					sample_table(i, j, newK, cts, model, b);
				}
			}
		}
	}
	gsl_vector_free(vector);
}
/************************************************************************************************************************************/
/***********************************************left2right inference*****************************************************************/
/************************************************************************************************************************************/
/*
 *     procedures for left-to-right likelihood estimates
 *     Author: Wray Buntine (Wray.Buntine@nicta.com.au)
 */
static double sum_topic_ll(int *N, int *T, int Ntot, int *Ttot, int Tdoc, int Ttottot,
			int word, Model *model) {
	int k;
	double tot = 0;
	double ktot = 0;
	for (k = 0; k < model->k; k++)
	  {
	    double tmp;
	    tmp = exp(stirling(N[k]+1, T[k]+1, model->a) - stirling(N[k], T[k], model->a))*
	    (model->b + model->a*Tdoc) * (Ttot[k]+vget(model->alpha, k))
	      / (Ttottot+model->alphaSum);
	    if (T[k] > 0)
	      tmp += exp(stirling(N[k]+1, T[k], model->a) - stirling(N[k], T[k], model->a));
	  tot += mget(model->phi, k, word) * tmp / (Ntot + model->b) ;
	  ktot += tmp / (Ntot + model->b);
	  // fprintf(stderr," %lg += %lg*%lg/%lg ", tot,
	  //  mget(model->phi, k, word), tmp , (Ntot + model->b) );
	  if ( !gsl_finite(tot) ) {
	    fprintf(stderr, "Infinite tot in sum_topic_ll for k=%d\n", k);
	    exit(1);
	  }
	  }
	if ( tot<= 0 ) {
	  fprintf(stderr, "non-pos tot in sum_topic_ll for k=%d\n", k);
	  exit(1);
	}
	// fprintf(stderr," \n");
	return tot/ktot;
}

static int sample_topic_ll(int *N, int *T, int *Ttot, int Tdoc, int Ttottot,
			   int word, Model *model, gsl_vector* fact) {
	int k;
	double tot = 0;
	for (k = 0; k < model->k; k++)
	{
		double tmp;
		if ( N[k]>0 ) {
			tmp = exp(stirling(N[k]+1, T[k], model->a) - stirling(N[k], T[k], model->a));
		} else {
			tmp = (model->b + model->a*Tdoc) * (Ttot[k]+vget(model->alpha, k))
						/ (Ttottot+model->alphaSum);
		}
		vset(fact, k , mget(model->phi, k, word) * tmp);
		tot += vget(fact, k);
		if ( !gsl_finite(tot) ) {
		  fprintf(stderr, "Infinite tot in sample_topic_ll for k=%d\n", k);
		  exit(1);
		}
	}
	return next_discrete_unnormalised(fact, tot);
}

/*
 *  highly compressed form of a single table sampler, changing
 *  just by 1 at most
 */
static int sample_table_ll(int k, int n, int old_t, int Ttot, int Tdoc, int Ttottot, Model *model)
{
	double p_m = 0, p_p = 0;
	double tmp, sum = 1;

	tmp = stirling(n, old_t, model->a);
	if ( old_t<n ) {
		p_p = exp(stirling(n, old_t+1, model->a) - tmp);
		p_p *= model->b + model->a*Tdoc;
		p_p *= vget(model->alpha, k) + Ttot;
		p_p /= model->alphaSum + Ttottot;
		sum += p_p;
	}
	if ( old_t>0 ) {
		p_m = exp(stirling(n, old_t-1, model->a) - tmp);
		p_m /= model->b + model->a*(Tdoc-1);
		p_m /= vget(model->alpha, k) + Ttot-1;
		p_m *= model->alphaSum + Ttottot-1;
		sum += p_m;
	}
	if ( !gsl_finite(sum) ) {
	  fprintf(stderr, "Infinite sum in sample_table_ll for k=%d\n", k);
	  exit(1);
	}

	sum *= next_uniform();
	if ( old_t<n ) {
		sum -= p_p;
		if ( sum <= 0 )
			return 1;
	}
	if ( old_t>0 ) {
		sum -= p_m;
		if ( sum<=0 )
			return -1;
	}
	return 0;
}


/*
 *
 */
double gibbs_likelihood_stm(int i, int samples, Model* model, doc* d)
{
	int jp;
	int k, lp, llp;
	double totalsum = 0;
	int *N = NULL;
	int *N_mem = malloc(model->k*sizeof(int)*d->nparas);
	int *Ntot = malloc(model->k*sizeof(*Ntot));
	int *T = NULL;
	int *T_mem = malloc(model->k*sizeof(*T)*d->nparas);
	int *Ttot = malloc(model->k*sizeof(*Ttot));
	int Ttottot = 0;
	int *Tdoc = malloc(d->nparas*sizeof(*Tdoc));
	int *kvec;
	gsl_vector* fact = gsl_vector_calloc(model->k);

	for (k = 0; k < model->k*d->nparas; k++)
	{
		N_mem[k] = 0;
		T_mem[k] = 0;
	}
	llp = 0;
	for (k = 0; k < d->nparas; k++)
	{
		Tdoc[k] = 0;
		llp += d->paras[k].total;
	}
	kvec = malloc(sizeof(*kvec)*llp);
	for (k = 0; k < model->k; k++)
	{
		Ntot[k] = 0;
		Ttot[k] = 0;
	}

	llp = 0;
	for(jp = 0; jp < d->nparas; jp++)
	{
		for(lp = 0; lp < d->paras[jp].total; lp++, llp++)
		{
			int tdiff;
			double pl = 0;
			int j, l, ll, r;
			/*
			*   resample all the k's
			*/
			for(r = 0; r < samples; r++)
			{
				ll = 0;
				for(j = 0; j <= jp; j++)
				{
					N = &N_mem[j*model->k];
					T = &T_mem[j*model->k];
					for (l=0; (j < jp && l < d->paras[j].total) || (j == jp && l < lp); l++, ll++)
					{
						k = kvec[ll];
						assert(k >= 0 && k < model->k);
						N[k]--; Ntot[k]--;
						if ( T[k]>N[k] ) {
							T[k]--; Ttot[k]--; Tdoc[j]--; Ttottot--;
							assert(T[k]<=N[k]);
						}
						k = sample_topic_ll(N, T, Ttot, Tdoc[j], Ttottot,
							  d->paras[j].words[l], model, fact);
						kvec[ll] = k;
						N[k]++; Ntot[k]++;
						if ( N[k]==1 ) {
						  tdiff = 1;
						} else {
						  tdiff = sample_table_ll(k, N[k], T[k], Ttot[k], Tdoc[j], Ttottot, model);
						}
						if ( tdiff!=0 ) {
						  T[k]+=tdiff; Ttot[k]+=tdiff; Tdoc[j]+=tdiff; Ttottot+=tdiff;
						  assert(T[k]<=N[k]);
						}
					}
				}
				/*
				*   now compute  prob( w_{jp,lp}, z_{jp,lp}, \delta t_j | rest )
				*/
				pl += sum_topic_ll(N, T, Ntot[jp], Ttot, Tdoc[jp], Ttottot, d->paras[jp].words[lp],
				 model);
				if ( !gsl_finite(pl) || pl<=0 ) {
				  fprintf(stderr, "Infinite or non-positive pl\n");
				  exit(1);
				}
			}
			/*
			*   sample new k for this particle for l=lp
			*/
			N = &N_mem[jp*model->k];
			T = &T_mem[jp*model->k];
			k = sample_topic_ll(N, T, Ttot, Tdoc[jp], Ttottot, d->paras[jp].words[lp], model, fact);
			/*
			*   save data, update stats
			*/
			kvec[llp] = k;
			N[k]++; Ntot[k]++;
			/*
			*   sample table, save data, update stats
			*/
			if ( N[k]==1 ) {
			  tdiff = 1;
			} else {
			  tdiff = sample_table_ll(k, N[k], T[k], Ttot[k], Tdoc[jp], Ttottot, model);
			}
			if ( tdiff!=0 ) {
			  T[k]+=tdiff; Ttot[k]+=tdiff; Tdoc[jp]+=tdiff; Ttottot+=tdiff;
			  assert(T[k]<=N[k]);
			}

			if ( pl<=0 ) {
			  fprintf(stderr, "pl illegal\n");
			  exit(1);
			}
			totalsum += log(pl/samples);
			if ( !gsl_finite(totalsum) ) {
			  fprintf(stderr, "Infinite totalsum\n");
			     exit(1);
			}
		}
	}

	gsl_vector_free(fact);
	return totalsum;
}

