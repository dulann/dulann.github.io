/*
 *
 * Routines for optimising strength parameter b in the PDP
 *
 *
 * Copyright (C) 2012 Lan Du
 * All rights reserved.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * Author: Lan Du (Lan.Du@mq.edu.au)
 */

#include <math.h>
#include <assert.h>
#include <gsl/gsl_sf.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_randist.h>

#include "arms.h"
#include "optimization.h"

extern gsl_rng* glob_r;

/*
 * Sampling b for the whole corpus with a = 0
 */
double sample_posteriorPDP_b(Cts* cts, Corpus* c, Model* model)
{
	  double x = 0, next_b;
	  int i, j;

	  double b = model->b;

	  int T = 0;
	  for(i = 0; i < c->ndocs; i++)
	  {
		  T += cts->sumT[i];
	  }

	  for(i = 0; i < c->ndocs; i++)
	  {
		  for(j = 0; j < c->docs[i].nparas; j++)
		  {
				double u,v;
				//  repeat until sample non-zero value
				while ( (u = next_gamma(b)) <= 1e-10 ) ;
				assert(c->docs[i].paras[j].total > 0);
				v = next_gamma(c->docs[i].paras[j].total);
				x -= log(u/(u+v));
		  }
	  }
	  //    repeat until get a b over the lower bound
	  while ( (next_b = next_gamma(T)/x) < 0.1 );
//	  fprintf(stderr,"Sampling b:  b=%lf, T=%d, \\sum log 1/x = %lf, b->%lf\n", b, T, x, next_b);
//	  printf("Sampling b:  b=%lf, T=%d, \\sum log 1/x = %lf, b->%lf\n", b, T, x, next_b);

	  model->b = next_b;
	  gsl_vector_set_all(cts->B, next_b);
	  return next_b;
}

/*
 * Adaptive rejection sampling for optimising b for each document.
 */
static double a;
static double lgq;
static int doc_id;
static Corpus* tc;
static Cts* tcts;

static double bterms(double b, void* data)
{
	int j;
	double val = lgq*b;
	double lba = gsl_sf_lngamma(b/a);
	for(j = 0; j < tc->docs[doc_id].nparas; j++)
	{
		int T = tcts->TJ[doc_id][j];
		assert((b/a + T) > 0);
		val += gsl_sf_lngamma(b/a + T) - lba;
	}
	return val;
}


void ars_b(int rep, Cts* cts, Model* model, Corpus* c)
{
	int i, j;
	a = model->a;
	tc = c;
	tcts = cts;
	while((--rep) > 0)
	{
		for(i = 0; i < c->ndocs; i++)
		{
			double b = vget(cts->B, i);
			lgq = 0;
			doc_id = i;
			for(j = 0; j < c->docs[i].nparas; j++)
			{
				double cust = c->docs[i].paras[j].total;
				double q = 0;
				int try = 5;
				while(--try >= 0 && q <= 0 )
				{
					q = gsl_ran_beta(glob_r, b, cust);
				}
				if(q <= 0){
					fprintf(stderr, "q in sample_b(b = %f, tot_cust = %f, q = %lf) "
					    "went zero!!!\n", b, cust, q);
					exit(1);
				}
				if(q < 1e-10){
					q = 1e-10;
				}
				lgq += gsl_sf_log(q);
			}

			double newb;
			double lv = 0.01;
			double rv = 500;
			arms_simple (8, &lv, &rv, bterms, NULL, 0, &b, &newb);
			//printf("i = %d, newb = %lf\n", i, newb);
			vset(cts->B, i, newb);
		}
	}
	tc = NULL;
	tcts = NULL;
}

void saveb(Cts* cts, char* file, int ite)
{
	char str[BUFSIZ];
	sprintf(str, "%s/b_%d.txt", file, ite);
	save_vector(str,cts->B);
}
