/*
 * corpus.h
 *
 * Copyright (C) 2012 Lan Du
 * All rights reserved.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * Author: Lan Du (Lan.Du@mq.edu.au)
 *
 */

#ifndef CORPUS_H_
#define CORPUS_H_

typedef struct para {
	int total;
	int* words;
} para;

typedef struct doc {
	int total;
	int nparas;
	para* paras;
} doc;

typedef struct Corpus {
	int total;
	int ndocs;
	int max_length; // the maximum length of paragraphs
	doc* docs;
} Corpus;

typedef struct id_2_word {
	int id;
	char word_str[100];
} id_2_word;

typedef struct vocabulary {
	int size;
	id_2_word* word_map;
} vocabulary;

/*
 * functions
 */
Corpus* read_data(const char*);
void write_corpus(Corpus*, char*);

void split_corpus(Corpus* s, Corpus* c1, Corpus* c2);

vocabulary* read_vocabulary(char*);
void write_vocabulary(vocabulary*, char*);

void free_corpus(Corpus*);
void free_vocabulary(vocabulary*);

#endif /* CORPUS_H_ */
