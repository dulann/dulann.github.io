/*
 * sort.c
 *
 * Copyright (C) 2012 Lan Du
 * All rights reserved.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * Author: Lan Du (Lan.Du@mq.edu.au)
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <gsl/gsl_vector.h>

#include "util.h"
/*
 *
 *
 */
int choose_pivot(int left, int right) {
	return ((left + right) / 2);
}

/*
 *
 *
 */
void swap(pair* x, pair* y) {
	pair tmp;

	tmp.key = x->key;
	tmp.value = x->value;
	x->key = y->key;
	x->value = y->value;
	y->key = tmp.key;
	y->value = tmp.value;
}

/*
 *
 *
 */
void quick_sort(pair* pairs, int m, int n) {

	int pivot_index;
	double val;
	int i, j;

	val = 0;
	if (m < n) {
		pivot_index = choose_pivot(m, n);
		swap(&pairs[m], &pairs[pivot_index]);
		val = pairs[m].value;
		i = m + 1;
		j = n;
		while (i <= j) {
			//			while( (i <= n) && (pairs[i].value <= val)){
			while ((i <= n) && (pairs[i].value >= val)) {
				i++;
			}
			//			while((j >= m) && (pairs[j].value > val)){
			while ((j >= m) && (pairs[j].value < val)) {
				j--;
			}
			if (i < j)
				swap(&pairs[i], &pairs[j]);
		}
		swap(&pairs[m], &pairs[j]);
		quick_sort(pairs, m, j - 1);
		quick_sort(pairs, j + 1, n);
	}
}

/*
 *
 *
 */
void sort(gsl_vector* vector) {
	int i;
	pair* pairs = (pair*) malloc(sizeof(pair) * vector->size);
	for (i = 0; i < vector->size; i++) {
		pairs[i].key = i;
		pairs[i].value = gsl_vector_get(vector, i);
	}

	quick_sort(pairs, 0, vector->size - 1);

	for (i = 0; i < vector->size; i++) {
		vset(vector, i, pairs[i].key);
	}
	free(pairs);
}

