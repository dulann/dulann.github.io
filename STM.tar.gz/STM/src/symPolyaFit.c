/*
 * optimization.h
 *
 * Copyright (C) 2012
 * All rights reserved.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * Author: Lan Du (Lan.Du@mq.edu.au)
 *         Changyou Chen (Changyou.Chen@nicta.com.au)
 */
#include <assert.h>
#include <gsl/gsl_sf.h>
#include <math.h>

#include "optimization.h"
#include "util.h"

#define maxIt 100
#define threshold 1e-4
#define GAMMA_MAX 10
#define GAMMA_MIN 0.0001

/*************************
* size1: #docs for alpha, #topics for gamma
* size2: #topic for alpha, #types for gamma
* counts[size1][size2]
* count_sum[size1]
* count_sum:	= \sum_j counts(:, j)
* initV: the previous alpha value or gamma value
*************************/

double sym_polya_fit(double**counts, double* count_sum,
		int size1, int size2, double initV)
{
	int i, j, iter;
	double sum1, sum2, oldvalue, gamma;
	iter = 0;
	gamma = oldvalue = initV;
	while(iter++ < maxIt){
		sum1 = 0;
		sum2 = 0;
		oldvalue = gamma;
		for(i = 0; i < size1; i++){
			for(j = 0; j < size2; j++){
				sum1 += gsl_sf_psi(counts[i][j] + oldvalue);
			}
			sum2 += gsl_sf_psi(count_sum[i] + size2 * oldvalue);
		}
		sum1 -= size1 * size2 * gsl_sf_psi(oldvalue);
		sum2 *= size2;
		sum2 -= size1 * size2 * gsl_sf_psi(size2 * oldvalue);
		gamma = oldvalue * sum1 / sum2;
		if(gamma > GAMMA_MAX){
			gamma = 0.5;
			break;
		}
		if(gamma < GAMMA_MIN){
			gamma = GAMMA_MIN;
			break;
		}
		if(iter > 20 && fabs(gamma - oldvalue) / oldvalue < threshold){
			break;
		}
	}
	return gamma;
}

double sym_polya_fit_newton(double**counts, double* count_sum,
		int size1, int size2, double initV)
{
	int k, v, iter;
	double sum1, sum2, gamma_old, gamma;
	iter = 0;
	gamma = gamma_old = initV;
	while(iter++ < maxIt){
		sum1 = 0;
		sum2 = 0;
		gamma_old = gamma;
		for(k = 0; k < size1; k++){
			for(v = 0; v < size2; v++){
				sum1 += gsl_sf_psi(counts[k][v] + gamma_old);
				sum2 += gsl_sf_psi_1(counts[k][v] + gamma_old);
			}
			sum1 -= size2 * gsl_sf_psi(count_sum[k] + size2 * gamma_old);
			sum2 -= (double)size2 * (double)size2 * gsl_sf_psi_1(count_sum[k] + size2 * gamma_old);
		}
		sum1 += size1 * size2 * (gsl_sf_psi(size2 * gamma_old) - gsl_sf_psi(gamma_old));
		sum2 += size1 * size2 * (size2 * gsl_sf_psi_1(size2 * gamma_old) - gsl_sf_psi_1(gamma_old));
		gamma -= sum1 / sum2;
		if(gamma > GAMMA_MAX){
			gamma = 0.5;
			break;
		}
		if(gamma < GAMMA_MIN){
			gamma = GAMMA_MIN;
			break;
		}
		if(iter > 20 && fabs(gamma - gamma_old) / gamma_old < threshold){
			break;
		}
	}
	return gamma;
}

void alpha_opt(Cts* cts, Model* model, Corpus* c)
{
	int i, k;

	double* countSum = (double*)malloc(sizeof(double)*c->ndocs);
	double** counts = (double**)malloc(sizeof(double*)*c->ndocs);
	for(i = 0; i < c->ndocs; i++)
	{
		counts[i] = (double*)malloc(sizeof(double)*model->k);
		for(k = 0; k < model->k; k++)
		{
			counts[i][k] = cts->TK[i][k];
		}
		countSum[i] = cts->sumT[i];
	}
	double newAlpha = sym_polya_fit(counts, countSum,
			c->ndocs, model->k, model->alphaSum/model->k);
	gsl_vector_set_all(model->alpha, newAlpha);
	model->alphaSum = newAlpha*model->k;

	free(countSum);
	for(i = 0; i < c->ndocs; i++)
	{
		free(counts[i]);
	}
	free(counts);
}

void alpha_opt_newton(Cts* cts, Model* model, Corpus* c)
{
	int i, k;

	double* countSum = (double*)malloc(sizeof(double)*c->ndocs);
	double** counts = (double**)malloc(sizeof(double*)*c->ndocs);
	for(i = 0; i < c->ndocs; i++)
	{
		counts[i] = (double*)malloc(sizeof(double)*model->k);
		for(k = 0; k < model->k; k++)
		{
			counts[i][k] = cts->TK[i][k];
		}
		countSum[i] = cts->sumT[i];
	}
	double newAlpha = sym_polya_fit_newton(counts, countSum,
			c->ndocs, model->k, model->alphaSum/model->k);
	gsl_vector_set_all(model->alpha, newAlpha);
	model->alphaSum = newAlpha*model->k;

	free(countSum);
	for(i = 0; i < c->ndocs; i++)
	{
		free(counts[i]);
	}
	free(counts);
}

