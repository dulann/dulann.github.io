/*
 * model.c
 *
 * Copyright (C) 2012 Lan Du
 * All rights reserved.
 *
 * Author: Lan Du (Lan.Du@mq.edu.au)
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <gsl/gsl_sf.h>
#include <gsl/gsl_math.h>

#include "model.h"
#include "util.h"
/*
 * totK:	number of topics
 * totV: 	size of vocabulary
 */
Model* new_model(int totK, int totV)
{
	Model* model = (Model*) malloc(sizeof(Model));
	model->k = totK;
	model->v = totV;
	model->alpha = gsl_vector_calloc(totK);
	model->gamma = gsl_vector_calloc(totV);
	model->phi = gsl_matrix_calloc(totK, totV);
	return model;
}

Cts* new_cts(int totK, int totV, Corpus* c, double b)
{
	int i, j, k;

	Cts* cts = (Cts*) malloc(sizeof(Cts));
	cts->M = (int**)malloc(sizeof(int*)*totK);
	cts->m = (int*)malloc(sizeof(int)*totK);

	for(k = 0; k < totK; k++)
	{
		cts->m[k] = 0;
		cts->M[k] = (int*)malloc(sizeof(int)*totV);
		for(j = 0; j < totV; j++)
		{
			cts->M[k][j] = 0;
		}
	}

	cts->sumT = (int*)malloc(sizeof(int)*c->ndocs);
	cts->TJ = (int**)malloc(sizeof(int*)*c->ndocs);
	cts->TK = (int**)malloc(sizeof(int*)*c->ndocs);
	cts->n = (int***)malloc(sizeof(int**)*c->ndocs);
	cts->t = (int***)malloc(sizeof(int**)*c->ndocs);

	for(i = 0; i < c->ndocs; i++)
	{
		cts->sumT[i] = 0;
		cts->TJ[i] = (int*)malloc(sizeof(int)*c->docs[i].nparas);
		cts->TK[i] = (int*)malloc(sizeof(int)*totK);
		cts->n[i] = (int**)malloc(sizeof(int*)*c->docs[i].nparas);
		cts->t[i] = (int**)malloc(sizeof(int*)*c->docs[i].nparas);
		for(j = 0; j < c->docs[i].nparas; j++)
		{
			cts->TJ[i][j] = 0;
			cts->n[i][j] = (int*)malloc(sizeof(int)*totK);
			cts->t[i][j] = (int*)malloc(sizeof(int)*totK);
			for(k = 0; k < totK; k++)
			{
				cts->TK[i][k] = 0;
				cts->n[i][j][k] = 0;
				cts->t[i][j][k] = 0;
			}
		}
	}
	cts->B = gsl_vector_calloc(c->ndocs);
	gsl_vector_set_all(cts->B, b);

	return cts;
}

/*
 * Initialize the topic assignment of each word-token
 *
 */
int*** new_assignment(Corpus* c)
{
	int i, j;

	int*** ass = (int***)malloc(sizeof(int**)*c->ndocs);
	for(i = 0; i < c->ndocs; i++)
	{
		ass[i] = (int**)malloc(sizeof(int*)*c->docs[i].nparas);
		for(j = 0; j < c->docs[i].nparas; j++)
		{
			ass[i][j] = (int*)malloc(sizeof(int)*c->docs[i].paras[j].total);
		}
	}
	return ass;
}
/*
 * Initialise the estimator for compute mu, nu, and phi
 */
Estimator* new_estimator(Corpus* c, int k, int v, int do_mu, int do_nu, int do_phi)
{
	int i;

	Estimator* est = (Estimator*)malloc(sizeof(Estimator));

	if(do_mu){
		est->mu = gsl_matrix_calloc(c->ndocs, k);
	}else{
		est->mu = NULL;
	}

	if(do_phi){
		est->phi = gsl_matrix_calloc(k, v);
	}else{
		est->phi = NULL;
	}

	if(do_nu){
		est->nu = (gsl_matrix**)malloc(sizeof(gsl_matrix*) * c->ndocs);
		for(i = 0; i < c->ndocs; i++)
		{
			est->nu[i] = gsl_matrix_calloc(c->docs[i].nparas, k);
		}
	}else{
		est->nu = NULL;
	}
	return est;
}
/*
 * randomly initialize the model
 */
Model* modelInitialize(int k, int v, double alpha, double gamma, double a, double b)
{
	Model* model;
	model = new_model(k, v);
	model->a = a;
	model->b = b;
	model->alphaSum = alpha * k;
	model->gammaSum = gamma*v;
	gsl_vector_set_all(model->alpha, alpha);
	gsl_vector_set_all(model->gamma, gamma);
	model->seed = 0;
	return model;
}
/*
 * read model
 */
Model* read_model(char* file)
{
	char str[200];
	FILE* fileptr;
	Model* model;
	int k;
	int v;
	int tmp;

	sprintf(str, "%s/stmModel.txt", file);
	fileptr = fopen(str, "r");
	tmp = fscanf(fileptr, "model->k: %d\n", &k);
	tmp = fscanf(fileptr, "model->v: %d\n", &v);
	model = new_model(k, v);
	tmp = fscanf(fileptr, "model->a: %lf\n", &model->a);
	tmp = fscanf(fileptr, "model->b: %lf\n", &model->b);
	tmp = fscanf(fileptr, "model->alphaSum: %lf\n", &model->alphaSum);
	tmp = fscanf(fileptr, "model->gammaSum: %lf\n", &model->gammaSum);
	tmp = fscanf(fileptr, "model->seed: %ld\n", &model->seed);
	fclose(fileptr);

	sprintf(str, "%s/modelAlpha.txt", file);
	scanf_vector(str, model->alpha);

	sprintf(str, "%s/modelGamma.txt", file);
	scanf_vector(str, model->gamma);

	sprintf(str, "%s/modelPhi.txt", file);
	scanf_matrix(str, model->phi);

	return model;
}
/*
 * function: to save model (model sample)
 */
void save_model(Model* model, gsl_matrix* mphi, char* file)
{
	char str[200];
	FILE* fileptr;

	sprintf(str, "%s/stmModel.txt", file);
	fileptr = fopen(str, "w");
	fprintf(fileptr, "model->k: %d\n", model->k);
	fprintf(fileptr, "model->v: %d\n", model->v);
	fprintf(fileptr, "model->a: %lf\n", model->a);
	fprintf(fileptr, "model->b: %lf\n", model->b);
	fprintf(fileptr, "model->alphaSum: %lf\n", model->alphaSum);
	fprintf(fileptr, "model->gammaSum: %lf\n", model->gammaSum);
	fprintf(fileptr, "model->seed: %ld\n", model->seed);
	fclose(fileptr);

	sprintf(str, "%s/modelAlpha.txt", file);
	save_vector(str, model->alpha);

	sprintf(str, "%s/modelGamma.txt", file);
	save_vector(str, model->gamma);

	sprintf(str, "%s/modelPhi.txt", file);
	save_matrix(str, mphi);
}

/*
 *
 */
int*** read_topic_assignmnet(Corpus* c, char* file)
{
	int*** ass = new_assignment(c);
	int i, j, l;
	char str[BUFSIZ];
	FILE* fileptr;

	for(i = 0; i < c->ndocs; i++)
	{
		sprintf(str, "%s/assDoc-%d.txt", file, i);
		fileptr = fopen(str, "r");
		for(j = 0; j < c->docs[i].nparas; j++)
		{
			for(l = 0; l < c->docs[i].paras[j].total; l++)
			{
				if(fscanf(fileptr, "%d\n", &ass[i][j][l]) != 1)
				{
					fprintf(stderr, "Error: model.c-->read topic assignment error!!!\n");
				}
			}
		}
		fclose(fileptr);
	}

	return ass;
}

void save_topic_assignment(Corpus* c, int*** ass, char* file)
{
	int i, j, l;
	char str[BUFSIZ];
	FILE* fileptr;

	for(i = 0; i < c->ndocs; i++)
	{
		sprintf(str, "%s/assDoc-%d.txt", file, i);
		fileptr = fopen(str, "w");
		for(j = 0; j < c->docs[i].nparas; j++)
		{
			for(l = 0; l < c->docs[i].paras[j].total; l++)
			{
				fprintf(fileptr, "%d\n", ass[i][j][l]);
			}
		}
		fclose(fileptr);
	}
}

void save_estimator(Estimator* est, Corpus* c, char* file, int doMu, int doNu, int doPhi)
{
	int i;
	char str[BUFSIZ];
	char nu_root[BUFSIZ];

	if(doMu){
		sprintf(str, "%s/mu.txt", file);
		save_matrix(str, est->mu);
	}

	if(doPhi){
		sprintf(str, "%s/phi.txt", file);
		save_matrix(str, est->phi);
	}

	if(doNu){
		sprintf(nu_root, "%s/nu", file);
		mkdir(nu_root, S_IRUSR|S_IWUSR|S_IXUSR);
		for(i = 0; i < c->ndocs; i++)
		{
			sprintf(str, "%s/%d-nu.txt", nu_root, i);
			save_matrix(str, est->nu[i]);
		}
	}
}

void printf_estimator(Estimator* est, Corpus* c, char* file, int doMu, int doNu, int doPhi)
{
	int i;
	char str[BUFSIZ];
	char nu_root[BUFSIZ];

	if(doMu){
		sprintf(str, "%s/mu.txt", file);
		printf_matrix(str, est->mu);
	}

	if(doPhi){
		sprintf(str, "%s/phi.txt", file);
		printf_matrix(str, est->phi);
	}

	if(doNu){
		sprintf(nu_root, "%s/nu", file);
		mkdir(nu_root, S_IRUSR|S_IWUSR|S_IXUSR);
		for(i = 0; i < c->ndocs; i++)
		{
			sprintf(str, "%s/%d-nu.txt", nu_root, i);
			printf_matrix(str, est->nu[i]);
		}
	}
}

Estimator* read_estimator(Corpus* c, int k, int v, char* file, int doMu, int doNu, int doPhi)
{
	int i;
	char str[BUFSIZ];
	char nu_root[BUFSIZ];

	Estimator* est =  new_estimator(c, k, v, doMu, doNu, doPhi);

	if(doMu){
		sprintf(str, "%s/mu.txt", file);
		scanf_matrix(str, est->mu);
	}

	if(doPhi){
		sprintf(str, "%s/phi.txt", file);
		scanf_matrix(str, est->phi);
	}

	if(doNu){
		sprintf(nu_root, "%s/nu", file);
		for(i = 0; i < c->ndocs; i++)
		{
			sprintf(str, "%s/%d-nu.txt", nu_root, i);
			scanf_matrix(str, est->nu[i]);
		}
	}
	return est;
}

void print_top_words(int num_words, int ntopics, gsl_matrix* M, vocabulary* v, char* file)
{
	FILE* fileptr;
	int k, i, j;
	int word_id;
	gsl_vector* vector;

	fileptr = fopen(file, "w");
	vector = gsl_vector_alloc(v->size);
	for (k = 0; k < ntopics; k++)
	{
		fprintf(fileptr, "------word_topic_%d------\n", k);
		gsl_matrix_get_row(vector, M, k);
		sort(vector);
		for (i = 0; i < num_words; i++)
		{
			word_id = (int) vget(vector, i);
			for (j = 0; j < v->size; j++)
			{
				if (v->word_map[j].id == word_id) {
					fprintf(fileptr, "%s ", v->word_map[j].word_str);
					break;
				}
			}
		}
		fprintf(fileptr, "\n");
	}
	fclose(fileptr);
	gsl_vector_free(vector);
}

/*
 * Note: free estimator must before free corpus!!!
 */
void free_estimator(Estimator* est, Corpus* c, int do_mu, int do_nu, int do_phi)
{
	if(do_nu){
		int i;
		for(i = 0; i < c->ndocs; i++)
		{
			gsl_matrix_free(est->nu[i]);
		}
		free(est->nu);
	}

	if(do_mu){
		gsl_matrix_free(est->mu);
	}

	if(do_phi){
		gsl_matrix_free(est->phi);
	}
	free(est);
}

/*
 * Note: free topic assignment must before free corpus!!!
 */
void free_assignment(int*** ass, Corpus* c)
{
	int i, j;

	for (i = 0; i < c->ndocs; i++)
	{
		for (j = 0; j < c->docs[i].nparas; j++)
		{
			free(ass[i][j]);
		}
		free(ass[i]);
	}
	free(ass);
}
/*
 * Note free cts must before free corpus !!!
 */
void free_cts(Cts* cts, Corpus* c, int totK)
{
	int i, j, k;

	for(k = 0; k < totK; k++)
	{
		free(cts->M[k]);
	}
	free(cts->M);
	free(cts->m);
	for(i = 0; i < c->ndocs; i++)
	{
		for(j = 0; j < c->docs[i].nparas; j++)
		{
			free(cts->n[i][j]);
			free(cts->t[i][j]);
		}
		free(cts->n[i]);
		free(cts->t[i]);
		free(cts->TJ[i]);
		free(cts->TK[i]);
	}

	free(cts->sumT);
	free(cts->TJ);
	free(cts->TK);
	free(cts->n);
	free(cts->t);
	gsl_vector_free(cts->B);
	free(cts);
}
void free_model(Model* model)
{
	gsl_vector_free(model->alpha);
	gsl_vector_free(model->gamma);
	gsl_matrix_free(model->phi);
	free(model);
}
/*
 *
 */
void free_all(Corpus* c, Model* model, Cts* cts, int*** ass, vocabulary* v)
{
	free_cts(cts, c, model->k);
	free_model(model);
	free_assignment(ass, c);
	free_corpus(c);
	free_vocabulary(v);
	printf("--- All space is freed!!!\n");
}

