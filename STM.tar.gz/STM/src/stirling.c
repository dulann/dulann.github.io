/*
 * stirling.c
 *
 * Copyright (C) 2010 Wray Buntine
 * All rights reserved.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * Author: Wray Buntine (Wray.Buntine@nicta.com.au)
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <gsl/gsl_math.h>

#include "util.h"

static double* S_m;
static int usedM, usedN;
#define SNM(N, M) S_m[((M) * (usedN + 1)) + (N)]

/*
 *
 * Note: 0 <= a < 1
 * 		 maxN >= maxM
 */
void make_stirling_table(int maxN, int maxM, float a) {
	int N, M;
	usedM = maxM;
	usedN = maxN;
	S_m = malloc(sizeof(S_m[0]) * (maxM + 1) * (maxN + 1));

	for (N = 1; N < maxN; N++) {
		SNM(N,0) = GSL_NEGINF;
		for (M = N + 1; M < maxM; M++)
			SNM(N,M) = GSL_NEGINF;
	}
	SNM(0,0) = 0;
	SNM(1,1) = 0;
	for (N = 2; N <= maxN; N++) {
		for (M = 1; M <= maxM && M <= N; M++) {
//			if (N == M){
//				SNM(N,M) = SNM((N-1),(M-1)) - log(N);
//			}else{
//				SNM(N,M) = log_sum(SNM((N-1),(M-1)), (log(N - (M * a) - 1.0) + SNM((N-1),M))) - log(N);
//			}
			if (N == M){
				SNM(N,M) = 0;
			}else{
				SNM(N,M) = log_sum(SNM((N-1),(M-1)), (log(N - (M * a) - 1.0) + SNM((N-1),M)));
			}
			if (!gsl_finite(SNM(N,M))) {
				fprintf(stderr, " S_NM(%d,%d) gone inf. during adding\n", N, M);
				exit(1);
			}
		}
	}
}

void extend_stirling_table(int maxM, float a) {
	int N, M;
	int lastM = usedM;
	printf("lastM = %d\n", lastM);
	usedM = maxM;
	S_m = realloc(S_m, sizeof(S_m[0]) * (maxM + 1) * (usedN + 1));

	/*
	 *  all values outside bounds to 0
	 */
	for (N = 1; N < usedN; N++) {
		for (M = N + 1; M < maxM; M++)
			SNM(N,M) = GSL_NEGINF;
	}
	for (N = 2; N <= usedN; N++) {
		for (M = (lastM + 1); M <= maxM; M++) {
//			if (N == M){
//				SNM(N,M) = SNM((N-1),(M-1)) - log(N);
//			} else{
//				SNM(N,M) = log_sum(SNM((N-1), (M-1)), (log(N - (M * a) - 1.0) + SNM((N-1),M))) - log(N);
//			}
			if (N == M){
				SNM(N,M) = 0;
			} else{
				SNM(N,M) = log_sum(SNM((N-1), (M-1)), (log(N - (M * a) - 1.0) + SNM((N-1),M)));
			}
			if (!gsl_finite(SNM(N,M))) {
				fprintf(stderr, " S_NM(%d,%d) gone inf. during adding\n", N, M);
				exit(1);
			}
		}
	}
}

double stirling(int n, int m, float a) {
	if (n > usedN) {
		printf("n > usedN, making new stirling table!!!\n");
		if(m > usedM)
			make_stirling_table(n, m, a);
		else
			make_stirling_table(n, usedM, a);
	} else if (m > usedM) {
		printf("m > usedM, extending the old stirling table!!!\n");
		extend_stirling_table(m, a);
	}
	return SNM(n,m);
}

void print_stirling_table(char* file)
{
	int n, m;
	FILE* fileptr;
	char str[200];
	sprintf(str, "%s-stirling-table.txt", file);
	fileptr = fopen(str, "w");
	for(n = 1; n <= usedN; n++)
	{
		for(m = 1; m <= usedM && m <= n; m++)
		{
			fprintf(fileptr, "%lf ", SNM(n,m));
		}
		fprintf(fileptr, "\n");
	}
	fclose(fileptr);
}

void free_stirling_table()
{
	free(S_m);
	printf("Stirling table S_m is freed!!!\n");
}

/*
int main(int argc, char* argv[]) {
	int n, m;
	make_stirling_table(30, 10, 0.3);
	printf(">>>>>>>>>>>>>>\n");
	for(n = 1; n <= 30; n++){
		for(m = 1; m <= 10 && m <= n; m++){
			printf("n = %d, m = %d, stirling num: %f\n", n, m, stirling(n, m, 0.3));
		}
	}
	printf("stirling num: %f\n", stirling(10, 7, 0.3));
	printf("stirling num: %f\n", stirling(32, 3, 0.3));
	for(n = 1; n <= 32; n++){
		for(m = 0; m <= 10 && m <= n; m++){
			printf("n = %d, m = %d, stirling num: %f\n", n, m, stirling(n, m, 0.3));
		}
	}
	double x = 2;
	double y = 0.5;
	n = 30;
	printf("x = %f, y = %f, n = %d, poch_sym = %f\n", x, y, n, poch_sym(x, y, n));
	printf("x = %f, y = %f, n = %d, log_poch_sym = %f\n", x, y, n, log_poch_sym(x, y, n));
	free(S_m);
	return 0;
}
*/
