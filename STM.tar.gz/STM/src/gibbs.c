/*
 * gibbs.c
 *
 * Gibbs sampling routines shared by Latent Dirichlet Allocation and
 * Segmented Topic Model
 *
 * Copyright (C) 2012 Lan Du
 * All rights reserved.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * Author: Lan Du (Lan.Du@mq.edu.au)
 *
 */
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <assert.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_rng.h>

#include "gibbs.h"
#include "util.h"

/*
 * uniformly initialize the topic assignment of each word
 * Note:
 * 		the number of tables for each k is set to 1;
 * 		all the words with topic k in paragraph j sit in one table
 *
 */
void init_state_gibbs(Cts* cts, int*** ass, Corpus* c, Model* model)
{
	int i, j, l;
	int topic;
	gsl_rng* r = gsl_rng_alloc(gsl_rng_taus);

	printf("****** Begin initialize the states ******\n");
	if(model->seed == 0){
		time_t seed;
		time(&seed);
		gsl_rng_set(r, (long)seed);
		model->seed = (long)seed;
		printf("The seed for initial gibbs: %ld\n", model->seed);
	}else{
		gsl_rng_set(r, model->seed);
	}

	for (i = 0; i < c->ndocs; i++)
	{
		for (j = 0; j < c->docs[i].nparas; j++)
		{
			for (l = 0; l < c->docs[i].paras[j].total; l++)
			{
				topic = floor(gsl_rng_uniform(r) * model->k);
				ass[i][j][l] = topic;

				cts->M[topic][c->docs[i].paras[j].words[l]]++;
				cts->m[topic]++;
				cts->n[i][j][topic]++;
				/*
				 * t_{i, j, k}  from 0 to 1
				 */
				if(cts->t[i][j][topic] == 0){
					cts->t[i][j][topic] = 1;
					cts->TK[i][topic]++;
					cts->TJ[i][j]++;
					cts->sumT[i]++;
				}
			}
		}
	}
	gsl_rng_free(r);
	printf(">>>>>> End <<<<<<\n");
}

/*
 * Function: compute phi
 */
void compute_phi(Cts* cts, Model* model)
{
	int k, w;
	double num, den;

	for(k = 0; k < model->phi->size1; k++)
	{
		for(w = 0; w < model->phi->size2; w++)
		{
			num = vget(model->gamma, w) + cts->M[k][w];
			den =  model->gammaSum + cts->m[k];
			mset(model->phi, k, w, num/den);
		}
	}
}
void compute_mean_phi(gsl_matrix* mphi, Model* model, int n)
{
	int k, w;
	double val;

	for(k = 0; k < model->phi->size1; k++)
	{
		for(w = 0; w < model->phi->size2; w++)
		{
			val = (mget(mphi, k, w)*(n - 1) + mget(model->phi, k, w))/n;
			mset(mphi, k, w, val);
		}
	}

}
