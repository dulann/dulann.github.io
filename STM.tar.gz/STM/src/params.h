/*
 * params.h
 *
 * Copyright (C) 2010 Lan Du
 * All rights reserved.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * Author: Lan Du (Lan.Du@nicta.com.au)
 *
 */
#ifndef PARAMS_H_
#define PARAMS_H_

typedef struct stm_params {
	int k;
	double a;
	double b;
	double alpha;
	double gamma;
	int gibbs_max_iter;
	int burn_in;
	int sampling_lag;
	int top_words;
} stm_params;

void read_params(char*);
void write_params(char*);
void print_params();
void default_params();
void set_paras(int k, double a, double b, double alpha, double gamma,
		int gibbs_max_iter, int burn_in, int sampling_lag, int top_words);
#endif /* PARAMS_H_ */
