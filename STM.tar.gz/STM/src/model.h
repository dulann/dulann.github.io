/*
 * model.h
 *
 * Copyright (C) 2012 Lan Du
 * All rights reserved.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * Author: Lan Du (Lan.Du@mq.edu.au)
 *
 */

#ifndef MODEL_H_
#define MODEL_H_

#include <gsl/gsl_matrix.h>
#include <gsl/gsl_vector.h>

#include "corpus.h"

/*
 * Model structure
 */
typedef struct Model {
	int k;
	int v;
	double a;
	double b;
	double alphaSum;
	double gammaSum;
	gsl_vector* alpha;
	gsl_vector* gamma;
	gsl_matrix* phi;
	long seed;
} Model;
/*
 * Statistics recorded for the whole corpus
 */
typedef struct Cts {
	int** M; // K * W
	int* m; // K
	int*** n; // I * J * K
	int* sumT; // I
	int*** t; // I * J * K
	int** TJ; // I * J
	int** TK; // I * K
	gsl_vector* B;
} Cts;

/*
 * estimator
 */
typedef struct Estimator{
	gsl_matrix* mu;
	gsl_matrix* phi;
	gsl_matrix** nu;
} Estimator;
/*
 * functions
 */
Model* new_model(int k, int v);
Cts* new_cts(int k, int v, Corpus* c, double b);
int*** new_assignment(Corpus* c);
Estimator* new_estimator(Corpus* c, int k, int v, int doMu, int doNu, int doPhi);

Model* modelInitialize(int k, int v, double alpha, double gamma, double a, double b);

Model* read_model(char* file);
void save_model(Model* model, gsl_matrix* mphi, char* file);

Cts* read_cts(char* file, int k, int v);
void save_cts(Cts* cts, char* file);

int*** read_topic_assignmnet(Corpus* c, char* file);
void save_topic_assignment(Corpus* c, int*** ass, char* file);

void printf_estimator(Estimator* est, Corpus* c, char* file, int doMu, int doNu, int doPhi);
void save_estimator(Estimator* est, Corpus* c, char* file, int doMu, int doNu, int doPhi);
Estimator* read_estimator(Corpus* c, int k, int v, char* file, int doMu, int doNu, int doPhi);

void print_top_words(int num_words, int ntopics, gsl_matrix* M, vocabulary* v, char* file);

void free_estimator(Estimator* est, Corpus* c, int doMu, int doNu, int doPhi);
void free_assignment(int***, Corpus* c);
void free_cts(Cts*, Corpus* c, int totK);
void free_model(Model*);
void free_all(Corpus*, Model*, Cts*, int***, vocabulary*);

#endif /* MODEL_H_ */
