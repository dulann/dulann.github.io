/*
 * stm.c
 *
 * Gibbs sampling routines for segmented topic model
 *
 * Copyright (C) 2012 Lan Du
 * All rights reserved.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * Author: Lan Du (Lan.Du@mq.edu.au)
 *
 */
#include <gsl/gsl_sf.h>
#include <gsl/gsl_math.h>

#include "stm.h"
#include "gibbs.h"
#include "optimization.h"

#define MAX_M 500
#define SAMPLES 30

extern stm_params PARAMS;

/*
 * STM model log likelihood
 */
static double model_log_lihood(Corpus* c, Cts* cts, Model* model)
{
     int i, j, w;
     int k;
     double log_lihood = 0;
     
     for(i = 0; i < c->ndocs; i ++)
     {
          double b = vget(cts->B, i);
          log_lihood += gsl_sf_lngamma(model->alphaSum) -
          gsl_sf_lngamma(model->alphaSum + cts->sumT[i]);
          for(k=0; k < model->k; k++)
          {
               log_lihood += gsl_sf_lngamma(vget(model->alpha, k) + cts->TK[i][k])
               - gsl_sf_lngamma(vget(model->alpha, k));
          }
          
          for(j = 0; j < c->docs[i].nparas; j ++)
          {
               log_lihood += log_poch_sym(b, model->a, cts->TJ[i][j])
               - log_poch_sym(b, 1, c->docs[i].paras[j].total);
               
               for(k = 0; k < model->k; k++)
               {
                    log_lihood += stirling(cts->n[i][j][k], cts->t[i][j][k], model->a);
               }
          }
          
     }
     
     for(k = 0; k < model->k; k++)
     {
          log_lihood += gsl_sf_lngamma(model->gammaSum) -
          gsl_sf_lngamma(model->gammaSum + cts->m[k]);
          for(w = 0; w < model->v; w++)
          {
               log_lihood += gsl_sf_lngamma(vget(model->gamma, w) + cts->M[k][w])
               - gsl_sf_lngamma(vget(model->gamma, w));
          }
     }
     
     log_lihood = -log_lihood/c->total;
     
     if(!gsl_finite(log_lihood)){
          fprintf(stderr, "STM: model_log_lihood is NaN or infinite!!!");
          exit(1);
     }
     return log_lihood;
}
/*
 * STM: held-out perplexity computation
 */
static double heldout_perp(Cts* cts, Corpus* c1, Corpus* c2, Model* model)
{
     int i, j, l;
     int k, w;
     double nu_k;
     double mu_k;
     double log_lihood = 0;
     double perp;
     
     for(i = 0; i < c2->ndocs; i++)
     {
          double b = vget(cts->B, i);
          for(j = 0; j < c2->docs[i].nparas; j++)
          {
               for(l = 0; l < c2->docs[i].paras[j].total; l++)
               {
                    double tmp = 0;
                    w = c2->docs[i].paras[j].words[l];
                    for(k = 0; k < model->k; k++)
                    {
                         mu_k = (vget(model->alpha, k) + cts->TK[i][k])
                         /(model->alphaSum + cts->sumT[i]);
                         nu_k = (cts->n[i][j][k] - cts->t[i][j][k] *model->a
                                 + (cts->TJ[i][j]*model->a + b)*mu_k)
                         /(b + c1->docs[i].paras[j].total);
                         tmp += mget(model->phi, k, w) * nu_k;
                    }
                    assert(tmp > 0);
                    log_lihood += gsl_sf_log(tmp);
               }
          }
     }
     perp = -log_lihood/c2->total;
     if(!gsl_finite(perp)){
          fprintf(stderr, "Oops: perplexity is NaN or infinite!!!\n");
          exit(1);
     }
     return perp;
}

static void compute_mean_mu(Estimator* m_est, Cts* cts, Model* model, int ndocs, int n)
{
     int i, k;
     double m_mu;
     double mu_k;
     
     for(i = 0; i < ndocs; i++)
     {
          for(k = 0; k < model->k; k++)
          {
               m_mu = mget(m_est->mu, i, k);
               mu_k = (vget(model->alpha, k) + cts->TK[i][k])
               /(model->alphaSum + cts->sumT[i]);
               m_mu = (m_mu*(n-1) + mu_k)/n;
               mset(m_est->mu, i, k, m_mu);
          }
     }
}

static void compute_mean_nu(Estimator* m_est, Cts* cts, Model* model, Corpus* c, int n)
{
     int i, j, k;
     double m_nu;
     double mu_k;
     double new_nu;
     
     for(i = 0; i < c->ndocs; i++)
     {
          double b = vget(cts->B, i);
          for(j = 0; j < c->docs[i].nparas; j++)
          {
               for(k = 0; k < model->k; k++)
               {
                    m_nu = mget(m_est->nu[i], j, k);
                    mu_k = (vget(model->alpha, k) + cts->TK[i][k])
                    /(model->alphaSum + cts->sumT[i]);
                    new_nu = (cts->n[i][j][k] - cts->t[i][j][k]*model->a
                              + (cts->TJ[i][j]*model->a + b)*mu_k)
                    /(b + c->docs[i].paras[j].total);
                    m_nu = (m_nu*(n-1) + new_nu)/n;
                    mset(m_est->nu[i], j, k, m_nu);
               }
          }
     }
}
/*
 * Gibbs sampling iterations for STM
 *
 */
static void stm_gibbs(Model* model, Cts* cts, int*** ass,
                      Corpus* c, vocabulary* v, char* root, int doOpt)
{
     int ite;
     int samples;
     clock_t t1, t2;
     double log_lihood;
     char str[BUFSIZ];
     
     char broot[BUFSIZ];
     sprintf(broot, "%s/trainb", root);
     mkdir(broot, S_IRUSR|S_IWUSR|S_IXUSR);
     
     Estimator* mEst = new_estimator(c, model->k, v->size, 1, 1, 1);
     
     printf("Begin gibbs sampling for STM ...\n");
     
     samples = 0;
     for(ite = 1; ite <= PARAMS.gibbs_max_iter; ite++)
     {
          t1 = clock();
          stm_gibbs_sampling(model, cts, ass, c, 0);
          t2 = clock();
          printf(">>> running time for %d-iteration: %lf\n",  ite, 
                 1000*(double)(t2-t1)/CLOCKS_PER_SEC);
          log_lihood = model_log_lihood(c, cts, model);
          printf("++++++++++ STM model log likelihood for iteration %d = %lf\n", ite, log_lihood);
                 
          if(doOpt == 1){
               ars_b(10, cts, model, c);
          }else if(doOpt == 2){
               printf("Old alpha = %lf -->", model->alphaSum/model->k);
               alpha_opt(cts, model, c);
               printf("New alpha = %lf\n", model->alphaSum/model->k);
          }else if(doOpt == 3){
               ars_b(10, cts, model, c);
               alpha_opt(cts, model, c);
          }
          
          if(ite > PARAMS.burn_in && ite % PARAMS.sampling_lag == 0)
          {
               samples++;
               compute_phi(cts, model);
               printf("****** save top words and trained model ******\n");
               sprintf(str, "%s/top_%d_words_%d.txt", root, PARAMS.top_words, ite);
               print_top_words(PARAMS.top_words, model->k, model->phi, v, str);
               sprintf(str, "%s/stm_%d", root, samples);
               mkdir(str, S_IRUSR|S_IWUSR|S_IXUSR);
               save_model(model, model->phi, str);
               /*
                  * compute mean
                  */
               compute_mean_mu(mEst, cts, model, c->ndocs, samples);
               compute_mean_nu(mEst, cts, model, c, samples);
               compute_mean_phi(mEst->phi, model, samples);
               
               saveb(cts, broot, ite);
          }
     }
     /*
      * save averaged model
      */
     sprintf(str, "%s/stm_final", root);
     mkdir(str, S_IRUSR|S_IWUSR|S_IXUSR);
     save_model(model, mEst->phi, str);
     printf_estimator(mEst, c, str, 1, 1, 0);
     sprintf(str, "%s/top_%d_words_final.txt", root, PARAMS.top_words);
     print_top_words(PARAMS.top_words, model->k, mEst->phi, v, str);
     
     sprintf(str, "%s/estimator", root);
     mkdir(str, S_IRUSR|S_IWUSR|S_IXUSR);
     save_estimator(mEst, c, str, 1, 1, 0);
     
     free_estimator(mEst, c, 1, 1, 1);
}

/*
 * Training the model
 */
void estimate(Corpus* c, vocabulary* v, char* root, int doOpt)
{
     Model* model;
     Cts* cts;
     int*** ass;
     char str[BUFSIZ];
     
     model = modelInitialize(PARAMS.k, v->size, PARAMS.alpha, PARAMS.gamma,
                             PARAMS.a, PARAMS.b);
     cts = new_cts(model->k, model->v, c, PARAMS.b);
     ass = new_assignment(c);
     initial_rng();
     init_state_gibbs(cts, ass, c, model);
     make_stirling_table(c->max_length, MAX_M, model->a);
     sprintf(str, "%s/initial", root);
     print_stirling_table(str);
     printf("*** Begin STM Gibbs Sampling ***\n");
     stm_gibbs(model, cts, ass, c, v, root, doOpt);
     printf("**** End STM Gibbs Sampling ***\n");
     free_stirling_table();
     free_rng();
     free_all(c, model, cts, ass, v);
}
/*
 * Gibbs sampleing for held-out inference of PLDA
 *
 */
static double heldout(Model* model, Corpus* c, char* mroot, int doOpt)
{
     int*** ass;
     Cts* cts;
     Corpus* c1;
     Corpus* c2;
     double perp;
     //	double log_lihood;
     double av_perp = 0;
     int samples = 0;
     
     c1 = (Corpus*)malloc(sizeof(Corpus));
     c2 = (Corpus*)malloc(sizeof(Corpus));
     split_corpus(c, c1, c2);
     
     ass = new_assignment(c1);
     cts = new_cts(model->k, model->v, c1, model->b);
     init_state_gibbs(cts, ass, c1, model);
     
     sprintf(mroot, "%s/testb", mroot);
     mkdir(mroot, S_IRUSR|S_IWUSR|S_IXUSR);
     
     int ite;
     for(ite = 1; ite <=PARAMS.gibbs_max_iter; ite++)
     {
          stm_gibbs_sampling(model, cts, ass, c1, 1);
          //		log_lihood = stm_model_log_lihood(c1, cts, model);
          //		printf("++++++++++++++++++++ STM INF model log_lihood = %lf\n", log_lihood);
          
          if(doOpt == 1 || doOpt == 3){
               ars_b(10, cts, model, c1);
          }
          if(ite > PARAMS.burn_in && ite % PARAMS.sampling_lag == 0){
               samples++;
               perp = heldout_perp(cts, c1, c2, model);
               av_perp = (av_perp*(samples - 1) + perp)/samples;
               
               saveb(cts, mroot, ite);
          }
     }
     
     free_cts(cts, c1, model->k);
     free_assignment(ass, c1);
     free_corpus(c1);
     free_corpus(c2);
     return av_perp;
}

/*
 * Gibbs sampling for STM left-to-right gibbs inference
 */
static double left2right(Model* t_model, Corpus* c, int samples)
{
     int i;
     double ll = 0;
     int k, words=0;
     
     for (i = 0; i < c->ndocs; i++)
     {
          for (k = 0; k < c->docs[i].nparas; k++)
          {
               words += c->docs[i].paras[k].total;
          }
          ll += gibbs_likelihood_stm(i, samples, t_model, &(c->docs[i]));
          if ( !gsl_finite(ll) ) {
               fprintf(stderr, "Infinite ll\n");
               exit(1);
          }
          //			fprintf(stderr,"PLDA gibbs LL = %lf / %d / %d\n", -ll/words, i+1, words);
          printf("PLDA gibbs LL = %lf / %d / %d\n", -ll/words, i+1, words);
     }
     return -ll/c->total;
}
/*
 * Testing the model
 */
void inference(Corpus* c, char* mroot, int h, int doOpt)
{
     Model* t_model;
     double perp;
     
     t_model = read_model(mroot);
     initial_rng();
     perp = 0;
     make_stirling_table(c->max_length, MAX_M, t_model->a);
     if (h) {
          printf("--- Begin STM held-out inference!!!\n");
          perp = heldout(t_model, c, mroot, doOpt);
          printf(">>>>>>>>>>>>>held-out PLDA Perplexity: %lf\n", perp);
     }else{
          printf("--- Begin STM left-to-right inference!!!\n");
          perp = left2right(t_model, c, SAMPLES);
          printf(">>>>>>>>>>>>>letf-to-right STM Perplexity: %lf\n", perp);
     }
     printf(">>>>>>>>>>>>>Exp-perplexity: %lf\n", gsl_sf_exp(perp));
     free_stirling_table();
     free_corpus(c);
     free_model(t_model);
     free_rng();
}
