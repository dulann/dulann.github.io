/*
 * params.c
 *
 * Copyright (C) 2010 Lan Du
 * All rights reserved.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * Author: Lan Du (Lan.Du@nicta.com.au)
 *
 */
#include <stdio.h>

#include "params.h"

stm_params PARAMS;

void read_params(char* filename) {
	FILE* fileptr;
	int tmp;

	fileptr = fopen(filename, "r");
	tmp = fscanf(fileptr, "k %d\n", &(PARAMS.k));
	tmp = fscanf(fileptr, "a %lf\n", &(PARAMS.a));
	tmp = fscanf(fileptr, "b %lf\n", &(PARAMS.b));
	tmp = fscanf(fileptr, "alpha %lf\n", &(PARAMS.alpha));
	tmp = fscanf(fileptr, "gamma %lf\n", &(PARAMS.gamma));
	tmp = fscanf(fileptr, "gibbs max iter %d\n", &(PARAMS.gibbs_max_iter));
	tmp = fscanf(fileptr, "burn in %d\n", &(PARAMS.burn_in));
	tmp = fscanf(fileptr, "sampling lag %d\n", &(PARAMS.sampling_lag));
	tmp = fscanf(fileptr, "top words %d\n", &(PARAMS.top_words));
	fclose(fileptr);
}

void write_params(char* filename) {
	FILE* fileptr;
	fileptr = fopen(filename, "w");
	fprintf(fileptr, "k %d\n", PARAMS.k);
	fprintf(fileptr, "a %lf\n", PARAMS.a);
	fprintf(fileptr, "b %lf\n", PARAMS.b);
	fprintf(fileptr, "alpha %lf\n", PARAMS.alpha);
	fprintf(fileptr, "gamma %lf\n", PARAMS.gamma);
	fprintf(fileptr, "gibbs max iter %d\n", PARAMS.gibbs_max_iter);
	fprintf(fileptr, "burn in %d\n", PARAMS.burn_in);
	fprintf(fileptr, "sampling lag %d\n", PARAMS.sampling_lag);
	fprintf(fileptr, "top words %d\n", PARAMS.top_words);
	fclose(fileptr);
}

void print_params() {
	printf(">>>>>> parameters <<<<<<\n");
	printf("k %d\n", PARAMS.k);
	printf("a %lf\n", PARAMS.a);
	printf("b %lf\n", PARAMS.b);
	printf("alpha %.3f\n", PARAMS.alpha);
	printf("gamma %.3f\n", PARAMS.gamma);
	printf("gibbs max iter %d\n", PARAMS.gibbs_max_iter);
	printf("burn in %d\n", PARAMS.burn_in);
	printf("sampling lag %d\n", PARAMS.sampling_lag);
	printf("top words %d\n", PARAMS.top_words);
	printf(">>>>>> parameters <<<<<<\n");
}

void set_paras(int k, double a, double b, double alpha, double gamma,
		int gibbs_max_iter, int burn_in, int sampling_lag, int top_words)
{
	PARAMS.k = k;
	PARAMS.a = a;
	PARAMS.b = b;
	PARAMS.alpha = alpha;
	PARAMS.gamma = gamma;
	PARAMS.gibbs_max_iter = gibbs_max_iter;
	PARAMS.burn_in = burn_in;
	PARAMS.sampling_lag = sampling_lag;
	PARAMS.top_words = top_words;
}
