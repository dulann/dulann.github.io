/*
 * Corpus processing utility
 * Copyright (C) 2012 Lan Du
 * All rights reserved.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * Author: Lan Du (Lan.Du@mq.edu.au)
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "corpus.h"

Corpus* read_data(const char* file)
{
	FILE* fileptr;
	Corpus* c;
	int j, l, ndocs, nparas, nwords;
	int word;
	int wtotal = 0;
	int ptotal = 0;
	int max_length = 0;
	int tmp;

	printf("reading data from %s\n", file);

	c = (Corpus*) malloc(sizeof(Corpus));
	fileptr = fopen(file, "r");
	ndocs = 0;
	c->docs = (doc*) malloc(sizeof(doc) * 1);
	while ((fscanf(fileptr, "doc:%d\n", &nparas) != EOF))
	{
		c->docs = (doc*) realloc(c->docs, sizeof(doc) * (ndocs + 1));
		doc* d = &(c->docs[ndocs]);
		d->total = 0;
		d->nparas = nparas;
		d->paras = (para*) malloc(sizeof(para) * nparas);

		for (j = 0; j < nparas; j++)
		{
			tmp = fscanf(fileptr, "para:%d\n", &nwords);
			para* p = &(d->paras[j]);
			p->total = nwords;

			if(nwords > max_length){
				max_length = nwords;
			}

			p->words = malloc(sizeof(int) * nwords);
			for (l = 0; l < nwords; l++)
			{
				tmp = fscanf(fileptr, "word:%d\n", &word);
				p->words[l] = word;
			}
			d->total += nwords;
			ptotal += 1;
		}
		wtotal += d->total;
		ndocs++;
	}
	fclose(fileptr);
	c->ndocs = ndocs;
	c->total = wtotal;
	c->max_length = max_length;

	printf("\n>>>>>>statistic for loaded corpus <<<<<<\n");
	printf("number of docs           : %d\n", ndocs);
	printf("para total               : %d\n", ptotal);
	printf("word total               : %d\n", wtotal);
	printf("max length               : %d\n", max_length);
	printf(">>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<\n");

	return (c);
}


/*
 * write a corpus to file
 *
 */

void write_corpus(Corpus* c, char* filename)
{
	FILE* fileptr;
	int i, j, k;
	doc* d;
	para* p;
	fileptr = fopen(filename, "w");
	for (i = 0; i < c->ndocs; i++)
	{
		d = &(c->docs[i]);
		fprintf(fileptr, "doc:%d\n", d->nparas);
		for (j = 0; j < d->nparas; j++)
		{
			p = &(d->paras[j]);
			fprintf(fileptr, "para:%d\n", p->total);
			for (k = 0; k < p->total; k++)
			{
				fprintf(fileptr, "word:%d\n", p->words[k]);
			}
		}
	}
	fclose(fileptr);
}

/*
 *
 */
void split_corpus(Corpus* s, Corpus* c1, Corpus* c2)
{
	int i, j, l;

	c1->docs = (doc*)malloc(sizeof(doc)*s->ndocs);
	c1->ndocs = s->ndocs;
	c1->total = 0;
	c1->max_length = 0;

	c2->docs = (doc*)malloc(sizeof(doc)*s->ndocs);
	c2->ndocs = s->ndocs;
	c2->total = 0;
	c2->max_length = 0;

	for(i = 0; i < s->ndocs; i++)
	{
		c1->docs[i].paras = (para*)malloc(sizeof(para)*s->docs[i].nparas);
		c1->docs[i].nparas = s->docs[i].nparas;
		c1->docs[i].total = 0;

		c2->docs[i].paras = (para*)malloc(sizeof(para)*s->docs[i].nparas);
		c2->docs[i].nparas = s->docs[i].nparas;
		c2->docs[i].total = 0;

		for(j = 0; j < s->docs[i].nparas; j++)
		{
			c1->docs[i].paras[j].words = malloc(sizeof(int) * 1);
			c1->docs[i].paras[j].total = 0;

			c2->docs[i].paras[j].words = malloc(sizeof(int) * 1);
			c2->docs[i].paras[j].total = 0;
			for(l = 0; l < s->docs[i].paras[j].total; l++)
			{
				if(l%2 == 0){
					c1->docs[i].paras[j].words = realloc(c1->docs[i].paras[j].words, sizeof(int) * (c1->docs[i].paras[j].total + 1));
					c1->docs[i].paras[j].words[c1->docs[i].paras[j].total] = s->docs[i].paras[j].words[l];
					c1->docs[i].paras[j].total++;
				}else if(l%2 == 1){
					c2->docs[i].paras[j].words = realloc(c2->docs[i].paras[j].words, sizeof(int) * (c2->docs[i].paras[j].total + 1));
					c2->docs[i].paras[j].words[c2->docs[i].paras[j].total] = s->docs[i].paras[j].words[l];
					c2->docs[i].paras[j].total++;
				}
			}
			if(c1->max_length < c1->docs[i].paras[j].total ){
				c1->max_length = c1->docs[i].paras[j].total;
			}
			c1->docs[i].total += c1->docs[i].paras[j].total;

			if(c2->max_length < c2->docs[i].paras[j].total ){
				c2->max_length = c2->docs[i].paras[j].total ;
			}
			c2->docs[i].total += c2->docs[i].paras[j].total;
		}
		c1->total += c1->docs[i].total;
		c2->total += c2->docs[i].total;
	}
}

/*
 * create word_map which map the term in vocabulary to index
 *
 * file: the file contains the corpus vocabulary in the format: index:word_string
 */
vocabulary* read_vocabulary(char* file)
{
	char word_str[BUFSIZ];
	int word_index, count;
	FILE* fileptr;
	vocabulary* v;

	printf("Reading vocabulary ...\n");
	v = (vocabulary*) malloc(sizeof(vocabulary));
	fileptr = fopen(file, "r");
	count = 0;
	v->word_map = (id_2_word*) malloc(sizeof(id_2_word) * 1);
	while ((fscanf(fileptr, "%d:%s", &word_index, word_str)) != EOF)
	{
		v->word_map = (id_2_word*) realloc(v->word_map, sizeof(id_2_word) * (1 + count));
		v->word_map[count].id = word_index;
		strcpy(v->word_map[count].word_str, word_str);
		assert(count == word_index);
		count++;
	}
	fclose(fileptr);
	v->size = count;
	printf("the size of the vocabulary: %d\n", count);
	return (v);
}

/*
 * write vocabulary to a file, be used in test
 *
 * v:  vocabulary
 * vocabulary_file: file to write v
 */
void write_vocabulary(vocabulary* v, char* file)
{
	FILE* fileptr;
	int i;

	fileptr = fopen(file, "w");
	for (i = 0; i < v->size; i++)
	{
		fprintf(fileptr, "%d:%s\n", v->word_map[i].id, v->word_map[i].word_str);
	}
	fclose(fileptr);
}

void free_corpus(Corpus* c){
	int i, j;
	for (i = 0; i < c->ndocs; i++)
	{
		for (j = 0; j < c->docs[i].nparas; j++)
		{
			free(c->docs[i].paras[j].words);
		}
		free(c->docs[i].paras);
	}
	free(c->docs);
	free(c);
}

void free_vocabulary(vocabulary* v){
	free(v->word_map);
	free(v);
}
