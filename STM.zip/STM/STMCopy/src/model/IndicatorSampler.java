package model;

import java.io.Serializable;

import states.Parameters;
import util.MTRandom;
import util.SpecialFuns;
import util.StirNum;
import data.Corpus;

/**
 * 
 * @author Du Lan
 * @version 2013-3-13-v1
 */
public class IndicatorSampler extends TopicSampler implements Serializable{
	//Serialization
	private static final long serialVersionUID = 1L;
	//Class variables
	private double[] indOneProbs;
	private int tmpn, tmpt;

	public IndicatorSampler (Corpus corpus,
							 Parameters modelParams)
	{
		super(corpus, modelParams);
		indOneProbs = new double[modelParams.numTopics()];
		if(Parameters.debug)
			System.out.println("\nRun indicator sampling algorithm!!!\n");
	}
	
	/**
	 * Jointly sample topic and table indicator, and
	 * return the sample topic.
	 * 
	 * @param i
	 * @param j
	 * @param w
	 * @param k
	 * @return
	 */
	protected int sample(final int i, final int j, final int w, int k){
		double phi;
		int indicator = 0;
		//Uniform distribution is used
		double indProb = (double) stables.TIJK[i][j][k]/stables.NIJK[i][j][k];
		if(indProb > MTRandom.nextDouble())
			indicator = 1;
		/*
		 * Note 1) if NIJK == 1, TIJK == 1, and indicator = 1;
		 * 		2) if TIJK > 1, NIJK > 1
		 */
		if(stables.NIJK[i][j][k] == 1 || stables.TIJK[i][j][k] > 1 || indicator == 0){
			if(indicator == 1) 
				stables.adjustTable(i, j, k, -1);
			stables.adjustCust(i, j, w, k, -1);
			for(k = 0; k < modelParams.numTopics(); k++){
				if(modelParams.isPhiGiven())
					phi = modelParams.getPhi(k, w);
				else
					phi = (modelParams.getGamma(w) + stables.MKW[k][w])
							/(modelParams.getGammaSum() + stables.MK[k]);
				
				indOneProbs[k] = probIndOne(i, j, w, k, phi);
				topicProbs[k] = indOneProbs[k];
				if(stables.TIJK[i][j][k] > 0)
					topicProbs[k] += probIndZero(i, j, w, k, phi);
			}
			k = this.nextDiscrete(topicProbs);
			indProb = indOneProbs[k] / topicProbs[k];			
			if (indProb > MTRandom.nextDouble())
				stables.adjustTable(i, j, k, 1);
			stables.adjustCust(i, j, w, k, 1);
			return k;
		}else{
			return -1;
		}
	}
	
	/**
	 * Return the joint probablity of increasing both NIJK and TIJK 
	 * by one.
	 * @param i document index
	 * @param j text passage index
	 * @param w word index
	 * @param k topic index
	 * @param phi pre-computed phi value
	 * @return
	 */
	private double probIndOne(final int i, final int j, final int w, 
							  final int k, double val) 
	{
		tmpn = stables.NIJK[i][j][k];
		tmpt = stables.TIJK[i][j][k];
		val *= (Math.exp(StirNum.logSN(tmpn + 1, tmpt + 1) - StirNum.logSN(tmpn, tmpt))
				*(modelParams.getAlpha(k) + stables.TIK[i][k])
					*(modelParams.getb(i) + modelParams.geta()*stables.TIJ[i][j])
					*(tmpt + 1.0))
				/((modelParams.getAlphaSum() + stables.TI[i])
				 	*(modelParams.getb(i) + stables.NIJ[i][j])
				 	*(tmpn + 1.0));
		if(!SpecialFuns.isnormal(val) || val < 0)
			throw new RuntimeException("Illegal probability of ind = 1!!!");
		return val;
	}
//	cache.getCacheOne(stables.NIJK[i][j][k], stables.TIJK[i][j][k])
	
	/**
	 * Return the joint probability of increaing NIJK by one
	 * and keeping TIJK unchanged.
	 * @param i document index
	 * @param j text passage index
	 * @param w word index
	 * @param k topic index
	 * @param val pre-computed phi value
	 * @return
	 */
	private double probIndZero(final int i, final int j, final int w, 
							   final int k, double val)
	{
		tmpn = stables.NIJK[i][j][k];
		tmpt = stables.TIJK[i][j][k];
		
		val *= (Math.exp(StirNum.logSN(tmpn + 1, tmpt) - StirNum.logSN(tmpn, tmpt))
				*(tmpn - tmpt + 1.0))
				/ ((tmpn + 1.0)*
					(modelParams.getb(i) + stables.NIJ[i][j]));
		if(!SpecialFuns.isnormal(val) || val < 0)
			throw new RuntimeException("Illegal probability of ind = 0!!!");
		return val;
	}
//	cache.getCacheTwo(stables.NIJK[i][j][k], stables.TIJK[i][j][k]) 
	
	/**
	 * Return the minus log of joint posterior of the model.
	 */
	public double logLikelihood() {
		double logLikelihood = globalLLL();
		for (int i = 0; i < corpus.numDocs(); i++) {
			logLikelihood += SpecialFuns.logGamma(modelParams.getAlphaSum())
								- SpecialFuns.logGamma(modelParams.getAlphaSum() + stables.TI[i]);
			for (int k = 0; k < modelParams.numTopics(); k++)
				logLikelihood += SpecialFuns.logGamma(modelParams.getAlpha(k) + stables.TIK[i][k])
				 				 	- SpecialFuns.logGamma(modelParams.getAlpha(k));
			for (int j = 0; j < corpus.getDoc(i).numTPs(); j++) {	
				logLikelihood += SpecialFuns.logPochSym(modelParams.getb(i), modelParams.geta(), 
														stables.TIJ[i][j])
									- SpecialFuns.logPochSym(modelParams.getb(i), 1.0, stables.NIJ[i][j]);
				for (int k = 0; k < modelParams.numTopics(); k++)
					logLikelihood += StirNum.logSN(stables.NIJK[i][j][k], stables.TIJK[i][j][k])
									- SpecialFuns.logChoose(stables.NIJK[i][j][k], stables.TIJK[i][j][k]);
			}
		}
		logLikelihood /= - corpus.numWords();
		if (!SpecialFuns.isnormal(logLikelihood)) 
			throw new RuntimeException("Table indicator sampler has illegal log model likelihood.");
		return logLikelihood;
	}
}
