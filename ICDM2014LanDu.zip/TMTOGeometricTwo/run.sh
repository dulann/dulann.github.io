#!/bin/bash

CLASSPATH="./libs/commons-cli-1.2.jar:./libs/commons-lang-2.6.jar:./libs/commons-logging-1.1.1.jar"
CLASSPATH="${CLASSPATH}:./libs/trove-3.0.3.jar:./libs/commons-configuration-1.9.jar:./bin"

# the configuration file
CONFIG=./one.config

# the number of topics
K=10

# The start index of Markov Chains
IDX=2

#document length model
DOC=$1

#segment length model
SEG=$2

# Beta parameter in Geometric distribuion on doc lenghts
DOCETA=1.0

# Beta parameter in Geometric distribuion on section lenghts
SEGETA=1.0

# lambda parameter in Poisson distribuion on doc lenghts
DOCLAMBDA=1.0

# lambda parameter in Poisson distribuion on doc lenghts
SEGLAMBDA=1.0

VERB=5000

# File to save the log file
ROOT="./results"
if [ $DOC -eq 1 ]; then
    ROOT="${ROOT}/geo"
else
    ROOT="${ROOT}/poiss"
fi

if [ $SEG -eq 1 ]; then
    ROOT="${ROOT}-geo"
elif [ $SEG -eq 2 ]; then
    ROOT="${ROOT}-poiss"
else
    ROOT="${ROOT}-poiss-k"
fi
ROOT="$ROOT/k-$K"

mkdir -p $ROOT
#
#Run the experiment with different number of topics
#
CMD="java -ea -Xmx1g -cp ${CLASSPATH} TMTOGeometric"
CMD="$CMD -config $CONFIG -root $ROOT -k ${K}"
CMD="$CMD -gmm 0"
CMD="$CMD -doc ${DOC} -seg $SEG"
if [ $DOC -eq 1 ]; then
    CMD="$CMD -docEta ${DOCETA}"
else
    CMD="$CMD -docLambda ${DOCLAMBDA} -ds"
fi

if [ $SEG -eq 1 ]; then
    CMD="$CMD -segEta ${SEGETA}"
else
    CMD="$CMD -segLambda ${SEGLAMBDA} -ss"
fi

CMD="$CMD -anneal -r ${IDX}"
CMD="$CMD -verbose ${VERB} -debug"
$CMD # >${ROOT}/k-${K}-r-${IDX}.log
