package data;
import java.io.*;
import java.util.ArrayList;

/**
 * 
 * @author Lan Du
 * @since 30-May-2013
 */
public class Vocabulary {

	private ArrayList<String> types;
	private int size;
	
	/**
	 * Create an empty vocabulary.
	 */
	public Vocabulary() {
		types = new ArrayList<String>();
	}
	
	public Vocabulary(String file) {
		this();
		this.read(file);
	}

	/**
	 * 
	 * @return the size of the vocabulary.
	 */
	public int size() {
		return size;
	}

	/**
	 * Return the type index in vocabulary
	 * 
	 * @param type
	 *            token type
	 * @return
	 */
	public int getIndex(String type) {
		return types.indexOf(type);
	}

	/**
	 * Return the type string.
	 * 
	 * @param index
	 *            the type index
	 * @return
	 */
	public String getType(int index) {
		return types.get(index);
	}

	/**
	 * Read vocabulary from a given file with the following format:
	 * "int,String", the former is word index, and the later is word type
	 * string.
	 * 
	 * @param vocFile
	 *            the file from which the vocabulary is loaded.
	 */
	public void read(String vocFile) {
		try{
			InputStreamReader isr = new InputStreamReader(new FileInputStream(vocFile), "UTF-8");
			BufferedReader fileReader = new BufferedReader(isr);
			String line;
			while ( (line = fileReader.readLine()) != null) {
				String[] strs = line.split(",");
				if(strs.length == 2)
					types.add(strs[1]);
				else if(strs.length == 1)
					types.add(strs[0]);
				else {
						fileReader.close();
						throw new RuntimeException("Illegal format in vocabulary file!!!");
					}
			}
			fileReader.close();
			size = types.size();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	/**
	 * Write vocabulary into a file with the following format "int,String", in
	 * which the former is word index, the later is the word type string.
	 * 
	 * @param out
	 *            the output file where to write the vocabulary
	 * @throws IOException
	 */
	public void write(String out) {
		try{ 
			OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream(out), "UTF-8");
			BufferedWriter bwriter = new BufferedWriter(osw);
			for(int i = 0; i < types.size(); i++)
				bwriter.write(i + "," + types.get(i) + "\n");
			bwriter.flush();
			bwriter.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
}
