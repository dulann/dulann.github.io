package data;
import gnu.trove.list.array.TIntArrayList;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

import utils.StopWordList;

/**
 * 
 * @author Lan Du
 * @since 30-May-2013
 */
public class Corpus {

	private final String folder;
	private final String dataSetName;
	private Vocabulary voc;
	private final int numDocs;

	private TIntArrayList sentCounts;
	private ArrayList<String> topicList; //true topic list
	private int[][] goldSegs;
	private int[][] goldOrderings; //true topic ordering
	private String[][] segmentTitles;
	private int[][][] types;
	private int[][][] typeCounts;
	private TIntArrayList illegalDocs; //documents with repeated topics.

	/**
	 * Create a new Corpus instance from a given dataset folder.
	 * 
	 * @param folder
	 *            Directory where data set is stored
	 * @param dataSetName
	 *            Name of the data set.
	 * @param voc
	 *            Vocabulary
	 * @param stopWords
	 *            Stop-word list
	 */
	public Corpus(String folder, String dataSetName, Vocabulary voc, StopWordList stopWords) {
		this.folder = folder;
		this.dataSetName = dataSetName;
		this.voc = voc;
		// Read text passage count for each doc
		sentCounts = new TIntArrayList();
		this.readMetaInfo();
		numDocs = sentCounts.size();
		// Read gold segmentation;
		goldSegs = new int[numDocs][];
		segmentTitles = new String[numDocs][];
		for (int i = 0; i < numDocs; i++) {
			int np = sentCounts.get(i);
			goldSegs[i] = new int[np];
			Arrays.fill(goldSegs[i], 0);
			segmentTitles[i] = new String[np];
		}
		this.readSegmentTitles();
		// Load data
		types = new int[numDocs][][];
		typeCounts = new int[numDocs][][];
		for (int i = 0; i < numDocs; i++) {
			int np = sentCounts.get(i);
			types[i] = new int[np][];
			typeCounts[i] = new int[np][];
		}
		if(stopWords == null) this.readData();
		else this.readData(stopWords);
		// Generate true topic orderings of documents
		topicList = new ArrayList<String>();
		this.generateTrueTopicList();
		goldOrderings = new int[numDocs][];
		illegalDocs = new TIntArrayList();
		this.generateTrueOrdering();
	}
	
	/**
	 * Return the gold standard topic ordering for a document.
	 * 
	 * @param d
	 * @return
	 */
	public int[] getGoldOrdering(int d) {
		return goldOrderings[d];
	}
	
	/**
	 * Return the segmentation of whole corpus.
	 * 
	 * @return
	 */
	public int[][] getGoldSeg() {
		return goldSegs;
	}
	
	/**
	 * Return the gold segmentation of a given document.
	 * 
	 * @param d
	 *            document index
	 * @return
	 */
	public int[] getGoldSeg(int d) {
		return goldSegs[d];
	}
	
	/**
	 * Return the total number of segments in gold standard segmentation.
	 * 
	 * @return
	 */
	public int totalGoldSegs() {
		int total = 0;
		for(int i = 0; i < goldSegs.length; i++) 
				total += goldSegs[i][goldSegs[i].length-1]+1;
		return total;
	}
	
	/**
	 * Return the average number of true segments per document.
	 * 
	 * @return
	 */
	public int aveSegsInt() {
		return Math.round((float)totalGoldSegs()/numDocs);
	}
	
	public double aveSegsDouble() {
		return (double)totalGoldSegs()/numDocs;
	}
	
	/**
	 * Maximum number of text passages of gold segments.
	 * 
	 * @return
	 */
	public int maxSegLen() {
		int max = Integer.MIN_VALUE;
		int spanLength, start, numSents;
		for(int i = 0; i < goldSegs.length; i++) {
			start = 0;
			numSents = goldSegs[i].length;
			while(start < numSents){
				for (spanLength = 1; start + spanLength < numSents 
						&& goldSegs[i][start + spanLength] == goldSegs[i][start]; 
						spanLength++) {}
				if(spanLength > max)
					max = spanLength;
				start += spanLength;
			}
		}
		return max;
	}
	
	/**
	 * Minimum number of text passages of gold segments.
	 * 
	 * @return
	 */
	public int minSegLen() {
		int min = Integer.MAX_VALUE;
		int spanLength, start, numSents;
		for(int i = 0; i < goldSegs.length; i++) {
			start = 0;
			numSents = goldSegs[i].length;
			while(start < numSents){
				for (spanLength = 1; start + spanLength < numSents 
						&& goldSegs[i][start + spanLength] == goldSegs[i][start]; 
						spanLength++) {}
				if(spanLength < min)
					min = spanLength;
				start += spanLength;
			}
		}
		return min;
	}
	
	/**
	 * Return the maximum doc length in terms of number of
	 * text passages.
	 * 
	 * @return
	 */
	public int maxDocLenSent() {
		int max = Integer.MIN_VALUE;
		for(int i = 0; i < sentCounts.size(); i++) {
			if(sentCounts.get(i) > max)
				max = sentCounts.get(i);
		}
		return max;
	}
	
	/**
	 * Return the minimum doc length in terms of number of
	 * text passages.
	 * 
	 * @return
	 */
	public int minDocLenSent() {
		int min = Integer.MAX_VALUE;
		for(int i = 0; i < sentCounts.size(); i++) {
			if(sentCounts.get(i) < min)
				min = sentCounts.get(i);
		}
		return min;
	}
	
	/**
	 * Return the max document length in terms of segs.
	 * @return
	 */
	public int maxDocLenSeg() {
		int max = Integer.MIN_VALUE;
		for(int i = 0; i < goldSegs.length; i++) {
			int length = goldSegs[i][goldSegs[i].length-1]+1;
			if(length > max)
				max = length;
		}
		return max;
	}
	
	/**
	 * Return the min document length in terms of segs.
	 * @return
	 */
	public int minDocLenSeg() {
		int min = Integer.MAX_VALUE;
		for(int i = 0; i < goldSegs.length; i++) {
			int length = goldSegs[i][goldSegs[i].length-1]+1;
			if(length < min)
				min = length;
		}
		return min;
	}
	
	/**
	 * Return all the segment titles for each document.
	 * 
	 * @return
	 */
	public String[][] segmentTitles() {
		return segmentTitles;
	}
	
	/**
	 * Return false if segment's topic is repeated.
	 * 
	 * @param i
	 * @return
	 */
	public boolean isIllegalDoc(int i) {
		if(illegalDocs.isEmpty())
			return false;
		return illegalDocs.contains(i);
	}

	/**
	 * Return a String list of true topics.
	 * 
	 * @return
	 */
	public ArrayList<String> trueTopics() {
		return topicList;
	}
	
	/**
	 * Return the total number of documents.
	 * 
	 * @return
	 */
	public int numDocs() {
		return numDocs;
	}

	/**
	 * Return the total number of text passage in corpus.
	 * 
	 * @return
	 */
	public int numSents() {
		int totalSents = 0;
		for(int i = 0; i < sentCounts.size(); i++)
			totalSents += sentCounts.get(i);
		return totalSents;
	}

	/**
	 * Return the total number of word tokens in corpus
	 * @return
	 */
	public int numTokens() {
		int totalTokens = 0;
		for(int d = 0; d < typeCounts.length; d++) {
			for(int s = 0; s < typeCounts[d].length; s++) {
				for(int n = 0; n < typeCounts[d][s].length; n++)
					totalTokens += typeCounts[d][s][n];
			}
		}
		return totalTokens;
	}
	
	/**
	 * Return the total number of word tokens in a document.
	 * 
	 * @return
	 */
	public int numTokens(int d) {
		int totalTokens = 0;
		for(int s = 0; s < typeCounts[d].length; s++) {
			for(int n = 0; n < typeCounts[d][s].length; n++)
				totalTokens += typeCounts[d][s][n];
		}
		return totalTokens;
	}

	/**
	 * Return the number of sentences in a document.
	 * 
	 * @param d
	 *            document index
	 * @return
	 */
	public int numSents(int d) {
		return sentCounts.get(d);
	}

	/**
	 * Return the number of types in a sentence.
	 * 
	 * @param d
	 *            document index
	 * @param s
	 *            sentence index
	 * @return
	 */
	public int numTypes(int d, int s) {
		return types[d][s].length;
	}
	
	/**
	 * Return a type.
	 * 
	 * @param d
	 *            document index
	 * @param s
	 *            sentence index
	 * @param n
	 *            type poistion
	 * @return
	 */
	public int type(int d, int s, int n) {
		return types[d][s][n];
	}
	
	/**
	 * Return the number of instances of a type in a sentence.
	 * 
	 * @param d
	 *            document index
	 * @param s
	 *            sentence index
	 * @param n
	 * 			  type position
	 * @return
	 */
	public int typeCount(int d, int s, int n) {
		return typeCounts[d][s][n];
	}

	/**
	 * Read meta data file that contains how many sentences in each document
	 * has.
	 */
	private void readMetaInfo() {
		String file = folder + File.separator + dataSetName + ".meta";
		System.out.println("Read "+file);
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			String str;
			while ((str = br.readLine()) != null)
				sentCounts.add(Integer.parseInt(str));
			br.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	/**
	 * Read segment titles and gold segmentations for all the documents.
	 */
	public void readSegmentTitles() {
		String file = folder + File.separator + dataSetName + ".segmenttitles";
		System.out.println("Read "+file);
		try {
			InputStreamReader isr = new InputStreamReader(new FileInputStream(file), "UTF-8");
			BufferedReader br = new BufferedReader(isr);
			String line, segTitle;
			for(int i = 0; i < sentCounts.size(); i++) {//for each document
				line = br.readLine();
				String[] strs = line.split(",");
				assert Integer.parseInt(strs[1]) == 1;
				segTitle = strs[2];
				int seg = 0;
				goldSegs[i][0] = seg;
				segmentTitles[i][0] = strs[2];
				for(int j = 1; j < sentCounts.get(i); j++) {//for each text passage
					line = br.readLine();
					strs = line.split(",");
					assert Integer.parseInt(strs[1]) == j+1;
					if(!strs[2].equals(segTitle)){
						seg++;
						segTitle = strs[2];
					}
					goldSegs[i][j] = seg;
					segmentTitles[i][j] = strs[2];
				}
			}
			br.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	/**
	 * Read data and exclude stop words.
	 * 
	 * @param stopWords
	 */
	private void readData(StopWordList stopWords) {
		String file = folder + File.separator + dataSetName + ".data";
		System.out.println("Read "+file);
		try {
			InputStreamReader isr = new InputStreamReader(new FileInputStream(file), "UTF-8");
			BufferedReader br = new BufferedReader(isr);
			for (int i = 0; i < sentCounts.size(); i++) {
				for (int j = 0; j < sentCounts.get(i); j++) {
					String[] strs = br.readLine().split(",");
					ArrayList<String> tmpList = new ArrayList<String>();
					for (int n = 0; n < strs.length; n++) {
						String[] kv = strs[n].split(":");
						assert kv.length == 2;
						if(!stopWords.contains(voc.getType(Integer.parseInt(kv[0]))))
							tmpList.add(strs[n]);
					}
					assert tmpList.size() > 0;
					types[i][j] = new int[tmpList.size()];
					typeCounts[i][j] = new int[tmpList.size()];
					for (int n = 0; n < tmpList.size(); n++) {
						String[] kv = tmpList.get(n).split(":");
						assert kv.length == 2;
						types[i][j][n] = Integer.parseInt(kv[0]);
						typeCounts[i][j][n] = Integer.parseInt(kv[1]);
					}
				}
			}
			br.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	/**
	 * Read documents store int the following format 1) each row corresponds to
	 * a text passage, e.g., paragraph or sentence. 2) each row consists of
	 * "int:int" separated by ",", in which the former is the word index the
	 * later is word count in the corresponding text passage
	 */
	private void readData() {
		String file = folder + File.separator + dataSetName + ".data";
		System.out.println("Read "+file);
		try {
			InputStreamReader isr = new InputStreamReader(new FileInputStream(file), "UTF-8");
			BufferedReader br = new BufferedReader(isr);
			for (int i = 0; i < sentCounts.size(); i++) {
				for (int j = 0; j < sentCounts.get(i); j++) {
					String[] strs = br.readLine().split(",");
					types[i][j] = new int[strs.length];
					typeCounts[i][j] = new int[strs.length];
					for (int n = 0; n < strs.length; n++) {
						String[] kv = strs[n].split(":");
						assert kv.length == 2;
						types[i][j][n] = Integer.parseInt(kv[0]);
						typeCounts[i][j][n] = Integer.parseInt(kv[1]);
					}
				}
			}
			br.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	/**
	 * Generate a list of true topics based on segment titles
	 */
	private void generateTrueTopicList() {
		for(int i = 0; i < segmentTitles.length; i++) 
			for(int j = 0; j < segmentTitles[i].length; j++) 
				if(!topicList.contains(segmentTitles[i][j]) || topicList.isEmpty())
					topicList.add(segmentTitles[i][j]);
	}
	
	/**
	 * Generate a list of true topic ordering. This function
	 * will also find a list of documents that have one topic
	 * repeats in two different segments.
	 * 
	 */
	private void generateTrueOrdering() {
		TIntArrayList pi = new TIntArrayList();
		for(int i = 0; i < segmentTitles.length; i++) {
			for(int j = 0; j < segmentTitles[i].length; j++) {
				int topic = topicList.indexOf(segmentTitles[i][j]);
				if(pi.isEmpty() || !pi.contains(topic))
					pi.add(topic);
			}
			if(pi.size() != goldSegs[i][goldSegs[i].length-1]+1)
				illegalDocs.add(i);
			goldOrderings[i] = pi.toArray();
			pi.clear();
		}
	}
	
	/**
	 * Save information of this corpus. Mainly for 
	 * debugging purpose.
	 * 
	 * @param dir
	 *            output file directory
	 */
	public void write(String dir) {
		try {
			// write meta information
			String file = dir + File.separator + dataSetName + ".meta";
			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			for (int i = 0; i < sentCounts.size(); i++)
				writer.write(sentCounts.get(i) + "\n");
			writer.flush();
			writer.close();
			// write gold standard segmentation
			file = dir + File.separator + dataSetName + ".goldSeg";
			writer = new BufferedWriter(new FileWriter(file));
			for (int i = 0; i < goldSegs.length; i++)
				for (int j = 0; j < goldSegs[i].length; j++) {
					if (j == goldSegs[i].length - 1)
						writer.write(goldSegs[i][j] + "\n");
					else
						writer.write(goldSegs[i][j] + ",");
				}
			writer.flush();
			writer.close();
			
			file = dir + File.separator + dataSetName + ".seg";
			writer = new BufferedWriter(new FileWriter(file));
			for (int i = 0; i < goldSegs.length; i++) {
				for (int j = 0; j < goldSegs[i].length-1; j++) {
					if (goldSegs[i][j] != goldSegs[i][j+1])
						writer.write(1+ ",");
					else
						writer.write(0+ ",");
				}
				writer.write(1+ "\n");
			}
			writer.flush();
			writer.close();
			// write segment titiles
			file = dir + File.separator + dataSetName + ".segmentTitles";
			OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
			writer = new BufferedWriter(osw);
			for(int i = 0; i < sentCounts.size(); i++) {
				for(int j = 0 ; j < sentCounts.get(i); j++) {
					writer.write((i+1)+","+(j+1)+","+segmentTitles[i][j]+"\n");
				}
			}
			writer.flush();
			writer.close();
			// write segment titiles and segmentation
			file = dir + File.separator + dataSetName + ".segmentation";
			osw = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
			writer = new BufferedWriter(osw);
			for(int i = 0; i < sentCounts.size(); i++) {
				for(int j = 0 ; j < sentCounts.get(i); j++) {
					writer.write((i+1)+","+(j+1)+","+goldSegs[i][j]+","+segmentTitles[i][j]+"\n");
				}
			}
			writer.flush();
			writer.close();
			// write data
			file = dir + File.separator + dataSetName + ".data";
			writer = new BufferedWriter(new FileWriter(file));
			for (int i = 0; i < types.length; i++) {
				for (int j = 0; j < types[i].length; j++) {
					for (int n = 0; n < types[i][j].length; n++) {
						if (n == types[i][j].length - 1)
							writer.write(types[i][j][n] + ":" + typeCounts[i][j][n] + "\n");
						else
							writer.write(types[i][j][n] + ":" + typeCounts[i][j][n] + ",");
					}
				}
			}
			writer.flush();
			writer.close();
			// write topic list
			file = dir + File.separator + dataSetName + ".topicList";
			osw = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
			writer = new BufferedWriter(osw);
			for(int i = 0; i < topicList.size(); i++)
				writer.write((i+1)+":"+topicList.get(i)+"\n");
			writer.flush();
			writer.close();
			// write illegal documents
			if(illegalDocs.size() > 0){
				file = dir + File.separator + dataSetName + ".illegalDocs";
				osw = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
				writer = new BufferedWriter(osw);
				for(int i = 0; i < illegalDocs.size(); i++)
					writer.write(illegalDocs.get(i)+"\n");
				writer.flush();
				writer.close();
			}
			// write gold topic ordering
			file = dir + File.separator + dataSetName + ".goldTopicOrdering";
			writer = new BufferedWriter(new FileWriter(file));
			for (int i = 0; i < goldOrderings.length; i++) {
				for (int j = 0; j < goldOrderings[i].length; j++) {
					if(j == goldOrderings[i].length-1)
						writer.write(goldOrderings[i][j]+"\n");
					else
						writer.write(goldOrderings[i][j]+",");
				}
			}
			writer.flush();
			writer.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
}
