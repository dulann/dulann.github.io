package data;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

import lan.Parameters;

public class CorpusStats {

	private Corpus corpus;
	
	public CorpusStats(Corpus corpus) {
		this.corpus = corpus;
	}
	
	public void topicLengthDistribution(String str) {
		String[][] segmentTitles = corpus.segmentTitles();
		int[][] goldSegs = corpus.getGoldSeg();
		ArrayList<String> topics = new ArrayList<String>();
		
		for(int i = 0; i < segmentTitles.length; i++) {
			for(int j = 0; j < segmentTitles[i].length; j++) {
				if(!topics.contains(segmentTitles[i][j]) || topics.isEmpty()) {
					topics.add(segmentTitles[i][j]);
				}
			}
		}
	
		int max = corpus.maxSegLen();
		if(Parameters.verbose > 10000) {
			System.out.println("topic size: "+ topics.size());
			System.out.println("topics: "+topics.toString());
			System.out.println("max tps per doc: "+max);
		}
		
		int[][] lengthFreqs = new int[topics.size()][max];
		for(int i = 0; i < topics.size(); i++)
			Arrays.fill(lengthFreqs[i], 0);
		int start, spanLength, numSents;
		for(int i = 0; i < goldSegs.length; i++) {
			start = 0;
			numSents = goldSegs[i].length;
			while(start < numSents){
				for (spanLength = 1; start + spanLength < numSents 
						&& goldSegs[i][start + spanLength] == goldSegs[i][start]; 
						spanLength++) {}
				lengthFreqs[topics.indexOf(segmentTitles[i][start])][spanLength-1]++;
				start += spanLength;
			}
		}
		int[] totalSum = new int[max];
		Arrays.fill(totalSum, 0);
		for(int i = 0; i < lengthFreqs.length; i++) {
			for(int j = 0; j < max; j++) {
				totalSum[j] += lengthFreqs[i][j];
			}
		}
		
		try{
			FileWriter fw = new FileWriter(str);
			for(int i = 0; i < topics.size(); i++){
				for(int j = 0; j < max; j++) {
					if(j < max-1){
						fw.write(lengthFreqs[i][j]+",");
					}else{
						fw.write(lengthFreqs[i][j]+"\n");
					}
				}
			}
			for(int j = 0; j < max; j++) {
				if(j < max-1){
					fw.write(totalSum[j]+",");
				}else{
					fw.write(totalSum[j]+"\n");
				}
			}
//			fw.write("\n");
//			for(int i = 0; i < topics.size(); i++) {
//				fw.write((i+1)+":"+topics.get(i)+"\n");
//			}
			fw.flush();
			fw.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
}
