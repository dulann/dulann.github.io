import java.io.*;

import lan.ModelSampler;
import lan.Parameters;

import org.apache.commons.cli.*;

import data.Corpus;
import data.Vocabulary;
import utils.StopWordList;


/**
 * 
 * @author Lan Du
 * @since 12-Jun-2013
 */
public class TMTOGeometric {
	
	public static void run(Parameters params) throws IOException {
		Vocabulary voc = new Vocabulary();
		voc.read(params.dataSetFolder+File.separator+params.dataName+".vocab");
		StopWordList stopWords = null;
		if(params.removeStopWords)
			stopWords = new StopWordList();
		Corpus corpus = new Corpus(params.dataSetFolder, params.dataName, voc, stopWords);
		System.out.println("Voc size: "+voc.size()
							+"\nnum Docs: "+corpus.numDocs()
							+"\npassage Total: "+corpus.numSents()
							+"\nword Total: " +corpus.numTokens()
							+"\nsegs Per Doc: "+corpus.aveSegsDouble()
							+"\ntotal GoldSegs: "+corpus.totalGoldSegs()
							+"\nmax DocLenPass: "+corpus.maxDocLenSent()+", min DocLenPass: "+corpus.minDocLenSent()
							+"\nmax DocLenSeg: "+corpus.maxDocLenSeg()+", min DocLenSeg: "+corpus.minDocLenSeg()
							+"\nmax SegLen: "+corpus.maxSegLen()+", min SegLen: "+corpus.minSegLen()
							+"\ntrue topics count: "+corpus.trueTopics().size());
		ModelSampler modelSampler = new ModelSampler(corpus, voc, params);
		modelSampler.sample();
	}

	private static Options buildOption() {
		Options options = new Options();
		options.addOption(new Option("h", "print the help message"));
		options.addOption(new Option("debug", false, "turn on debugging"));
		options.addOption(new Option("verbose", true, "the verbose level"));
		//commands for general settings
		options.addOption(new Option("k", true, "number of topics"));
		options.addOption(new Option("config", true, "the model configuration file"));
		options.addOption(new Option("stop", false, "Remove stop words"));
		options.addOption(new Option("root", true, "the root directory to save trained models"));
		//commands for the GMM
		options.addOption(new Option("gmm", true, "0: top-t model, 1: partial model"));
		options.addOption(new Option("theta", true, "dispersion parameter of the GMM"));
		//commands for document level model
		options.addOption(new Option("doc", true, "1: Geometric distribution; 2: Poisson distribution"));
		options.addOption(new Option("docEta", true, "Beta parameter in Geometric distribution on doc lengths"));
		options.addOption(new Option("docLambda", true, "Parameter in Poisson distribution on doc lengths"));
		options.addOption(new Option("ds", false, "Sample doc-level Poisson parameter from a Gamma distribution"));
		//commands for segment level model
		options.addOption(new Option("seg", true, "1: Geo; 2: Poiss, 3: PoissK"));
		options.addOption(new Option("segEta", true, "Beta parameter in Geometric distribution on seg lengths"));
		options.addOption(new Option("segLambda", true, "Parameter in Poisson distribution on seg lengths"));
		options.addOption(new Option("ss", false, "Sample seg-level Poisson parameter from a Gamma distribution"));
		//commands for SA and others
		options.addOption(new Option("anneal", false, "do simulated annealing"));
		options.addOption(new Option("r", true, "Markov Chain number"));
		options.addOption(new Option("n", true, "number of Markov Chains"));
		return options;
	}

	public static void main(String[] args) throws Exception {
		Options options = buildOption();
		CommandLineParser parser = new GnuParser();
		HelpFormatter formatter = new HelpFormatter();
		CommandLine line = null;
		try {
			line = parser.parse(options, args);
		} catch (ParseException exp) {
			System.err.println("Unexpected exception:" + exp.getMessage());
			formatter.printHelp("Partially Ranked Topic Model (PTM)", options);
			System.exit(1);
		}

		/*******************************************************************
		 *************Parse the command line arguments**********************
		 *******************************************************************/
		if (line.hasOption("h")) {
			formatter.printHelp("Partially Ranked Topic Model (PTM)", options);
			System.exit(0);
		}
		if(line.hasOption("debug")) {
			Parameters.debug = true;
		} 
		
		if(line.hasOption("verbose")) {
			Parameters.verbose = Integer.parseInt(line.getOptionValue("verbose"));
		}
		/*
		 * The number of topics to be learnt.
		 */
		int numTopics = 0;
		if(line.hasOption("k")) {
			numTopics = Integer.parseInt(line.getOptionValue("k"));
		} else {
			System.err.println("Missing \'-k\' to specify the number of topics!!!");
			System.exit(1);
		}
		/*
		 * The configuration file
		 */
		String configFile = null;
		if(line.hasOption("config")) {
			configFile = line.getOptionValue("config");
		} else {
			System.err.println("Missing \'-config\' to specify the configuration file!!!");
			System.exit(1);
		}
		Parameters params = new Parameters(numTopics, configFile);
		/*
		 * If removing stop words.
		 */
		if(line.hasOption("stop"))
			params.removeStopWords = true;
		else 
			params.removeStopWords = false;
		/*
		 * The folder where the output files will be stored.
		 */
		if(line.hasOption("root")) {
			params.outputDir = line.getOptionValue("root");
		} else {
			System.err.println("Missing \'-root\' to specify the root directory!!!");
			System.exit(1);
		}
		/*
		 * Specify the GMM
		 * 		0: top-t ordering
		 * 		1: partial ordering with instance learning.
		 */
		if(line.hasOption("gmm")) {
			Parameters.gmmModel = Integer.parseInt(line.getOptionValue("gmm"));
			assert Parameters.gmmModel == 0 || Parameters.gmmModel == 1;
		} 
		/*
		 * The dispersion parameter in the GMM. If it is not specified, 
		 * the default value will be theta_0.
		 */
		if(line.hasOption("theta")) {
			params.initTheta = Double.parseDouble(line.getOptionValue("theta"));
		} else {
			params.initTheta = params.theta_0;
			System.out.println("The initial theta will be equal to theat_0!!!");
		}
		
		/*
		 * Select document level models
		 */
		if(line.hasOption("doc")) {
			Parameters.docModel = Integer.parseInt(line.getOptionValue("doc"));
		}else{
			System.err.println("Missing \'-doc\' to specify the model on document length,\n\t"+
						"1: Geometric distribution \n\t 2: Poisson distribution!");
			System.exit(1);
		}
		if(Parameters.docModel == 1) {
			//Geometric distribution
			if(line.hasOption("docEta")) {
				params.docEta = Double.parseDouble(line.getOptionValue("docEta"));
			} else {
				System.err.println("Missing \'-docEta\' to specify Beta parameter!!!");
				System.exit(1);
			}
		} else if(Parameters.docModel == 2) {
			//Poisson distribution
			if(line.hasOption("docLambda")) {
				params.docLambda = Double.parseDouble(line.getOptionValue("docLambda"));
			} else {
				System.err.println("Missing \'-docEta\' to specify Beta parameter!!!");
				System.exit(1);
			}
			if(line.hasOption("ds")) {
				Parameters.optDocLambda = true;
			} else {
				Parameters.optDocLambda = false;
			}
		} else {
			System.err.println("Wrong values for  \'-doc\', which should be 1 or 2.");
			System.exit(1);
		}

		/*
		 * Select segment level model
		 */
		if(line.hasOption("seg")) {
			Parameters.segModel = Integer.parseInt(line.getOptionValue("seg"));
		}else{
			System.err.println("Missing \'-seg\' to specify segment level length model!!!");
			System.exit(1);
		}
		if(Parameters.segModel == 1) {
			//Geometric distribution on segment level
			if(line.hasOption("segEta")) {
				params.segEta = Double.parseDouble(line.getOptionValue("segEta"));
			} else {
				System.err.println("Missing \'-segEta\' to specify Beta parameter!!!");
				System.exit(1);
			}
		} else if(Parameters.segModel == 2 || Parameters.segModel == 3) {
			// Poisson distribution on segment level
			if(line.hasOption("segLambda")) {
				params.segLambda = Double.parseDouble(line.getOptionValue("segLambda"));
			} else {
				System.err.println("Missing \'-segLambda\' to specify Poisson parameter!!!");
				System.exit(1);
			}
			if(line.hasOption("ss")) {
				Parameters.optSegLambda = true;
			} else {
				Parameters.optSegLambda = false;
			}
		}  else {
			System.err.println("Wrong values for  \'-seg\', which shoule be in [1,3]!!!");
			System.exit(1);
		}
		
		/*
		 * If doing simulated annealing.
		 */
		if(line.hasOption("anneal")) {
			System.out.println("Do simulated annealing = true!!!");
			Parameters.anneal = true;
		} else {
			Parameters.anneal = false;
		}
		/*
		 * the total number of markov chains to run.
		 */
		int numMarkovChains = 1;
		if(line.hasOption("n")){
			numMarkovChains = Integer.parseInt(line.getOptionValue("n"));
		}
		System.out.println("The number of Markov Chains to run: "+numMarkovChains);
		/*
		 * the chain index
		 */
		int chainIdx = 1;
		if(line.hasOption("r")){
			chainIdx = Integer.parseInt(line.getOptionValue("r"));
		}
		System.out.println("Markov Chains number: "+chainIdx);
		
		if(numMarkovChains > 1) {
			for(int i = 0; i < numMarkovChains; i++) {
				params.createRoot(i+chainIdx);
				params.writeParameters();
				TMTOGeometric.run(params);
				System.gc();
			}
		} else {
			params.createRoot(chainIdx);
			params.writeParameters();
			TMTOGeometric.run(params);
			System.gc();
		}
	}
}
