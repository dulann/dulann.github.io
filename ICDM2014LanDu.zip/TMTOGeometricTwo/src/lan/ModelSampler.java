package lan;
import gmm.GMM;
import gmm.PartialModel;
import gmm.TopTModel;
import gnu.trove.list.array.*;

import java.io.*;
import java.util.Arrays;

import data.Corpus;
import data.Vocabulary;
import utils.MTRandom;
import lengthModels.DocLenGeoDist;
import lengthModels.DocLenPoissDist;
import lengthModels.SegLenGeoDist;
import lengthModels.SegLenPoisson;
import lengthModels.SegLenPoissonK;
import lengthModels.SegPoissonDist;


/**
 * 
 * @author Lan Du
 * @since 6-Jun-2013
 */
public class ModelSampler {
	private Corpus corpus;
	private Parameters params;
	private MTRandom rand;
	private BoundarySampler bsampler;
	private Evaluator eva;
	public static GMM gmm;
	public static DCM dcm;
	//segment level models
	public static SegPoissonDist segLenPoiss;
	public static SegLenGeoDist segLenGeoDist;
	//document level models
	public static DocLenGeoDist docLenGeoDist;
	public static DocLenPoissDist docLenPoissDist;
	//Simulated Annealing
	public static Annealer ann;
	/*
	 * Save topic segmentation in the format, for example
	 *      [0, 0, 0, 1, 1, 2, 2, 2, 2, 3]
	 * which has four segments.
	 */
	private int[][] segmentations;
	/*
	 * For debug
	 */
	int countSegs;
	//cache
	TIntArrayList sentIdx;

	public ModelSampler(Corpus corpus, Vocabulary voc, Parameters params) {
		this.corpus = corpus;
		this.params = params;
		segmentations = new int[corpus.numDocs()][];
		for(int d = 0; d < corpus.numDocs(); d++)
			segmentations[d] = new int[corpus.numSents(d)];
		rand = new MTRandom(params.seed);
		//Dirichlet Multinomial model
		dcm = new DCM(params.numTopics, voc, corpus, params.beta);
		//Generalised Mallows model
		if(Parameters.gmmModel == 0) {
			gmm = new TopTModel(params.numTopics, corpus.numDocs(), params.theta_0, params.s_0, rand);
			System.out.println("+++ Run GMM with top-t ordering +++");
		} else if(Parameters.gmmModel == 1) {
			gmm = new PartialModel(params.numTopics, corpus.numDocs(), params.theta_0, params.s_0, rand);
			System.out.println("+++ Run GMM with partial ordering, futher with instance learning +++");
		} else throw new RuntimeException("Parameters.gmmModel is not specified!!!");
		gmm.setThetas(params.initTheta); 
//		if(Parameters.debug)
//			System.out.println("Initial thetas: "+(new TDoubleArrayList(gmm.getThetas())).toString());
		//Boundary sampler
		bsampler = new BoundarySampler(rand, params.numTopics);
		//Model selection on segment lengths
		if(Parameters.segModel == 2 || Parameters.segModel == 3) {//Poisson distribution
			segLenGeoDist = null;
			if(Parameters.segModel == 2) {
				segLenPoiss = new SegLenPoisson(params.segLambda, rand);
				System.out.println("=== One Poisson distribution over segment lengths ===");
			}else {
				segLenPoiss = new SegLenPoissonK(params.segLambda, rand,  params.numTopics); 
				System.out.println("=== K Poisson distributions over segment lengths ===");
			}
		}else {
			segLenPoiss = null;
			assert Parameters.segModel == 1;
			segLenGeoDist = new SegLenGeoDist(params.segEta, corpus.numSents());
			System.out.println("***Geometric distribition on segment lengths***");
		}
		//Geometric model on document length
		if(Parameters.docModel == 1) {
			docLenGeoDist = new DocLenGeoDist(params.docEta, corpus.numDocs());
			System.out.println("***Geometric distribition on doc lengths***");
			docLenPoissDist = null;
		} else {
			docLenPoissDist = new DocLenPoissDist(params.docLambda, rand);
			System.out.println("***Poisson distribition on doc lengths***");
			docLenGeoDist = null;
		}
		//Annealing
		ann = new Annealer(params.startTemp, params.endTemp, params.coolingTemp, 
							params.annealItes, params.coolingItes, params.gibbsMaxIte);
		//Segmentation evaluation
		eva = new Evaluator(corpus);
		//cache
		sentIdx = new TIntArrayList(corpus.maxDocLenSent()*2);
	}
	
	private void initialiseFromFullRanking() {
		//Generate s code for full ranking
		int[][] fullPis = new int[corpus.numDocs()][];
		for(int d = 0; d < corpus.numDocs(); d++)
			fullPis[d]= gmm.sample_pi();
		//Initialize topic orders
		int[] topicsOrder;
		int totalInitSegs = 0;
		TIntArrayList partialPi;
		for(int d = 0; d < corpus.numDocs(); d++) {
			topicsOrder = new int[corpus.numSents(d)];
			for(int s = 0; s < corpus.numSents(d); s++)
				topicsOrder[s] = rand.nextInt(params.numTopics); //0 to K-1
			Arrays.sort(topicsOrder);
			partialPi = new TIntArrayList();
			int spanLength, end, start = 0;
			int numSents = corpus.numSents(d);
			int segIdx = 0;
			while(start < numSents){
				for (spanLength = 1; start + spanLength < numSents 
						&& topicsOrder[start + spanLength] == topicsOrder[start]; 
						spanLength++) {}
				end = start + spanLength - 1;
				totalInitSegs++;
				int k = fullPis[d][topicsOrder[start]];
				partialPi.add(k);
				for(int s = start; s <= end; s++) {
					segmentations[d][s] = segIdx;
					dcm.add(d, s, k);
				}
				segIdx ++;
				start = end + 1;
				if(Parameters.docModel == 1) {
					if(start >= numSents)
						docLenGeoDist.addOneSec(true);
					else
						docLenGeoDist.addOneSec(false);
				}
				if(Parameters.segModel == 1) {
					segLenGeoDist.addOneSec(spanLength);
				}
			}
			gmm.addPi(d, partialPi);
			if(Parameters.verbose >= 20000) {
				System.out.println("\t topic order: "+(new TIntArrayList(topicsOrder)).toString());
				System.out.println("\t full  order: "+(new TIntArrayList(fullPis[d])).toString());
				System.out.println("\t seg: "+(new TIntArrayList(segmentations[d])).toString());
				System.out.println("\t partial order:"+partialPi.toString());
				System.out.println();
			}
		}
		
		if(Parameters.debug) {
			dcm.debug();
			if(Parameters.docModel == 1)
				docLenGeoDist.debug(totalInitSegs);
			if(Parameters.segModel == 1)
				segLenGeoDist.debug(totalInitSegs);
		}
		if(Parameters.verbose >= 2500)
			System.out.println("================== init segs ratio: "+totalInitSegs +"/"+corpus.totalGoldSegs());
	}
	
	public void sample() throws IOException {
		int sampleIndex = 1;
		double wd, pk, wde;
		long startTime = System.currentTimeMillis();
		initialiseFromFullRanking();
		//Print initial information
		if(Parameters.verbose >= 5000) {
			eva.generateWordBased(segmentations);
			wd = eva.avewd(0, false);
			pk = eva.avepk(0, false);
			wde = eva.avewde(0, false);
			System.out.printf("Sentence:\tite = %d, pk = %.4f, wd = %.4f, wde = %.4f\n", 0, pk, wd, wde);
			wd = eva.avewd(0, true);
			pk = eva.avepk(0, true);
			wde = eva.avewde(0, true);
			System.out.printf("Word:\t\tite = %d, pk = %.4f, wd = %.4f, wde = %.4f\n", 0, pk, wd, wde);
			System.out.println(String.format("ite = %d, lll = %.5f\n", 0, this.modelloglikelihood()));
		}
		//Start Gibbs iterations
		for(int ite = 1; ite <= params.gibbsMaxIte; ite++) {
			if(Parameters.verbose >= 5000) 
				System.out.println();
			this.runOneIte(ite);
			// Print information
			if(Parameters.verbose >= 5000 || ite == params.gibbsMaxIte) {
				System.out.printf("ite = %d, temp = %.5f\n", ite, ann.temp());
				eva.generateWordBased(segmentations);
				wd = eva.avewd(0, false);
				pk = eva.avepk(0, false);
				wde = eva.avewde(0, false);
				System.out.printf("Sentence:\tite = %d, pk = %.4f, wd = %.4f, wde = %.4f\n", ite, pk, wd, wde);
				wd = eva.avewd(0, true);
				pk = eva.avepk(0, true);
				wde = eva.avewde(0, true);
				System.out.printf("Word:\t\tite = %d, pk = %.4f, wd = %.4f, wde = %.4f\n", ite, pk, wd, wde);
				System.out.printf("ite = %d, lll = %.5f\n", ite,  this.modelloglikelihood());
				System.out.printf("ite = %d, #segs = %d, segsRatio = %.3f\n", ite, countSegs, (countSegs*1.0/corpus.numDocs()));
				if(Parameters.segModel == 2 || Parameters.segModel == 3){
					System.out.printf("ite = %d, exptected seg lambda = %.3f\n", ite, ((double)corpus.numSents()/corpus.totalGoldSegs()));
					System.out.printf("ite = %d,  sampled seg lambdas = %s\n", ite, segLenPoiss.lambdaToString());
				}
				if(Parameters.docModel == 2) {
					System.out.printf("ite = %d, exptected doc lambda = %.3f\n", ite, ((double)corpus.totalGoldSegs()/corpus.numDocs()));
					System.out.printf("ite = %d,  sampled doc lambdas = %s\n", ite, docLenPoissDist.lambdaToString());
				}
			}
			//Draw samples
			if(ite > params.gibbsBurnIn && ite%params.gibbsLag == 0) {
				String sampleRoot = params.root + File.separator + "sample-"+sampleIndex;
				(new File(sampleRoot)).mkdirs();
				String str = sampleRoot+ File.separator + "pis.log";
				gmm.writePis(str);
				str = sampleRoot + File.separator + "segmentations.log";
				writeSegmentation(str);
				str = sampleRoot+ File.separator + "topWordsPerTopic.log";
				dcm.writeTopicByWords(str);
				sampleIndex++;
			}
			//Optimize parameters
			if(params.optTheta)
				gmm.sampleThetas();
			if((Parameters.segModel == 2 || Parameters.segModel == 3) && Parameters.optSegLambda) 
				segLenPoiss.sampleLambda(segmentations);
			if(Parameters.docModel == 2 && Parameters.optDocLambda)
				docLenPoissDist.sampleLambda(segmentations);
			//SA
			if(Parameters.anneal)
				ann.update();
		}
		long duration = Math.round((System.currentTimeMillis() - startTime)/1000.0);
		printRuningTime(duration, "Total running time");
	}
	
	private void runOneIte(int ite) {
		long startTime = System.currentTimeMillis();
		countSegs = 0;
		for(int d = 0; d < corpus.numDocs(); d++) {
			sentIdx.clear();
			//Jointly sample boundaries and topics
			for (int s = 0; s < corpus.numSents(d) - 1; s++) 
				sentIdx.add(s);
			sentIdx.shuffle(rand);
			for (int s = 0; s < corpus.numSents(d) - 1; s++) 
				bsampler.sample(d, sentIdx.get(s), gmm.getPartialPi(d), segmentations[d]);
			bsampler.sampleLastSent(d, corpus.numSents(d) - 1, gmm.getPartialPi(d), segmentations[d]);
			//For debug
			countSegs += segmentations[d][segmentations[d].length - 1] + 1;
		}
		if(Parameters.verbose >= 5000)
			System.out.printf("ite = %d, runTime: %.3f\n", ite, (System.currentTimeMillis() - startTime)/1000.0);
	}	
	
	
	private double modelloglikelihood() {
		double lll = dcm.loglikelihood() + gmm.loglikelihood();
		if(Parameters.docModel == 1)
			lll += docLenGeoDist.logPosterior();
		else 
			lll += docLenPoissDist.logLikelihood(segmentations);
		
		if(Parameters.segModel == 2 || Parameters.segModel == 3)
			lll += segLenPoiss.logLikelihood(segmentations);
		else 
			lll += segLenGeoDist.logLikelihood();
		return   lll/corpus.numTokens();
	}

	private void printRuningTime(long seconds, String str) {
		long minutes = seconds / 60;	seconds %= 60;
		long hours = minutes / 60;	minutes %= 60;
		long days = hours / 24;	hours %= 24;
		System.out.print (str+": ");
		if (days != 0) 
			System.out.print(String.format("%d days, ", days));
		if (hours != 0)
			System.out.print(String.format("%d hours, ", hours)); 
		if (minutes != 0) 
			System.out.print(String.format("%d minutes, ", minutes)); 
		System.out.print(String.format("%d seconds\n", seconds)); 
	}
	
	private void writeSegmentation(String str) {
		try{
			FileWriter writer = new FileWriter(str);
			for(int d = 0; d < segmentations.length; d++) {
				for(int s = 0; s < segmentations[d].length; s++) {
					if(s < segmentations[d].length-1) 
						writer.write(segmentations[d][s]+",");
					else
						writer.write(segmentations[d][s]+"\n");
				}
			}
			writer.flush();
			writer.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
}
