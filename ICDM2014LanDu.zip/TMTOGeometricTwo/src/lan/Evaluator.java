package lan;
import data.Corpus;

public class Evaluator {
	
	private Corpus corpus;
	private int goldWordSeg[][];
	private int hypoWordSeg[][];
	private int[][] goldSentSegs;
	private int[][] hypoSentSegs;
	
	public Evaluator(Corpus corpus) {
		this.corpus = corpus;
		this.goldSentSegs = corpus.getGoldSeg();
		goldWordSeg = new int[corpus.numDocs()][];
		hypoWordSeg = new int[corpus.numDocs()][];
		for(int d = 0; d < corpus.numDocs(); d++) {
			goldWordSeg[d] = new int[corpus.numTokens(d)];
			hypoWordSeg[d] = new int[corpus.numTokens(d)];
			int idx = 0;
			for(int s = 0; s < corpus.numSents(d); s++) {
				int seg = goldSentSegs[d][s];
				for(int n = 0; n < corpus.numTypes(d, s); n++) {
					for(int m = 0; m < corpus.typeCount(d, s, n); m++) {
						goldWordSeg[d][idx] = seg;
						idx++;
					}
				}
			}
			assert idx == corpus.numTokens(d);
		}
	}
	
	/**
	 * 
	 * @param hypoSegs
	 */
	public void generateWordBased(int [][] hypoSegs) {
		this.hypoSentSegs = hypoSegs;
		for(int d = 0; d < corpus.numDocs(); d++) {
			int idx = 0;
			for(int s = 0; s < corpus.numSents(d); s++) {
				int seg = hypoSentSegs[d][s];
				for(int n = 0; n < corpus.numTypes(d, s); n++) {
					for(int m = 0; m < corpus.typeCount(d, s, n); m++) {
						hypoWordSeg[d][idx] = seg;
						idx++;
					}
				}
			}
			assert idx == corpus.numTokens(d);
		}
	}

////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
	public double avepkCell(int wsize, boolean doWord) {
		if(doWord) {
			return avepkCell(hypoWordSeg, goldWordSeg, wsize);
		} else {
			return avepkCell(hypoSentSegs, goldSentSegs, wsize);
		}
	}

	private double avepkCell(int[][] hypos, int[][] golds, int wsize) {
		double averagePK = 0.0;
		double docCount = 0;
		int docIll = 0;
		double totalGoldSegs = 0;
		double totalHypoSegs = 0;
		for(int d = 0; d < golds.length; d++) {
			if(golds[d][golds[d].length-1] > 0) {
				averagePK += pk(hypos[d], golds[d], wsize);
				totalGoldSegs += golds[d][golds[d].length -1]+1;
				totalHypoSegs += hypos[d][hypos[d].length -1]+1;
				docCount++;
			} else {
				docIll++;
			}
		}
		System.out.println("average gold seg per doc: "+ (totalGoldSegs/docCount));
		System.out.println("average hypo seg per doc: "+ (totalHypoSegs/docCount));
		System.out.println("Not counted docs: "+ docIll);
		return averagePK/docCount;
	}
	

	public double avepk(int wsize, boolean doWord) {
		if(doWord) {
			return avepk(hypoWordSeg, goldWordSeg, wsize);
		} else {
			return avepk(hypoSentSegs, goldSentSegs, wsize);
		}
	}

	private double avepk(int[][] hypos, int[][] golds, int wsize) {
		double averagePK = 0.0;
		double docCount = 0;
		double totalGoldSegs = 0;
		double totalHypoSegs = 0;
		for(int d = 0; d < golds.length; d++) {
			if(golds[d].length > 1) {
				averagePK += pk(hypos[d], golds[d], wsize);
			} else {
				averagePK += 0;
				assert golds[d][0] == 0 && hypos[d][0] == 0;
			}
			totalGoldSegs += golds[d][golds[d].length -1]+1;
			totalHypoSegs += hypos[d][hypos[d].length -1]+1;
			docCount++;
		}
		System.out.println("average gold seg per doc: "+ (totalGoldSegs/docCount));
		System.out.println("average hypo seg per doc: "+ (totalHypoSegs/docCount));
		return averagePK/docCount;
	}
	
	private double pk(int[] hypo, int[] gold, int wsize) {
		assert hypo.length == gold.length;
		if(wsize == 0)
			wsize = (int) Math.round(gold.length / (2.0 * (gold[gold.length-1]+1)));

		double num_misses = 0.0;
		for (int i = wsize; i < gold.length; i++) 
			if ((gold[i] == gold[i - wsize]) != (hypo[i] == hypo[i - wsize]))
				num_misses++;
		return num_misses / (gold.length - wsize);
	}
		

////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////

	public double avewdCell(int wsize, boolean doWord) {
		if(doWord) {
			return avewdCell(hypoWordSeg, goldWordSeg, wsize);
		} else {
			return avewdCell(hypoSentSegs, goldSentSegs, wsize);
		}
	}
	
	private double avewdCell(int[][] hypos, int[][] golds, int wsize) {
		double averageWD = 0.0;
		double docCount = 0;
		for(int d = 0; d < golds.length; d++){
			if(golds[d][golds[d].length-1] > 0) {
				averageWD += wd(hypos[d], golds[d], wsize);
				docCount ++;
			} 
		}
		return averageWD/docCount;
	}
	
	/*
	 * Averge window-diff scores
	 */
	public double avewd(int wsize, boolean doWord) {
		if(doWord) {
			return avewd(hypoWordSeg, goldWordSeg, wsize);
		} else {
			return avewd(hypoSentSegs, goldSentSegs, wsize);
		}
	}
	
	private double avewd(int[][] hypos, int[][] golds, int wsize) {
		double averageWD = 0.0;
		double docCount = 0;
		for(int d = 0; d < golds.length; d++){
			if(golds[d].length > 1) {
				averageWD += wd(hypos[d], golds[d], wsize);
			} else {
				averageWD += 0;
			}
			docCount ++;
		}
		return averageWD/docCount;
	}
	
	private double wd(int[] hypo, int[] gold, int wsize) 
	{
		assert  hypo.length == gold.length;
		if(wsize == 0)
			wsize = (int) Math.round(gold.length / (2.0 * (gold[gold.length-1]+1)));

		double num_misses = 0.0;
		for (int i = wsize; i < gold.length; i++) 
//			num_misses += Math.abs((hypo[i] - hypo[i - wsize])
//					- (gold[i] - gold[i - wsize]));
			if(Math.abs((hypo[i] - hypo[i - wsize]) - (gold[i] - gold[i - wsize])) > 0)
				num_misses ++;
//		System.out.println("num_misses = "+num_misses + ", numWinds = "+(refSegs.length - wsize));
		return num_misses / (gold.length - wsize);
	}

////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
	
	public double avewdeCell(int wsize, boolean doWord) {
		if(doWord) {
			return avewdeCell(hypoWordSeg, goldWordSeg, wsize);
		} else {
			return avewdeCell(hypoSentSegs, goldSentSegs, wsize);
		}
	}
	
	private double avewdeCell(int[][] hypos, int[][] golds, int wsize) {
		double averageWDE = 0.0;
		double docCount = 0;
		for(int d = 0; d < golds.length; d++){
			if(golds[d][golds[d].length-1] > 0) {
				averageWDE += wde(hypos[d], golds[d], wsize);
				docCount ++;
			} 
		}
		return averageWDE/docCount;
	}
	
	public double avewde(int wsize, boolean doWord) {
		if(doWord) {
			return avewde(hypoWordSeg, goldWordSeg, wsize);
		} else {
			return avewde(hypoSentSegs, goldSentSegs, wsize);
		}
	}
	
	private double avewde(int[][] hypos, int[][] golds, int wsize) {
		double averageWDE = 0.0;
		double docCount = 0;
		for(int d = 0; d < golds.length; d++){
			if(golds[d].length > 1) {
				averageWDE += wde(hypos[d], golds[d], wsize);
			} else {
				averageWDE += 0;
			}
			docCount ++;
		}
		return averageWDE/docCount;
	}
	
	private double wde(int[] hypo, int[] gold, int wsize) 
	{
		if(wsize == 0)
			wsize = (int) Math.round(gold.length / (2.0 * (gold[gold.length - 1]+1)));
		
		int cardRef = 0, cardHyp = 0;
		double num_misses = 0.0;
		for (int i = 0; i < gold.length; i++)  {
			if(i >= 1 && i <= wsize-1){
				cardRef = gold[i] - gold[0];
				cardHyp = hypo[i] - hypo[0];
				if(Math.abs(cardRef - cardHyp) > 0)
					num_misses ++;
			}
			
			if(i >= 0 && i <= gold.length - wsize - 1){
				cardRef = gold[i+wsize] - gold[i];
				cardHyp = hypo[i+wsize] - hypo[i];
				if(Math.abs(cardRef - cardHyp) > 0)
					num_misses ++;
			}
			
			if(i >= gold.length - wsize && i <= gold.length-2){
				cardRef = gold[i] - gold[gold.length-1];
				cardHyp = hypo[i] - hypo[gold.length-1];
				if(Math.abs(cardRef - cardHyp) > 0)
					num_misses ++;
			}
		}
		return num_misses/(gold.length + wsize - 2.0);
	}
}
