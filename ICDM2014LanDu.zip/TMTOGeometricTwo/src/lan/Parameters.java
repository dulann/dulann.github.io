package lan;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.ConfigurationRuntimeException;
import org.apache.commons.configuration.PropertiesConfiguration;

public final class Parameters {
	public static boolean debug = false;
	public static int verbose = 0;
	/*
	 *  0: top-t model; 
	 *  1: partial model with instance learning
	 */
	public static int gmmModel = 0;
	/*
	 * 1: Geometric distribution, 
	 * 2: Poisson distribution
	 */
	public static int docModel = 1;
	/*
	 * 1: Geometric distribution 
	 * 2: single Poisson distribution
	 * 3: K Poisson distributions
	 */
	public static int segModel = 3;
	
	public final long seed;
	public int numTopics;
	public final String dataSetFolder;
	public final String dataName;
	public String outputDir;
	public String root;
	
	//Gibbs settings
	public final int gibbsMaxIte;
	public final int gibbsBurnIn;
	public final int gibbsLag;
	//Dirichlet-Multinomial parameter
	public final double beta;
	
	//GMM parameters
	public double initTheta;
	public final double theta_0;
	public final double s_0;
	public boolean optTheta;
	
	//Document level parameters
	public double docEta;
	public double docLambda;
	public static boolean optDocLambda = false;
	
	//Segment level parameters
	public double segEta;
	public double segLambda;
	public static boolean optSegLambda = false;
	
	//anneal parameters
	public static boolean anneal;
	public final double startTemp;
	public final double endTemp;
	public final double coolingTemp;
	public final int annealItes;
	public final int coolingItes;
	//
	public boolean removeStopWords;

	public Parameters(int numTopics, String configFile) throws ConfigurationException {
		this.numTopics = numTopics;
		seed = System.currentTimeMillis();
		PropertiesConfiguration config = new PropertiesConfiguration();
		config.load(configFile);
		//Read data set folder
		if(config.containsKey("data.folder"))
			dataSetFolder = config.getString("data.folder");
		else
			throw new ConfigurationRuntimeException("Missing data.folder!!!");
		//Read data set name
		if(config.containsKey("data.name"))
			dataName = config.getString("data.name");
		else
			throw new ConfigurationRuntimeException("Missing data.name!!!");
		/*
		 * Read Gibbs settings
		 */
		if(config.containsKey("train.maxItes"))
			gibbsMaxIte = config.getInt("train.maxItes");
		else
			throw new ConfigurationRuntimeException("Missing train.maxItes!!!");
		if(config.containsKey("train.burnIn"))
			gibbsBurnIn = config.getInt("train.burnIn");
		else
			throw new ConfigurationRuntimeException("Missing train.burnIn!!!");
		if(config.containsKey("train.lag"))
			gibbsLag = config.getInt("train.lag");
		else
			throw new ConfigurationRuntimeException("Missing train.lag!!!");
		/*
		 * Read Dirichlet parameter beta
		 */
		if(config.containsKey("dcm.beta"))
			beta = config.getDouble("dcm.beta");
		else
			throw new ConfigurationRuntimeException("Missing dcm.beta!!!");
		/*
		 * Read common prior on thetas in PGMM
		 */
		if(config.containsKey("pgmm.theta0"))
			theta_0 = config.getDouble("pgmm.theta0");
		else
			throw new ConfigurationRuntimeException("Missing pgmm.theta0!!!");
		if(config.containsKey("pgmm.szero"))
			s_0 = config.getDouble("pgmm.szero");
		else
			throw new ConfigurationRuntimeException("Missing pgmm.szero!!!");
		
		if(config.containsKey("opt.theta"))
			optTheta = config.getBoolean("opt.theta");
		else
			optTheta = false;
		/*
		 * Annealing configuration
		 */
		if(config.containsKey("sa.startTemp"))
			startTemp = config.getDouble("sa.startTemp");
		else 
			startTemp = 0.0;
		if(config.containsKey("sa.endTemp"))
			endTemp = config.getDouble("sa.endTemp");
		else 
			endTemp = 0.0;
		if(config.containsKey("sa.coolingTemp"))
			coolingTemp = config.getDouble("sa.coolingTemp");
		else 
			coolingTemp = 0.0;
		if(config.containsKey("sa.annealItes"))
			annealItes = config.getInt("sa.annealItes");
		else 
			annealItes = 0;
		if(config.containsKey("sa.coolingItes"))
			coolingItes = config.getInt("sa.coolingItes");
		else 
			coolingItes = 0;
	}
	
	/**
	 * Create the root file directory for storing 
	 * output files.
	 */
	public void createRoot(int idx) {
		root = outputDir + File.separator +"k-"+numTopics+"-run-"+idx;
		File rootDir = new File(root);
		if(!rootDir.exists()) 
			rootDir.mkdirs();
		System.out.println("root = "+root);
	}
	
	public void writeParameters() {
		try {
			String str = root + File.separator + "parameters.log";
			FileWriter writer = new FileWriter(str);
			writer.write("data.folder = "+this.dataSetFolder+"\n");
			writer.write("data.name = " + this.dataName+"\n");
			writer.write("random.seed = "+this.seed);
			writer.write("oDir = " + this.outputDir+"\n");
			writer.write("root = "+this.root+"\n");
			writer.write("train.maxItes = "+this.gibbsMaxIte+"\n");
			writer.write("train.burIn = "+this.gibbsBurnIn+"\n");
			writer.write("train.lag = "+this.gibbsLag+"\n");
			writer.write("gmm.model = "+gmmModel);
			writer.write("dcm.beta = "+this.beta+"\n");
			writer.write("docLen.model = "+docModel+"\n");
			if(docModel == 2) {
				writer.write("poisson.docLambda = "+this.docLambda+"\n");
				writer.write("poisson.sampleDocLambda = "+optDocLambda+"\n");
			}else {
				writer.write("geometric.docEta = "+this.docEta+"\n");
			}
			writer.write("segLen.model = "+segModel);
			if(segModel == 1) {
				writer.write("geometric.segEta = "+this.segEta+"\n");
			} else {
				writer.write("poisson.segLambda = "+this.segLambda+"\n");
				writer.write("poisson.sampleSegLambda = "+optSegLambda+"\n");
			}
			writer.write("gmm.theta0 = "+this.theta_0+"\n");
			writer.write("gmm.szero = " + this.s_0 + "\n");
			writer.write("gmm.theta = "+this.optTheta+"\n");
			writer.write("gmm.initTheta = "+this.initTheta+"\n");
			writer.write("removeStopWords = "+removeStopWords+"\n");
			writer.write("sa.anneal = "+anneal+"\n");
			writer.write("sa.startTmp = "+startTemp+"\n");
			writer.write("sa.endTmp = "+endTemp+"\n");
			writer.write("sa.coolingTemp = "+coolingTemp+"\n");
			writer.write("sa.annealItes = "+annealItes+"\n");
			writer.write("sa.coolingItes = "+coolingItes+"\n");
			writer.flush();
			writer.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

}
