package lan;
import utils.MTRandom;

public class BoundarySampler {
	private MTRandom rand;
	private MergeSampler mergeSampler;
	private SplitSampler splitSampler;
	
	private boolean isLastSec;
	
	public BoundarySampler(MTRandom rand, int numTopics) {
		this.rand = rand;
		mergeSampler = new MergeSampler(numTopics, rand);
		splitSampler = new SplitSampler(numTopics, rand);
	}
	
	/**
	 * Resampling the topic assignment of the last section.
	 * 
	 * @param d
	 * @param s
	 * @param pi
	 * @param segs
	 */
	public void sampleLastSent(final int d, final int s, int[] pi, int[] segs) {
		int ss = this.findSegStart(s, segs);
		assert segs[ss] == segs[s];
		int se = s;
		ModelSampler.gmm.removePi(d);
		ModelSampler.dcm.remove(d, ss, se, segs, pi);
		mergeSampler.merge(d, ss, se, pi, segs);
		mergeSampler.sample(d, s, ss, se, segs);
	}
	
	/**
	 * Sample boundary after each sentence.
	 * @param d
	 * @param s
	 * @param pi
	 * @param segs
	 */
	public void sample(final int d, final int s, int[] pi, int[] segs) {
		assert s < segs.length - 1;
		int ss, se;
		int numSecs = pi.length;
		//Find start and end of segment
		ss = this.findSegStart(s, segs);
		if (segs[s] != segs[s + 1])
			se = this.findSegEnd(s + 1, segs);
		else
			se = this.findSegEnd(s, segs);
		//Remove
		isLastSec = false;
		ModelSampler.gmm.removePi(d);
		ModelSampler.dcm.remove(d, ss, se, segs, pi);
		if (segs[ss] != segs[se]) {
			numSecs -= 2;
			if(segs[se] == pi.length-1) 
				isLastSec = true;
			if(Parameters.docModel == 1) {
				ModelSampler.docLenGeoDist.removeOneSec(false);
				ModelSampler.docLenGeoDist.removeOneSec(isLastSec);
			} 
			if(Parameters.segModel == 1){
				ModelSampler.segLenGeoDist.removeOneSec(s-ss+1);
				ModelSampler.segLenGeoDist.removeOneSec(se-s);
			}
		} else {
			numSecs --;
			if(segs[ss] == pi.length-1) 
				isLastSec = true;
			if(Parameters.docModel == 1)
				ModelSampler.docLenGeoDist.removeOneSec(isLastSec);
			if(Parameters.segModel == 1){
				ModelSampler.segLenGeoDist.removeOneSec(se-ss+1);
			}
		}
		
		//Calculate merging and splitting probabilities
		double mergeProb = mergeSampler.merge(d, ss, se, pi, segs);
		double splitProb = splitSampler.split(d, s, ss, se, pi, segs);
		
		if(Parameters.docModel == 1) {
			mergeProb += ModelSampler.docLenGeoDist.logProbOne(isLastSec);
			splitProb += ModelSampler.docLenGeoDist.logProbTwo(isLastSec);
		} else {
			mergeProb += ModelSampler.docLenPoissDist.logProb(numSecs+1, -1);
			splitProb += ModelSampler.docLenPoissDist.logProb(numSecs+2, -1);
		}
		if(Parameters.segModel == 2) {
			   mergeProb += ModelSampler.segLenPoiss.logProb(se-ss+1, -1);
			   splitProb +=	ModelSampler.segLenPoiss.logProb(s-ss+1, -1) + ModelSampler.segLenPoiss.logProb(se-s, -1);
		} else if(Parameters.segModel == 1) {
			   mergeProb += ModelSampler.segLenGeoDist.logProb(se-ss+1);
			   splitProb += ModelSampler.segLenGeoDist.logProb(s-ss+1, se-s);
		}
		//Sample
		if (Double.isNaN(splitProb)) {
			mergeSampler.sample(d, s, ss, se, segs);
			if(Parameters.docModel == 1)
				ModelSampler.docLenGeoDist.addOneSec(isLastSec);
			if(Parameters.segModel == 1) {
				ModelSampler.segLenGeoDist.addOneSec(se-ss+1);
			}
		} else {
			mergeProb = 1.0 / (1.0 + Math.exp(splitProb - mergeProb));
			if (Parameters.anneal) {
				splitProb = 1 - mergeProb;
				mergeProb = ModelSampler.ann.anneal(mergeProb);
				splitProb = ModelSampler.ann.anneal(splitProb);
				mergeProb = mergeProb / (splitProb + mergeProb);
			}
			if (mergeProb > rand.nextDouble()) {
				mergeSampler.sample(d, s, ss, se, segs);
				if(Parameters.docModel == 1)
					ModelSampler.docLenGeoDist.addOneSec(isLastSec);
				if(Parameters.segModel == 1) {
					ModelSampler.segLenGeoDist.addOneSec(se-ss+1);
				}
			} else {
				splitSampler.sample(d, s, ss, se, segs);
				if(Parameters.docModel == 1){
					ModelSampler.docLenGeoDist.addOneSec(false);
					ModelSampler.docLenGeoDist.addOneSec(isLastSec);
				}
				if(Parameters.segModel == 1) {
					ModelSampler.segLenGeoDist.addOneSec(s-ss+1);
					ModelSampler.segLenGeoDist.addOneSec(se-s);
				}
			}
		}
	}
	
	private int findSegStart(int s, int[] segs) {
		int start = s;
		for(int i = s-1; i >= 0; i--)
			if(segs[i] ==  segs[s])
				start = i;
			else break;
		return start;
	}

	private int findSegEnd(int s, int[] segs) {
		int end = s;
		for(int i = s+1; i < segs.length; i++) {
			if(segs[i] == segs[s])
				end = i;
			else break;
		}
		return end;
	}
}
