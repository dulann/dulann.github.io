package lan;
import utils.MTRandom;
import gnu.trove.list.array.TIntArrayList;
import gnu.trove.map.hash.TIntDoubleHashMap;
import gnu.trove.map.hash.TObjectDoubleHashMap;

public class SplitSampler {
	private final int numTopics;
	private final int[] topics;
	private MTRandom rand;
	//cache
	private TObjectDoubleHashMap<Pair> topicPairProbs;
	private TIntArrayList newPi;
	private double sum;
	private TIntDoubleHashMap leftTopicProbs;
	private int[] leftTopics;
	private TIntDoubleHashMap rightTopicProbs;
	private int[] rightTopics;
	
	public SplitSampler(int numTopics, MTRandom rand) {
		this.numTopics = numTopics;
		this.rand = rand;
		topics = new int[numTopics];
		for(int i = 0; i < numTopics; i++)
			topics[i] = i;
		//cache
		topicPairProbs = new TObjectDoubleHashMap<Pair>((numTopics+1)*(numTopics+1));
		leftTopicProbs = new TIntDoubleHashMap(numTopics*2);
		rightTopicProbs = new TIntDoubleHashMap(numTopics*2);
	}
	
	/**
	 * 
	 * @param d
	 * @param s
	 * @param ss
	 * @param se
	 * @param pi
	 * @param segs
	 * @return
	 */
	public double split(final int d, final int s, final int ss, final int se, int[] pi, int[] segs) {
		int i, j;
		// Generate candidate topic pairs
		leftTopicProbs.clear();
		rightTopicProbs.clear();
		for(i = 0; i < numTopics; i++) {
			leftTopicProbs.put(i, 0.0);
			rightTopicProbs.put(i, 0.0);
		}
		for(i = 0; i < pi.length; i++) {
			if(i != segs[ss] && i != segs[se]) {
				leftTopicProbs.remove(pi[i]);
				rightTopicProbs.remove(pi[i]);
			}
		}
		if(leftTopicProbs.size() == 1) {
			assert rightTopicProbs.size() == 1;
			assert leftTopicProbs.keys()[0] == rightTopicProbs.keys()[0];
			return Double.NaN;
		}
		//
		leftTopics = leftTopicProbs.keys();
		rightTopics = rightTopicProbs.keys();
		assert leftTopics.length == rightTopics.length;
		for(i = 0; i < leftTopics.length; i++) {
			leftTopicProbs.put(leftTopics[i], logProb(d, ss, s, leftTopics[i])); 
			rightTopicProbs.put(rightTopics[i], logProb(d, s+1, se, rightTopics[i]));
		}
			
		//
		topicPairProbs.clear();
		double leftProb;
		for(i = 0; i < leftTopics.length; i++) {
			leftProb = leftTopicProbs.get(leftTopics[i]);
			for(j = 0; j < rightTopics.length; j++) {
				if(leftTopics[i] != rightTopics[j]) {
					topicPairProbs.put(new Pair(leftTopics[i], rightTopics[j]), leftProb + rightTopicProbs.get(rightTopics[j]));
				}
			}
		}
		// Create an extra space, if sample from merge to split.
		newPi = new TIntArrayList(pi);
		if (segs[ss] == segs[se])
			newPi.insert(segs[ss] + 1, -1);
		// Compute log probability of each candidate topic pairs
		for (Pair tp : topicPairProbs.keySet()) {
			newPi.replace(segs[ss], tp.left());
			newPi.replace(segs[ss] + 1, tp.right());
			double tmp = topicPairProbs.get(tp) + ModelSampler.gmm.logProbPartialPi(newPi);
			topicPairProbs.put(tp, tmp);
		}
		// Compute log probability of splitting
		double max = Double.NEGATIVE_INFINITY;
		for (Pair tp : topicPairProbs.keySet()) {
			if (topicPairProbs.get(tp) > max)
				max = topicPairProbs.get(tp);
		}
		sum = 0.0;
		double tmp;
		for (Pair tp : topicPairProbs.keySet()) {
			tmp = Math.exp(topicPairProbs.get(tp) - max);
			topicPairProbs.put(tp, tmp);
			sum += tmp;
		}
		double logProb = max + Math.log(sum);

		if (Double.isInfinite(logProb) || Double.isNaN(logProb))
			throw new RuntimeException("Illegal log probability of spliting!!!");
		return logProb;
	}
	
	private double logProb(int d, int ss, int se, int k) {
		double logProb =  ModelSampler.dcm.logProb(d, k, ss, se);
		if(Parameters.segModel == 3)
			logProb += ModelSampler.segLenPoiss.logProb(se-ss+1, k);
		if(Double.isInfinite(logProb) || Double.isNaN(logProb))
			throw new RuntimeException("Illegal log probability for d = "+d+", topic = "+k);
		return logProb;
	}
	
	
	public void sample(int d, int s, int ss, int se, int[] segs) {
		Pair tp;
		if(Parameters.anneal)
			tp = this.nextAnnealed(rand.nextDouble());
		else
			tp = this.nextNormalised(rand.nextDouble());
		ModelSampler.dcm.add(d, ss, s, tp.left());
		ModelSampler.dcm.add(d, s+1, se, tp.right());
		newPi.replace(segs[ss], tp.left());
		newPi.replace(segs[ss]+1, tp.right());
		ModelSampler.gmm.addPi(d, newPi);
		if (segs[ss] == segs[se])
			for(int i = s+1; i < segs.length; i++)
				segs[i]++;
	}
	
	private Pair nextNormalised(double rand) {
		double scaledRandom = sum * rand;
		sum = 0.0;
		for(Pair tp : topicPairProbs.keySet()) {
			sum += topicPairProbs.get(tp);
			if(sum > scaledRandom)
				return tp;
		}
		int idx = Math.round((float)Math.floor(rand*topicPairProbs.keySet().size()));
		int i = 0;
		for(Pair tp : topicPairProbs.keySet()) {
			if (i == idx)
				return tp;
			i++;
		}
		throw new RuntimeException("oooops: no value sampled for spliting move!!!");
	}
	
	private Pair nextAnnealed(double rand) {
		double tmpSum = 0.0;
		for(Pair tp : topicPairProbs.keySet()) {
			double tmp = ModelSampler.ann.anneal(topicPairProbs.get(tp)/sum);
			topicPairProbs.put(tp, tmp);
			tmpSum += tmp;
		}
		double scaledRandom = tmpSum * rand;
		tmpSum = 0.0;
		for(Pair tp : topicPairProbs.keySet()) {
			tmpSum += topicPairProbs.get(tp);
			if(tmpSum > scaledRandom)
				return tp;
		}
		int idx = Math.round((float)Math.floor(rand*topicPairProbs.keySet().size()));
		int i = 0;
		for(Pair tp : topicPairProbs.keySet()) {
			if (i == idx)
				return tp;
			i++;
		}
		throw new RuntimeException("oooops: no value sampled for spliting move!!!");
	}
	
	private class Pair {
		private int left;
		private int right;

		public Pair(int left, int right){
			this.left = left;
			this.right = right;
		}
	
		public int left() {return left;}

		public int right() {return right;}
		
	    public boolean equals(Object o) {
			if(o == null || !(o instanceof Pair))
				return false;
			Pair p = (Pair) o;
			if(p.left != this.left || p.right != this.right)
				return false;
			return true;
		}
	
		public String toString() {
			return String.format("[%d, %d]", left, right);
		}
	}
}
