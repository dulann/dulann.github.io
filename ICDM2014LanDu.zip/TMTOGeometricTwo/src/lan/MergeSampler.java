package lan;
import utils.MTRandom;
import gnu.trove.list.array.*;
import gnu.trove.map.hash.TIntDoubleHashMap;

/**
 * 
 * @author Du Lan
 *
 */
public class MergeSampler {
	private final int numTopics;
	private MTRandom rand;
	//caches
	private TIntDoubleHashMap topicProbs;
	private int[] topics;
	private TIntArrayList newPi;
	private double sum;
	
	public MergeSampler(int numTopics, MTRandom rand) {
		this.numTopics = numTopics;
		this.rand = rand;
		topicProbs = new TIntDoubleHashMap(numTopics*2);
	}

	/**
	 * 
	 * @param d
	 * @param ss
	 * @param se
	 * @param pi a partial ordering
	 * @param segs 
	 * @return
	 */
	public double merge(int d, int ss, int se, int[] pi, int[] segs) {
		int i;
		//Generate candidate topic list
		topicProbs.clear(); 
		for(i = 0; i < numTopics; i++) 
			topicProbs.put(i, 0.0);
		for(i = 0; i < pi.length; i++) {
			if(i != segs[ss] && i != segs[se])
				topicProbs.remove(pi[i]);
		}
		topics = topicProbs.keys();
		//Remove a topic if needed
		newPi = new TIntArrayList(pi);
		if(segs[ss] != segs[se]) { 
			assert segs[se] - segs[ss] == 1;
			newPi.removeAt(segs[se]);
		}
		//Compute log probability of each candidate topic
		for(i = 0; i < topics.length; i++) {
			newPi.replace(segs[ss], topics[i]);
			topicProbs.put(topics[i], logProb(d, ss, se, topics[i], newPi));
		}
		//Compute log probability of merging
		double max = Double.NEGATIVE_INFINITY;
		for(i = 0; i < topics.length; i++)
			if(topicProbs.get(topics[i]) > max)
				max = topicProbs.get(topics[i]);
		sum = 0.0;
		double tmp; 
		for(i = 0; i < topics.length; i++) {
			tmp = Math.exp(topicProbs.get(topics[i]) - max);
			topicProbs.put(topics[i], tmp);
			sum += tmp;
		}
		double logProb = max + Math.log(sum);
		
		if(Double.isInfinite(logProb) || Double.isNaN(logProb))
			throw new RuntimeException("Illegal log probability of merging!!! logProb = "+logProb);
		return logProb;
	}
	
	private double logProb(int d, int ss, int se, int k, TIntArrayList npi) {
		double logProb = ModelSampler.dcm.logProb(d, k, ss, se)
					   		+ ModelSampler.gmm.logProbPartialPi(npi);
		if(Parameters.segModel == 3) 
			logProb += ModelSampler.segLenPoiss.logProb(se-ss+1, k);
		if(Double.isInfinite(logProb) || Double.isNaN(logProb))
			throw new RuntimeException("Illegal merging log probability for d = "+d+", topic = "+k);
		return logProb;
	}
	
	public void sample(int d, int s, int ss, int se, int[] segs) {
		int k;
		if(Parameters.anneal) 
			k = nextAnnealed(rand.nextDouble());
		else 
			k = nextNormalised(rand.nextDouble());
		ModelSampler.dcm.add(d, ss, se, k);
		newPi.replace(segs[ss], k);
		ModelSampler.gmm.addPi(d, newPi);
		if(segs[ss] != segs[se]) 
			for(int i = s+1; i < segs.length; i++)
				segs[i]--;
	}
	
	private int nextAnnealed(double rand) {
		double tmpSum = 0.0;
		for(int i = 0; i < topics.length; i++) {
			double tmp = ModelSampler.ann.anneal(topicProbs.get(topics[i])/sum);
			tmpSum += tmp;
			topicProbs.put(topics[i], tmp);
		}
		double scaledRandom = tmpSum * rand;
		tmpSum = 0.0;
		for(int i = 0; i < topics.length; i++) {
			tmpSum += topicProbs.get(topics[i]);
			if(tmpSum > scaledRandom)
				return topics[i];
		}
		return topics[Math.round((float)Math.floor(rand*topics.length))];
	}
	
	private int nextNormalised(double rand) {
		double scaledRandom = sum * rand;
		sum = 0.0;
		for(int i = 0; i < topics.length; i++) {
			sum += topicProbs.get(topics[i]);
			if(sum > scaledRandom)
				return topics[i];
		}
		return topics[Math.round((float)Math.floor(rand*topics.length))];
	}
}
