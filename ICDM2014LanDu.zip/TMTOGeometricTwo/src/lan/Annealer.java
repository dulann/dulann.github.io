package lan;

public class Annealer {
	private int ite = 0;
	private double startTemp;
	private double endTemp;
	private double coolingTemp;
	private int coolingItes;
	private int annealItes;
	private int gibbsMaxItes;
	private double currentTmp;
	
	public Annealer(double startTemp, double endTemp, double coolingTemp,
					int annealItes, int coolingItes,int gibbsMaxItes) 
	{
		this.startTemp = startTemp;
		this.endTemp = endTemp;
		this.annealItes = annealItes;
		this.coolingTemp = coolingTemp;
		this.coolingItes = coolingItes;
		this.gibbsMaxItes = gibbsMaxItes;
		if(Parameters.verbose >= 5000) {
			System.out.printf("startTemp = %.3f, endTemp = %.3f, " +
					"annealItes = %d, ", startTemp, endTemp, annealItes);
			System.out.printf("coolingTemp = %.3f, coolingItes = %d, gibbsMaxItes = %d\n", 
					coolingTemp, coolingItes, gibbsMaxItes);
		}
	}
	
	public void reset() {
		ite = 0;
	}
	
	public void update() {
		ite++;
	}
	
	public double temp() {
		return currentTmp;
	}
	
	//which is usually used
	public double anneal(double prob) {
		currentTmp = 1.0;
		if(ite < annealItes){
			currentTmp = 1.0 + ((double) startTemp - 1.0) * (1.0 - (double) ite / annealItes);
//			currentTmp = startTemp*Math.pow(endTemp/startTemp, (double)ite/(annealItes-1.0));
		} else if (ite + coolingItes > gibbsMaxItes) {
			currentTmp = coolingTemp;
		} else {
			currentTmp = endTemp;
		}
		
//		System.out.printf("ite = %d, tmp = %.3f, prob = %.3f, annealed = %.3f\n", ite, currentTmp, prob, Math.pow(prob, 1.0 / currentTmp));
		return Math.pow(prob, 1.0 / currentTmp); 
	}
	
	public double anneal1(double prob) {
		currentTmp = 1.0;
		if(ite < annealItes/2) {
			currentTmp = 2.0;
		}
		return Math.pow(prob, 1.0 / currentTmp); 
	}
	
	public double anneal3(double prob) {
		currentTmp = 1.0;
		if(ite < annealItes){
			currentTmp = 1.0 + ((double) startTemp - 1.0) * (1.0 - (double) ite / annealItes);
//			currentTmp = startTemp*Math.pow(endTemp/startTemp, (double)ite/(annealItes-1.0));
		} else if (ite + coolingItes > gibbsMaxItes) {
			currentTmp = ((double) gibbsMaxItes - ite + 1) / ((double) coolingItes);
		} else {
			currentTmp = endTemp;
		}
//		System.out.printf("ite = %d, tmp = %.3f, prob = %.3f, annealed = %.3f\n", ite, currentTmp, prob, Math.pow(prob, 1.0 / currentTmp));
		return Math.pow(prob, 1.0 / currentTmp); 
	}
	
	/*
	public static void main(String[] args) {
		double startTemp = 10.0;
		double endTemp = 1.0;
		int annealItes = 500;
		double coolingTemp = 1.0;
		int coolingItes = 1000;
		int gibbsMaxItes = 2000;
		Annealer ann = new Annealer(startTemp, endTemp, coolingTemp, annealItes, coolingItes, gibbsMaxItes);
		double prob = 0.5;
		for(int i = 0; i < gibbsMaxItes; i++) {
			ann.anneal2(prob);
			ann.update();
//			double currentTmp1 = 1.0 + ((double) startTemp - 1.0) * (1.0 - (double) i / (annealItes-1));
//			double currentTmp2 = Math.max(Math.pow(startTemp, (1.0 - (double)i/(annealItes-1))), 1.0); 
//			double currentTmp3 = startTemp*Math.pow(endTemp/startTemp, (double)i/(annealItes-1.0));
//			System.out.printf("ite = %d: %.4f, %.4f,  %.4f\n", i, currentTmp1, currentTmp2, currentTmp3);
		}
	}
	*/
}
