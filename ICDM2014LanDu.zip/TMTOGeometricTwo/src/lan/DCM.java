package lan;
import java.util.*;
import java.io.*;

import utils.Dirichlet;
import data.Corpus;
import data.Vocabulary;

/**
 * Dirichlet-Multinomial model.
 * 
 * @author Lan Du
 * @since 11-Jun-2013
 */
public class DCM {
	private static final int NUMTOPWORDS = 100;
	private Vocabulary voc;
	private Corpus corpus;
	private double betaSum;
	private double beta;
	private int[][] nkv;
	private int[] nk;
	private int[] wordCountCache;
	//
	private int count;
	private double log10 = Math.log(10.0);
	/**
	 * Create a Dirichlet-Multinomial language model.
	 * 
	 * @param numTopics
	 * @param voc
	 * @param corpus
	 * @param beta Dirichlet parameter
	 */
	public DCM(int numTopics, Vocabulary voc, Corpus corpus, double beta) {
		this.voc = voc;
		this.corpus = corpus;
		this.beta = beta;
		betaSum = beta*voc.size();
		nkv = new int[numTopics][voc.size()];
		for(int k = 0; k < numTopics; k++)
			Arrays.fill(nkv[k], 0);
		nk = new int[numTopics];
		Arrays.fill(nk, 0);
		wordCountCache = new int[voc.size()];
	}
	
	/**
	 * 
	 * @param d document index
	 * @param s sentence index
	 * @param k topic index
	 */
	public void remove(int d, int s, int k) {
		int v, count;
		for(int n = 0; n < corpus.numTypes(d, s); n++){
			count = corpus.typeCount(d, s, n);
			v = corpus.type(d, s, n);
			nkv[k][v] -= count;
			nk[k] -= count;
			if(Parameters.debug) {
				assert nkv[k][v] >= 0;
				assert nk[k] >= 0;
			}
		}
	}
	
	/**
	 *
	 */
	public void remove(int d, int ss, int se, int[] segs, int[] pi) {
		for(int s = ss; s <= se; s++) 
			remove(d, s, pi[segs[s]]); 
	}
	
	public void add(int d, int s, int k) {
		int count;
		for(int n = 0; n < corpus.numTypes(d, s); n++){
			count = corpus.typeCount(d, s, n);
			nkv[k][corpus.type(d, s, n)] += count;
			nk[k] += count;
		}
	}
	
	public void add(int d, int ss, int se, int k) {
		assert ss <= se;
		for(int s = ss; s <= se; s++)
			add(d, s, k);
	}
	
	public double logProb(int d, int k, int ss, int se) {
		assert ss <= se;
		int v, wordCount = 0;
		Arrays.fill(wordCountCache, 0);
		double logProb = 0;
		double prob = 1.0;
		count = 0;
		for(int s = ss; s <= se; s++) {
			for(int n = 0; n < corpus.numTypes(d, s); n++) {
				v = corpus.type(d, s, n);
				for(int c = 0; c < corpus.typeCount(d, s, n); c++) {
					while(prob < 1e-100){
						prob *= 10.0;
						count ++;
					}
					prob *= (nkv[k][v] + wordCountCache[v] + beta) /(nk[k] + wordCount + betaSum);
					wordCountCache[v] ++;
					wordCount ++;
				}
			}
		}
		logProb = Math.log(prob) - count*log10;
		if(Double.isInfinite(logProb) || Double.isNaN(logProb))
			throw new RuntimeException("Illegal DCM log probability for d = "+d+", prob = "+prob);
		return logProb;
	}

	public double loglikelihood() {
		double logProb = nkv.length*Dirichlet.logGamma(betaSum) - nkv.length*voc.size()*Dirichlet.logGamma(beta);
		for(int k = 0; k < nkv.length; k++){
			logProb -= Dirichlet.logGamma(nk[k] + betaSum);
			for(int v = 0; v < voc.size(); v++)
				logProb += Dirichlet.logGamma(nkv[k][v] + beta);
		}
		if(Double.isInfinite(logProb) || Double.isNaN(logProb))
			throw new RuntimeException("Illegal posterior probability of DCM!!!");
		return logProb;
	}
	
	public void writeTopicByWords(String fileName) {
		try {
			FileWriter fwriter = new FileWriter(new File(fileName));
			Map<String, Integer> treeMap = new TreeMap<String, Integer>();
			for (int k = 0; k < nkv.length; k++) {
				for (int w = 0; w < nkv[k].length; w++)
					treeMap.put(voc.getType(w), new Integer(nkv[k][w]));
				treeMap = sortByValueDecending(treeMap);
				fwriter.write("Topic-" + k + ": ");
				int count = 0;
				for (String key : treeMap.keySet()) {
					if (count == NUMTOPWORDS - 1)
						fwriter.write(String.format("%s\n", key));
					else
						fwriter.write(String.format("%s, ", key));
					count++;
					if (count == NUMTOPWORDS)
						break;
				}
				fwriter.write("\n");
				fwriter.flush();
				treeMap.clear();
			}
			fwriter.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	public void writeTopicWordCount(String str) {
		try{
			OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream(str), "UTF-8");
			BufferedWriter writer = new BufferedWriter(osw);
			for(int v = 0; v < voc.size(); v++) {
				if(v < voc.size()-1)
					writer.write(voc.getType(v)+",");
				else
					writer.write(voc.getType(v)+"\n");
			}
			for(int k = 0; k < nkv.length; k++) {
				for(int v = 0; v < voc.size(); v++) {
					if(v < voc.size()-1)
						writer.write(nkv[k][v]+",");
					else
						writer.write(nkv[k][v]+"\n");
				}
			}
			writer.flush();
			writer.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void debug() {
		int[] tmpnk = new int[nk.length];
		for(int k = 0; k < nkv.length; k++)
			for(int v = 0; v < nkv[k].length; v++)
				tmpnk[k] += nkv[k][v];
		int total = 0;
		for(int k = 0; k < nk.length; k++){
			total += nk[k];
			assert tmpnk[k] == nk[k];
		}
		assert total == corpus.numTokens() : "In DCM: total = "+total+", totalNumTokens = "+corpus.numTokens();
	}

	private <K, V extends Comparable<? super V>> Map<K, V> sortByValueDecending(Map<K, V> map)
	{
		List<Map.Entry<K, V>> list = new LinkedList<Map.Entry<K, V>>(map.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<K, V>>() {
			public int compare(Map.Entry<K, V> o1, Map.Entry<K, V> o2)
			{
				int compare = (o1.getValue()).compareTo(o2.getValue());
				return -compare;
			}
		});

		Map<K, V> result = new LinkedHashMap<K, V>();
		for (Map.Entry<K, V> entry : list) {
			result.put(entry.getKey(), entry.getValue());
		}
		return result;
	}
}
