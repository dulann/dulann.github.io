package lengthModels;
import utils.MTRandom;
import utils.Maths;


public class DocLenPoissDist extends PoissonDist{
	private double lambda;
	private double logLambda;
	
	public DocLenPoissDist(double lambda, MTRandom rand) {
		this.rand = rand;
		this.lambda = lambda;
		logLambda = Math.log(lambda);
	}
	
	public double logProb(int length, int topic){
		assert topic == -1;
		double logProb = length * logLambda - lambda - Maths.logFactorial(length);
		if(Double.isInfinite(logProb) || Double.isNaN(logProb))
			throw new RuntimeException("Illegal log poisson desity = "+logProb + " for len = "+length);
		return logProb;
	}
	
	public String lambdaToString() {
		return lambda+"";
	}
	
	public double getLambda() {
		return lambda;
	}
	
	public void sampleLambda(int[][] segmentations) {
		int numSegs = 0;
		for(int i = 0; i < segmentations.length; i++) {
			numSegs += segmentations[i][segmentations[i].length-1] + 1;
		}
		lambda = rand.nextGamma(shape+numSegs, 1.0)/(1/scale + segmentations.length);
		assert lambda > 0;
		if(lambda > MAX)
			lambda = MAX;
		if(lambda < MIN)
			lambda = MIN;
		logLambda = Math.log(lambda);
	}
	
	public double logLikelihood(int[][] segmentations) {
		double val = 0;
		int segTot = 0;
		int numSegs;
		for(int i = 0; i < segmentations.length; i++) {
			numSegs = segmentations[i][segmentations[i].length-1] + 1;
			segTot += numSegs;
			val -= Maths.logFactorial(numSegs);
		}
		val += (shape + segTot - 1)*logLambda - lambda*(segmentations.length + 1.0/scale);
		val -=  Maths.logGamma(shape) + shape*Math.log(scale);
		
		if(Double.isInfinite(val) || Double.isNaN(val))
			throw new RuntimeException("Illegal posterior probability of Poisson model!!!");
		return val;
	}
	
}
