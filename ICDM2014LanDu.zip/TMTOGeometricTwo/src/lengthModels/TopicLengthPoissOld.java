package lengthModels;
import java.util.Arrays;

import lan.ModelSampler;
import utils.MTRandom;
import utils.Maths;

public class TopicLengthPoissOld {
	private static final double MAX = 1000;
	private static final double MIN = 0.01;
	private static final double shape = 2.0;
	private static final double scale = 2.0;
	private int numTopics;
	private MTRandom rand;
	private double[] lambdas;
	private double[] logLambdas;
	//caches
	private int[] n;
	private int[] sum;
	
	public TopicLengthPoissOld(double lambda, MTRandom rand, int numTopics) {
		this.rand = rand;
		this.numTopics = numTopics;
		lambdas = new double[numTopics];
		Arrays.fill(lambdas, lambda);
		logLambdas = new double[numTopics];
		Arrays.fill(logLambdas, Math.log(lambda));
		//initialize caches
		sum = new int[numTopics];
		n = new int[numTopics];
	}
	
	public double logProb(int length, int topic) {
		double logProb;
		logProb = length * logLambdas[topic] - lambdas[topic] - Maths.logFactorial(length);
		if(Double.isInfinite(logProb) || Double.isNaN(logProb))
			throw new RuntimeException("Illegal log poisson desity = "+logProb + " for len = "+length+", topic = "+topic);
		return logProb;
	}
	
	public String getLambdasAsString() {
		String tmp = "";
		for(int k = 0; k < numTopics; k++) {
			tmp += String.format("%.3f", lambdas[k]);
			if(k < numTopics-1)
				tmp +=", ";
		}
		return tmp;
	}
	
	public void sampleLambda(int[][] segmentations, int ite) {
		Arrays.fill(sum, 0);
		Arrays.fill(n, 0);
		int spanLength, pi[], start, numSents, k;
		for(int i = 0; i < segmentations.length; i++) { // for each document
			pi = ModelSampler.gmm.getPartialPi(i);
			start = 0;
			numSents = segmentations[i].length;
			while(start < numSents){
				for (spanLength = 1; 
						start + spanLength < numSents  && segmentations[i][start + spanLength] == segmentations[i][start]; 
						spanLength++) {}
				k = pi[segmentations[i][start]];
				sum[k] += spanLength;
				n[k] ++;
				start += spanLength;
			}
		}
		for(k = 0; k < numTopics; k++) {
			lambdas[k] = rand.nextGamma(shape+sum[k], 1.0)/(1/scale + n[k]);
			assert lambdas[k] > 0;
			if(lambdas[k] > MAX)
				lambdas[k] = MAX;
			if(lambdas[k] < MIN)
				lambdas[k] = MIN;
			logLambdas[k] = Math.log(lambdas[k]);
		}
	}
	
	public double logPosterior(int[][] segmentations) {
		double val = 0;
		Arrays.fill(sum, 0);
		Arrays.fill(n, 0);
		int spanLength, pi[], start, numSents, k;
		for(int i = 0; i < segmentations.length; i++) {
			pi = ModelSampler.gmm.getPartialPi(i);
			start = 0;
			numSents = segmentations[i].length;
			while(start < numSents){
				for (spanLength = 1; start + spanLength < numSents 
						&& segmentations[i][start + spanLength] == segmentations[i][start]; 
						spanLength++) {}
				k = pi[segmentations[i][start]];
				val -= Maths.logFactorial(spanLength);
				sum[k] += spanLength;
				n[k] ++;
				start += spanLength;
			}
		}
		for(k = 0; k < numTopics; k++) {
			val += (shape + sum[k] -1)*Math.log(lambdas[k]) - lambdas[k]*(n[k] + 1.0/scale);
		}
		val -= numTopics * (Maths.logGamma(shape) + shape*Math.log(scale));
		
		if(Double.isInfinite(val) || Double.isNaN(val))
			throw new RuntimeException("Illegal posterior probability of Poisson model!!!");
		return val;
	}
}
