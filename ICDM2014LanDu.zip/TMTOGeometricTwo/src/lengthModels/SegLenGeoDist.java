package lengthModels;
import utils.Maths;

public class SegLenGeoDist {
	private static final double log10 = Math.log(10.0);
	private double eta;
	private double halfEta;
	private final int numParas;
	private int secBounds;
	private int nonSecBounds;
	
	public SegLenGeoDist(double eta, int numParas) {
		this.numParas = numParas;
		this.eta = eta;
		halfEta = eta/2.0;
		secBounds = 0;
		nonSecBounds = 0;
	}
	
	/**
	 * 
	 * @param length #paragraphs in the section
	 */
	public void addOneSec(int length) {
		secBounds ++;
		nonSecBounds += length-1;
	}
	
	/**
	 * 
	 * @param length #paragraphs in the section
	 */
	public void removeOneSec(int length) {
		secBounds --;
		nonSecBounds -= length-1;
	}
	
	public void debug(int numSections) {
		assert numSections == secBounds;
		assert secBounds + nonSecBounds == numParas;
	}
	
	
	public double expectSecBoundProb() {
		return (halfEta + secBounds)/(eta + numParas);
	}
	
	public double logProb(int length) {
		int count = 0;
		double tmpSum = eta + secBounds + nonSecBounds;
		double prob = (halfEta + secBounds)/(tmpSum);
		double tmp = halfEta + nonSecBounds - 1.0;
		for(int i = 1; i < length; i++) {
			prob *= (tmp + i)/(tmpSum + i);
			while(prob < 1e-100){
				prob *= 10.0;
				count ++;
			}
		}
		return Math.log(prob) - count*log10;
	}
	
	public double logProb(int lengthOne, int lengthTwo) {
		int count = 0;
		double tmpSum = eta + secBounds + nonSecBounds;
		double tmp = halfEta + nonSecBounds-2.0;
		double prob = (halfEta + secBounds)/(tmpSum);
		prob *= (halfEta + secBounds + 1.0)/(tmpSum+1.0);
		for(int i = 2; i < lengthOne + lengthTwo; i++) {
			prob *= (tmp + i)/(tmpSum + i);
			while(prob < 1e-100){
				prob *= 10.0;
				count ++;
			}
		}
		return Math.log(prob) - count*log10;
	}
	
	public double logLikelihood() {
		double val = Maths.logGamma(eta) - 2*Maths.logGamma(halfEta);
		val += Maths.logGamma(secBounds + halfEta)+ Maths.logGamma(nonSecBounds + halfEta) 
				- Maths.logGamma(numParas + eta);
		return val;
	}

}
