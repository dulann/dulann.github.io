package lengthModels;
import utils.MTRandom;


public abstract class SegPoissonDist extends PoissonDist {
//	protected static final double MAX = 1000;
//	protected static final double MIN = 0.001;
//	protected static final double shape = 2.0;
//	protected static final double scale = 2.0;
//	protected MTRandom rand;
//	
	public SegPoissonDist(MTRandom rand) {
		this.rand = rand;
	}
	
	public abstract void sampleLambda(int[][] segmentations);
	public abstract double logLikelihood(int[][] segmentations);
}
