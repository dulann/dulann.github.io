package lengthModels;
import utils.MTRandom;


public abstract class PoissonDist {

	protected static final double MAX = 1000;
	protected static final double MIN = 0.001;
	protected static final double shape = 2.0;
	protected static final double scale = 2.0;
	protected MTRandom rand;
	
	public abstract double logProb(int length, int topic);
	public abstract String lambdaToString();
}
