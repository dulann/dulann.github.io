package lengthModels;
import utils.Maths;

/**
 * 
 * @author landu
 *
 */
public class DocLenGeoDist {
	private final int numDocs;
	private double eta;
	private double halfEta;
	private int totalNumLastSecs;
	private int totalNumSecs;

	public DocLenGeoDist(double eta, int numDocs) {
		this.numDocs = numDocs;
		this.eta = eta;
		halfEta = eta/2.0;
		totalNumLastSecs = 0;
		totalNumSecs = 0;
	}
	
	public void addOneSec(boolean isLastSec) {
		totalNumSecs ++;
		if(isLastSec)
			totalNumLastSecs ++;
	}
	
	public void removeOneSec(boolean isLastSec){
		totalNumSecs --;
		if(isLastSec) {
			assert totalNumLastSecs == numDocs;
			totalNumLastSecs--;
		}
	}
	
	public void debug(int totalSegs) {
		assert totalNumLastSecs == numDocs;
		assert totalSegs == totalNumSecs;
	}

	public double expectedDocBoundProb() {
		return (halfEta + totalNumLastSecs)/(eta + totalNumSecs);
	}
	
	public double logProbOne(boolean isLastSec) {
		if(isLastSec)
			return Math.log((totalNumLastSecs + halfEta)/(totalNumSecs + eta));
		else 
			return Math.log((totalNumSecs - totalNumLastSecs + halfEta)/(totalNumSecs + eta));
	}
	
	public double logProbTwo(boolean isLastSec) {
		double val = (totalNumSecs - totalNumLastSecs + halfEta)/(totalNumSecs + eta);
		if(isLastSec){
			val *= (totalNumLastSecs + halfEta)/(totalNumSecs + 1.0 + eta);
		} else {
			val *= (totalNumSecs - totalNumLastSecs + 1.0 + halfEta)/(totalNumSecs + 1.0 + eta);
		}
		return Math.log(val);
	}
	
	public double logPosterior() {
		double val = Maths.logGamma(eta) - 2*Maths.logGamma(halfEta);
		val += Maths.logGamma(totalNumSecs - totalNumLastSecs + halfEta)+ Maths.logGamma(totalNumLastSecs + halfEta) 
				- Maths.logGamma(totalNumSecs + eta);
		return val;
	}
}
