package lengthModels;
import utils.MTRandom;
import utils.Maths;

public class SegLenPoisson extends SegPoissonDist {
	private double lambda;
	private double logLambda;
	
	public SegLenPoisson(double lambda, MTRandom rand) {
		super(rand);
		this.lambda = lambda;
		logLambda = Math.log(lambda);
	}
	
	public double logProb(int length, int k) {
		assert k == -1;
		double logProb;
		logProb = length * logLambda - lambda - Maths.logFactorial(length);
		if(Double.isInfinite(logProb) || Double.isNaN(logProb))
			throw new RuntimeException("Illegal log poisson desity = "+logProb + " for len = "+length);
		return logProb;
	}
	
	public double getLambda() {
		return lambda;
	}
	
	public String lambdaToString() {
		return lambda+"";
	}
	
	public void sampleLambda(int[][] segmentations) {
		int numSents = 0;
		int numSegs = 0;
		int tmp;
		for(int i = 0; i < segmentations.length; i++) {
			tmp = segmentations[i].length;
			numSents += tmp;
			numSegs += segmentations[i][tmp-1] + 1;
		}
		lambda = rand.nextGamma(shape+numSents, 1.0)/(1/scale + numSegs);
		assert lambda > 0;
		if(lambda > MAX)
			lambda = MAX;
		if(lambda < MIN)
			lambda = MIN;
		logLambda = Math.log(lambda);
	}
	
	public double logLikelihood(int[][] segmentations) {
		double val = 0;
		int sentTot = 0, segTot = 0;
		int spanLength, start, numSents;
		for(int i = 0; i < segmentations.length; i++) {
			start = 0;
			numSents = segmentations[i].length;
			sentTot += numSents;
			while(start < numSents){
				for (spanLength = 1; 
					 start + spanLength < numSents && segmentations[i][start + spanLength] == segmentations[i][start]; 
						spanLength++) {}
				val -= Maths.logFactorial(spanLength);
				segTot++;
				start += spanLength;
			}
		}
		val += (shape + sentTot -1)*logLambda - lambda*(segTot + 1.0/scale);
		val -=  Maths.logGamma(shape) + shape*Math.log(scale);
		
		if(Double.isInfinite(val) || Double.isNaN(val))
			throw new RuntimeException("Illegal posterior probability of Poisson model!!!");
		return val;
	}
}
