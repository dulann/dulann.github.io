package gmm;
import utils.MTRandom;
import utils.Stat;
import gnu.trove.list.array.TIntArrayList;
import gnu.trove.map.hash.TIntObjectHashMap;

/**
 * 
 * @author Lan Du
 * @since 31-May-2013
 */
public class TopTModel extends GMM{
	private MTRandom rand;
	private TIntObjectHashMap<TIntArrayList> topTOrderings;
	
	public TopTModel(int numTopics, int numDocs, double thetaZero, double sZero, MTRandom rand) {
		super(numTopics, thetaZero, sZero, rand);
		allocate(numDocs);
		topTOrderings = new TIntObjectHashMap<TIntArrayList>(numDocs);
	}
	
	/**
	 * Add the d-th ordering
	 * 
	 * @param d
	 * @param pi
	 */
	public void addPi(int d, TIntArrayList pi) {
		topTOrderings.put(d, pi);
		int[] s = pi2s(pi);
		for (int i = 0; i < s.length; i++) {
			assert ss[d][i] == Integer.MIN_VALUE;
			ss[d][i] = s[i];
			sTotal[i] += s[i];
			dTotal[i]++;
		}
	}
	
	/**
	 * remove the d-th old ordering
	 * 
	 * @param d
	 */
	public void removePi(int d) {
		topTOrderings.remove(d);
		for (int i = 0; i < ss[d].length; i++) {
			if (ss[d][i] != Integer.MIN_VALUE) {
				assert ss[d][i] >= 0;
				sTotal[i] -= ss[d][i];
				dTotal[i]--;
				ss[d][i] = Integer.MIN_VALUE;
			} else
				break;
		}
	}
	
	public int[] getPartialPi(int d) {
		return topTOrderings.get(d).toArray();
	}
	
	public double logProbPartialPi(TIntArrayList pi) {
		return logProPi(pi);
	}
	
	public int[] sample_pi(int size, double[] thetaValues) {
		int idx, k;
		double theta, probs[];
		int[] new_s = new int[size];
		for (int rank = 1; rank <= size; rank++) {
			probs = new double[numTopics - rank + 1];
			idx = rank - 1;
			if (rank == numTopics)
				theta = 0.0;
			else
				theta = thetaValues[idx];
			for (k = 0; k <= numTopics - rank; k++)
				probs[k] = Math.exp(-theta * k);
			new_s[idx] = Stat.sampleUnnormalised(probs, rand.nextDouble());
		}
		return s2pi(new_s).toArray();
	}

	

}
