package gmm;
import java.util.Arrays;

import gnu.trove.list.array.TIntArrayList;
import gnu.trove.map.hash.TIntIntHashMap;


public class TestGMM {
	
	private TIntArrayList sigma;
	private int numTopics;
	
	private TIntIntHashMap jcounts;
	
	public TestGMM(int numTopics) {
		this.numTopics = numTopics;
		this.sigma = new TIntArrayList();
		for (int i = 0; i < numTopics; i++)
			sigma.add(i);
		
		jcounts = new TIntIntHashMap(numTopics);
	}
	
	public TIntArrayList getCenterOrdering() {
		return sigma;
	}
	
	public TIntArrayList genMostProbExt(TIntArrayList pOrder) {
		pOrder = new TIntArrayList(pOrder);
		TIntArrayList candidates = new TIntArrayList(sigma);
		candidates.removeAll(pOrder);
		for(int i = 0; i < candidates.size(); i++) {
			int candidate = candidates.get(i);
			insert(candidate, pOrder);
		}
		return pOrder;
	}
	
	/**
	 * 
	 * @param candidate i
	 * @param pOrder sigma
	 */
	private void insert(int candidate, TIntArrayList pOrder) {
		int j, item, rank, count;
		jcounts.clear();
		int minCount = Integer.MAX_VALUE;
		int minj = 0;
		for(j = 0; j <= pOrder.size(); j++) {// for 0 <= j <= m
			count = 0;
			for(int n = 0; n < pOrder.size(); n++) {
				item = pOrder.get(n);
				rank = n + 1;
				if(rank <= j && sigma.indexOf(item) > sigma.indexOf(candidate))
					count ++;
				if(rank > j && sigma.indexOf(item) < sigma.indexOf(candidate))
					count ++;
			}
			if(count < minCount) {
				minCount = count;
				minj = j;
			}
		}
		pOrder.insert(minj, candidate);
	}
	
	public int sdistance(int[] pi) {
		int[] s = pi2s(pi);
		return (new TIntArrayList(s)).sum();
	}
	
	public int sdistance(TIntArrayList pi) {
		return sdistance(pi.toArray());
	}
	
	private int[] pi2s(int[] pi) {
		int tmp;
		int[] s = new int[pi.length];
		for (int j = 0; j < s.length; j++) {
			tmp = sigma.indexOf(pi[j]);
			for (int l = j - 1; l >= 0; l--)
				if (sigma.indexOf(pi[l]) < sigma.indexOf(pi[j]))
					tmp -= 1;
			s[j] = tmp;
		}
		if (pi.length == numTopics)
			assert s[numTopics - 1] == 0;
		return s;
	}

	
	
	public static void main(String[] args) {
		/*int[] intArr = {1,2,3,4,5};
		TIntArrayList arrlist = new TIntArrayList(intArr);
		arrlist.insert(arrlist.size(), 6);
		System.out.println("insert at poistion 5: "+arrlist);
		arrlist.insert(0, 7);
		System.out.println("insert at poistion 0: "+arrlist);
		arrlist.insert(1, 10);
		System.out.println("insert at poistion 1: "+arrlist);
		arrlist.insert(arrlist.size()-1, 11);
		System.out.println("insert at poistion 7: "+arrlist);*/
		TestGMM testGMM = new TestGMM(5);
		System.out.println("the center ordering: \t\t "+testGMM.getCenterOrdering());
		TIntArrayList probFull;
		/*int[] intArr1 = {1,2,3};
		TIntArrayList probFull = testGMM.genMostProbExt(new TIntArrayList(intArr1));
		System.out.println("the most probable full ordering: "+probFull);
		System.out.println("distance: "+testGMM.sdistance(probFull));
		
		int[] intArr2 = {2,1,3};
		probFull = testGMM.genMostProbExt(new TIntArrayList(intArr2));
		System.out.println("the most probable full ordering: "+probFull);
		System.out.println("distance: "+testGMM.sdistance(probFull));
		*/
		
		int[] intArr3 = {4,3,1};
		probFull = testGMM.genMostProbExt(new TIntArrayList(intArr3));
		System.out.println("partial ordering: "+ Arrays.toString(intArr3));
		System.out.println("the most probable full ordering: "+probFull);
		System.out.println("distance: "+testGMM.sdistance(probFull));
		
		int[] a4 = {0, 4, 2, 3, 1};
		System.out.println("the most probable full ordering: "+Arrays.toString(a4));
		System.out.println("distance: "+testGMM.sdistance(a4));
		int[] a44 = {2, 4, 0, 3, 1};
		System.out.println("the most probable full ordering: "+Arrays.toString(a44));
		System.out.println("distance: "+testGMM.sdistance(a44));
		
		int[] a5 = {0, 4, 3, 2, 1};
		System.out.println("the most probable full ordering: "+Arrays.toString(a5));
		System.out.println("distance: "+testGMM.sdistance(a5));
		int[] a55 = {2, 4, 3, 0, 1};
		System.out.println("the most probable full ordering: "+Arrays.toString(a55));
		System.out.println("distance: "+testGMM.sdistance(a55));
		
		int[] a6 = {0, 4, 3, 1, 2};
		System.out.println("the most probable full ordering: "+Arrays.toString(a6));
		System.out.println("distance: "+testGMM.sdistance(a6));
		int[] a66 = {2, 4, 3, 1, 0};
		System.out.println("the most probable full ordering: "+Arrays.toString(a66));
		System.out.println("distance: "+testGMM.sdistance(a66));
		
		int[] a7 = {4, 0, 3, 1, 2};
		System.out.println("the most probable full ordering: "+Arrays.toString(a7));
		System.out.println("distance: "+testGMM.sdistance(a7));
		int[] a77 = {4, 2, 3, 1, 0};
		System.out.println("the most probable full ordering: "+Arrays.toString(a77));
		System.out.println("distance: "+testGMM.sdistance(a77));
		
		int[] a8 = {4, 3, 0, 1, 2};
		System.out.println("the most probable full ordering: "+Arrays.toString(a8));
		System.out.println("distance: "+testGMM.sdistance(a8));
		int[] a88 = {4, 3, 2, 1, 0};
		System.out.println("the most probable full ordering: "+Arrays.toString(a88));
		System.out.println("distance: "+testGMM.sdistance(a88));
		
		int[] a9 = {4, 3, 1, 0, 2};
		System.out.println("the most probable full ordering: "+Arrays.toString(a9));
		System.out.println("distance: "+testGMM.sdistance(a9));
		int[] a99 = {4, 3, 1, 2, 0};
		System.out.println("the most probable full ordering: "+Arrays.toString(a99));
		System.out.println("distance: "+testGMM.sdistance(a99));
		
		int[] aa9 = {4, 3, 0, 2, 1 };
		System.out.println("the most probable full ordering: "+Arrays.toString(aa9));
		System.out.println("distance: "+testGMM.sdistance(aa9));
		int[] aa99 = {4, 3, 2, 0, 1};
		System.out.println("the most probable full ordering: "+Arrays.toString(aa99));
		System.out.println("distance: "+testGMM.sdistance(aa99));
		
		int[] aaa9 = {4, 0, 2, 3, 1 };
		System.out.println("the most probable full ordering: "+Arrays.toString(aaa9));
		System.out.println("distance: "+testGMM.sdistance(aaa9));
		int[] aaa99 = {4, 2, 0, 3, 1};
		System.out.println("the most probable full ordering: "+Arrays.toString(aaa99));
		System.out.println("distance: "+testGMM.sdistance(aaa99));
		
	}

}
