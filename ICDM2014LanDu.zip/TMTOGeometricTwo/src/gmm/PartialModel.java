package gmm;
import utils.MTRandom;
import gnu.trove.list.array.TIntArrayList;
import gnu.trove.map.hash.TIntObjectHashMap;


public class PartialModel extends GMM{
	private TIntObjectHashMap<TIntArrayList> partialPis;
	
	/**
	 * ]
	 * @param numTopics
	 * @param numDocs
	 * @param thetaZero
	 * @param sZero
	 * @param rand
	 */
	public PartialModel(int numTopics, int numDocs, double thetaZero, double sZero, MTRandom rand) {
		super(numTopics, thetaZero, sZero, rand);
		allocate(numDocs);
		partialPis = new TIntObjectHashMap<TIntArrayList>(numDocs);
	}
	
	/**
	 * 
	 */
	public void addPi(int d, TIntArrayList pi) {
		partialPis.put(d, pi);
		//find the most probable pi
//		System.out.println("=====> d ="+d +", partialPi = "+pi.toString());
		pi =  genMostProbExt(pi);
		assert pi.size() == numTopics;
//		System.out.println("=====> d ="+d +",    fullPi = "+pi.toString());
		int[] s = pi2s(pi);
		for (int i = 0; i < s.length; i++) {
			assert ss[d][i] == Integer.MIN_VALUE;
			ss[d][i] = s[i];
			sTotal[i] += s[i];
			dTotal[i]++;
		}
	}
	
	/**
	 * 
	 */
	public void removePi(int d) {
		partialPis.remove(d);
		for (int i = 0; i < ss[d].length; i++) {
			assert ss[d][i] >= 0;
			sTotal[i] -= ss[d][i];
			dTotal[i]--; 
			assert dTotal[i] == ss.length - 1;
			ss[d][i] = Integer.MIN_VALUE;
		}
	}
	
	/**
	 * Return a partial ordering
	 */
	public int[] getPartialPi(int d) {
		return partialPis.get(d).toArray();
	}

	public double logProbPartialPi(TIntArrayList pi) {
		return logProPi(genMostProbExt(pi));
	}
	
	/**
	 * Return a new full order
	 * @param pOrder
	 * @return
	 */
	private TIntArrayList genMostProbExt(TIntArrayList pOrder) {
		pOrder = new TIntArrayList(pOrder);
		TIntArrayList candidates = new TIntArrayList(sigma);
		candidates.removeAll(pOrder);
		for(int i = 0; i < candidates.size(); i++) {
			int candidate = candidates.get(i);
			insert(candidate, pOrder);
		}
		return pOrder;
	}
	
	/**
	 * 
	 * @param candidate i
	 * @param pOrder sigma
	 */
	private void insert(int candidate, TIntArrayList pOrder) {
		int j, item, rank, count;
		int minCount = Integer.MAX_VALUE;
		int minj = 0;
		for(j = 0; j <= pOrder.size(); j++) {// for 0 <= j <= m
			count = 0;
			for(int n = 0; n < pOrder.size(); n++) {
				item = pOrder.get(n);
				rank = n + 1;
				if(rank <= j && sigma.indexOf(item) > sigma.indexOf(candidate))
					count ++;
				if(rank > j && sigma.indexOf(item) < sigma.indexOf(candidate))
					count ++;
			}
			if(count < minCount) {
				minCount = count;
				minj = j;
			}
		}
		pOrder.insert(minj, candidate);
	}
}
