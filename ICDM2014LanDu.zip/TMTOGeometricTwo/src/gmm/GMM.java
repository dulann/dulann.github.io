package gmm;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

import lan.Parameters;
import utils.MTRandom;
import utils.SliceSampler;
import utils.Stat;
import gnu.trove.list.array.TDoubleArrayList;
import gnu.trove.list.array.TIntArrayList;

/**
 * 
 * @author Lan Du
 *
 */
public abstract class GMM {
	protected final int numTopics;
	private final double sZero;
	private MTRandom rand;
	protected TIntArrayList sigma; // center ordering
	protected double[] sprims;
	protected double[] thetas;
	private ThetaSampler thetaSamp;
	//statistics 
	protected int[][] ss;
	protected int[] sTotal;
	protected int[] dTotal;
	//cache
	private double[] logPhis;
	
	/**
	 * 
	 * @param numTopics
	 * @param thetaZero
	 * @param sZero
	 * @param rand
	 */
	public GMM(int numTopics, double thetaZero, double sZero, MTRandom rand) {
		this.numTopics = numTopics;
		this.sZero = sZero;
		this.rand = rand;
		this.sigma = new TIntArrayList(numTopics);
		for (int i = 0; i < numTopics; i++)
			sigma.add(i);
		sprims = new double[numTopics - 1];
		for (int j = 0; j < numTopics - 1; j++) {
			int kminusj = numTopics - j;
			sprims[j] = 1.0 / (Math.exp(thetaZero) - 1.0) - kminusj / (Math.exp(kminusj * thetaZero) - 1.0);
		}
		thetas = new double[numTopics - 1];
		Arrays.fill(thetas, thetaZero);
		thetaSamp = new ThetaSampler(rand);
		logPhis = new double[numTopics-1];
		computeLogPhis();
	}
	
	/**
	 * 
	 * @param numDocs #data points
	 */
	protected void allocate(int numDocs) {
		ss = new int[numDocs][numTopics];
		for (int i = 0; i < numDocs; i++)
			Arrays.fill(ss[i], Integer.MIN_VALUE);
		sTotal = new int[numTopics];
		Arrays.fill(sTotal, 0);
		dTotal = new int[numTopics];
		Arrays.fill(dTotal, 0);
	}
	
	/**
	 * 
	 * @param sigma
	 */
	public void setSigma(int[] sigma) {
		assert sigma.length == numTopics;
		this.sigma = new TIntArrayList(sigma);
	}
	
	/**
	 * 
	 * @param theta
	 */
	public void setThetas(double theta) {
		Arrays.fill(this.thetas, theta);
		computeLogPhis();
	}
	
	/**
	 * 
	 * @param theta
	 */
	public void setThetas(double[] theta) {
		System.arraycopy(theta, 0, thetas, 0, theta.length);
		computeLogPhis();
	}
	
	public double[] getThetas() {
		return thetas;
	}
	
	public abstract void addPi(int d, TIntArrayList pi);
	public abstract void removePi(int d);
	public abstract int[] getPartialPi(int d);
	public abstract double logProbPartialPi(TIntArrayList pi);
	
	
	private void computeLogPhis() {
		for (int idx = 0; idx < numTopics-1; idx++) {
			logPhis[idx] = Math.log1p(-Math.exp(-(numTopics - idx) * thetas[idx])) - Math.log1p(-Math.exp(-thetas[idx]));
		}
	}
	
	/**
	 * 
	 * @param pi
	 * @return
	 */
	protected double logProPi(TIntArrayList pi) {
		int[] proposed_s = pi2s(pi);
		int size = proposed_s.length;
		if (size == numTopics) size = numTopics - 1;
		double logVal = 0;
		for (int idx = 0; idx < size; idx++) {
			logVal += -thetas[idx] * proposed_s[idx] - logPhis[idx];
		}
		if (Double.isInfinite(logVal) || Double.isNaN(logVal))
			throw new RuntimeException("Illegal GMM log probability!!!");
		return logVal;
	}
	
	/**
	 * 
	 * @return
	 */
	public double loglikelihood() {
		double logProb = 0;
		for (int rank = 1; rank < numTopics; rank++) {
			int idx = rank - 1;
			logProb += -thetas[idx] * (sTotal[idx] + sprims[idx] * sZero)
						- (dTotal[idx] + sZero) * (Math.log1p(-Math.exp(-(numTopics - rank + 1) * thetas[idx])) - Math.log1p(-Math.exp(-thetas[idx])));
		}
		if (Double.isInfinite(logProb) || Double.isNaN(logProb))
			throw new RuntimeException(
					"Illegal posterior probability of Partial GMM!!!");
		return logProb;
	}
	
	/**
	 * Sample all theta values with a Slice sampler.
	 */
	public void sampleThetas() {
		thetaSamp.sampleThetas();
		computeLogPhis();
		if (Parameters.verbose >= 5000)
			System.out.println((new TDoubleArrayList(thetas)).toString());
	}
	
	/**
	 * 
	 * @return
	 */
	public int[] sample_pi() {
		return sample_pi(numTopics);
	}
	
	/**
	 * 
	 * @param size
	 * @return
	 */
	public int[] sample_pi(int size) {
		int idx, k;
		double theta, probs[];
		int[] new_s = new int[size];
		for (int rank = 1; rank <= size; rank++) {
			probs = new double[numTopics - rank + 1];
			idx = rank - 1;
			if (rank == numTopics)
				theta = 0.0;
			else
				theta = thetas[idx];
			for (k = 0; k <= numTopics - rank; k++)
				probs[k] = Math.exp(-theta * k);
			new_s[idx] = Stat.sampleUnnormalised(probs, rand.nextDouble());
		}
		return s2pi(new_s).toArray();
	}
	
	/**
	 * 
	 * @param str
	 */
	public void writePis(String str) {
		try {
			FileWriter writer = new FileWriter(str);
			for (int i = 0; i < ss.length; i++) {
				int[] pi = getPartialPi(i);
				for (int j = 0; j < pi.length; j++)
					if (j < pi.length - 1)
						writer.write(pi[j] + ",");
					else
						writer.write(pi[j] + "\n");
			}
			writer.flush();
			writer.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	/**
	 * 
	 * @param pi
	 * @return
	 */
	protected int[] pi2s(TIntArrayList pi) {
		int tmp;
		int[] s = new int[pi.size()];
		for (int j = 0; j < s.length; j++) {
			tmp = sigma.indexOf(pi.get(j));
			for (int l = j - 1; l >= 0; l--)
				if (sigma.indexOf(pi.get(l)) < sigma.indexOf(pi.get(j)))
					tmp -= 1;
			s[j] = tmp;
		}
		if (pi.size() == numTopics)
			assert s[numTopics - 1] == 0;
		return s;
	}

	/**
	 * 
	 * @param s
	 * @return
	 */
	protected TIntArrayList s2pi(int[] s) {
		if (s.length == numTopics)
			assert s[numTopics - 1] == 0;
		TIntArrayList tmpSigma = new TIntArrayList(sigma);
		TIntArrayList pi = new TIntArrayList(s.length);
		for (int i = 0; i < s.length; i++) {
			pi.add(tmpSigma.get(s[i]));
			tmpSigma.removeAt(s[i]);
		}
		return pi;
	}
	
	/**
	 * 
	 * @author Lan Du
	 *
	 */
	class ThetaSampler extends SliceSampler {
		private static final double MIN = 0.0001;
		private static final double MAX = 5000;
		private int st;
		private double sprim;
		private int dt;
		private int kminusj;
		/**
		 * 
		 * @param rand
		 */
		public ThetaSampler(MTRandom rand) {
			super(rand);
		}

		public double logpdf(double theta, Object params) {
			if (theta > 0)
				return -theta * (st + sprim * sZero)
						- (dt + sZero) * (Math.log1p(-Math.exp(-kminusj * theta)) - Math.log1p(-Math.exp(-theta)));
			else
				return Double.NEGATIVE_INFINITY;
		}

		/**
		 * 
		 * @param rank
		 * @param idx
		 */
		private void sample(int rank, int idx) {
			this.st = sTotal[idx];
			this.dt = dTotal[idx];
			this.sprim = sprims[idx];
			this.kminusj = numTopics - rank + 1;
			thetas[idx] = sliceSample1D(null, thetas[idx], MIN, MAX, thetas[idx] / 32.0, 50, 32);
		}
		
		/**
		 * 
		 */
		public void sampleThetas() {
			for (int rank = 1; rank <= thetas.length; rank++) {
				sample(rank, rank-1);
			}
		}
	}
}
