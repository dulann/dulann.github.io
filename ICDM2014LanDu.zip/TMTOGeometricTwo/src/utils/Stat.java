package utils;
import gnu.trove.list.array.TDoubleArrayList;
import gnu.trove.list.array.TIntArrayList;

public class Stat {
	
	public static int sampleUnnormalised(double[] probs, double rand) {
		double sum = 0;
		for (int i = 0; i < probs.length; i++)
			sum += probs[i];
		double scaledRandom = rand * sum;
		sum = 0;
		for (int i = 0; i < probs.length; i++) {
			sum += probs[i];
			if (scaledRandom < sum)
				return i;
		}
		return Math.round((float) Math.floor(rand * probs.length));
	}
	
	public static int sampleUnNormalizedLog(double[] logProb, double rand) {
		double maxLogProb = Double.NEGATIVE_INFINITY;
		int i;
		for (i = 0; i < logProb.length; i++)
			if (logProb[i] > maxLogProb)
				maxLogProb = logProb[i];
		double sum = 0.0;
		for (i = 0; i < logProb.length; i++) {
			logProb[i] = Math.exp(logProb[i] - maxLogProb);
			sum += logProb[i];
		}
		double scaledRandom = rand * sum;
		sum = 0.0;
		for (i = 0; i < logProb.length; i++) {
			sum += logProb[i];
			if (scaledRandom < sum)
				break;
		}
		// Special case
		if (i == logProb.length)
			i = Math.round((float) Math.floor(rand * logProb.length));
		assert i < logProb.length;
		return i;
	}
	
	public static String toString(double[] array) {
		return (new TDoubleArrayList(array)).toString();
	}
	
	public static String toString(int[] array) {
		return (new TIntArrayList(array)).toString();
	}
}
