import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class TrieNode<T> {

	private Character nodeKey;
	private T nodeValue;
	private boolean terminal;
	private Map<Character, TrieNode<T>> children
				= new HashMap<Character, TrieNode<T>>();
	
	 public Character getNodeKey() {
	        return nodeKey;
	    }
	 
	    public void setNodeKey(Character nodeKey) {
	        this.nodeKey = nodeKey;
	    }
	 
	    public T getNodeValue() {
	        return nodeValue;
	    }
	 
	    public void setNodeValue(T nodeValue) {
	        this.nodeValue = nodeValue;
	    }
	     
	    public boolean isTerminal() {
	        return terminal;
	    }
	 
	    public void setTerminal(boolean terminal) {
	        this.terminal = terminal;
	    }
	 
	    public Map<Character, TrieNode<T>> getChildren() {
	        return children;
	    }
	 
	    public void setChildren(Map<Character, TrieNode<T>> children) {
	        this.children = children;
	    }
	    
	    public boolean equals(Object o) {
			if (o instanceof TrieNode<?>) {
				@SuppressWarnings("unchecked")
				TrieNode<T> node = (TrieNode<T>) o;
				return nodeKey == node.getNodeKey() && nodeValue.equals(node.getNodeValue());
			}
			return false;
		}
	    
	    public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this);
		}
}
