import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Trie<T> {
	private TrieNode<T> rootNode = new TrieNode<T>();

	/**
	 * 
	 * @param key
	 * @param value
	 */
	public void add(String key, T value) {
		addNode(rootNode, key, 0, value);
	}

	/**
	 * 
	 * @param key
	 * @return
	 */
	public T find(String key) {
		return findKey(rootNode, key);
	}

	/**
	 * 
	 * @param prefix
	 * @return
	 */
	public List<T> search(String prefix) {
		List<T> list = new ArrayList<T>();

		char[] ch = prefix.toCharArray();
		TrieNode<T> node = rootNode;
		for (int i = 0; i < ch.length; i++) {
			node = node.getChildren().get(ch[i]);
			if (node == null) {
				break;
			}
		}

		if (node != null) {
			getValuesFromNode(node, list);
		}

		return list;
	}

	/**
	 * 
	 * @param key
	 * @return
	 */
	public boolean contains(String key) {
		return hasKey(rootNode, key);
	}

	/**
	 * 
	 * @return
	 */
	public Set<String> getAllKeys() {
		Set<String> keySet = new HashSet<String>();
		getKeysFromNode(rootNode, "", keySet);
		return keySet;
	}

	/**
	 * 
	 * @return
	 */
	public int size() {
		return getAllKeys().size();
	}

	/**
	 * 
	 * @param currNode
	 * @param valueList
	 */
	@SuppressWarnings("rawtypes")
	private void getValuesFromNode(TrieNode<T> currNode, List<T> valueList) {
		if (currNode.isTerminal()) {
			valueList.add(currNode.getNodeValue());
		}

		Map<Character, TrieNode<T>> children = currNode.getChildren();
		Iterator childIter = children.keySet().iterator();
		while (childIter.hasNext()) {
			Character ch = (Character) childIter.next();
			TrieNode<T> nextNode = children.get(ch);
			getValuesFromNode(nextNode, valueList);
		}
	}

	/**
	 * 
	 * @param currNode
	 * @param key
	 * @param keySet
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void getKeysFromNode(TrieNode<T> currNode, String key, Set keySet) {
		if (currNode.isTerminal()) {
			keySet.add(key);
		}

		Map<Character, TrieNode<T>> children = currNode.getChildren();
		Iterator childIter = children.keySet().iterator();
		while (childIter.hasNext()) {
			Character ch = (Character) childIter.next();
			TrieNode<T> nextNode = children.get(ch);
			String s = key + nextNode.getNodeKey();
			getKeysFromNode(nextNode, s, keySet);
		}
	}

	/**
	 * 
	 * @param currNode
	 * @param key
	 * @return
	 */
	private T findKey(TrieNode<T> currNode, String key) {
		Character c = key.charAt(0);
		if (currNode.getChildren().containsKey(c)) {
			TrieNode<T> nextNode = currNode.getChildren().get(c);
			if (key.length() == 1) {
				if (nextNode.isTerminal()) {
					return nextNode.getNodeValue();
				}
			} else {
				return findKey(nextNode, key.substring(1));
			}
		}

		return null;
	}

	/**
	 * 
	 * @param currNode
	 * @param key
	 * @return
	 */
	private boolean hasKey(TrieNode<T> currNode, String key) {
		Character c = key.charAt(0);
		if (currNode.getChildren().containsKey(c)) {
			TrieNode<T> nextNode = currNode.getChildren().get(c);
			if (key.length() == 1) {
				if (nextNode.isTerminal()) {
					return true;
				}
			} else {
				return hasKey(nextNode, key.substring(1));
			}
		}

		return false;
	}

	/**
	 * 
	 * @param currNode
	 * @param key
	 * @param pos
	 * @param value
	 */
	private void addNode(TrieNode<T> currNode, String key, int pos, T value) {
		Character c = key.charAt(pos);
		TrieNode<T> nextNode = currNode.getChildren().get(c);

		if (nextNode == null) {
			nextNode = new TrieNode<T>();
			nextNode.setNodeKey(c);
			if (pos < key.length() - 1) {
				addNode(nextNode, key, pos + 1, value);
			} else {
				nextNode.setNodeValue(value);
				nextNode.setTerminal(true);
			}
			currNode.getChildren().put(c, nextNode);
		} else {
			if (pos < key.length() - 1) {
				addNode(nextNode, key, pos + 1, value);
			} else {
				nextNode.setNodeValue(value);
				nextNode.setTerminal(true);
			}
		}
	}
//	
//	public static void main(String[] args) {
//		Trie<Integer> test = new Trie<Integer> ();
//		test.add("a", new Integer(1));
//		test.add("able", new Integer(2));
//		test.add("about", new Integer(3));
//		test.add("above", new Integer(4));
//		test.add("according", new Integer(5));
//		
//		System.out.println("size : "+test.size());
//		System.out.println("keys: "+test.getAllKeys());
//		System.out.println("contains able: "+test.contains("able"));
//		System.out.println("value of key able: "+test.find("able"));
//	}
}
