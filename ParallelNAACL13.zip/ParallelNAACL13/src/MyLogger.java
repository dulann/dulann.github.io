import java.util.logging.*;
import java.io.*;

public class MyLogger {
	static FileHandler fileTxt;

	public static void setup(String file) {
		System.out.println("Setup my logger!!!");
		Logger logger = Logger.getLogger("");
		
		Logger rootLogger = Logger.getLogger("");
		Handler[] handlers = rootLogger.getHandlers();
		assert handlers.length == 1;
		if(handlers[0] instanceof ConsoleHandler) {
			rootLogger.removeHandler(handlers[0]);
		}
		
		logger.setLevel(Level.FINER);
		try{
			fileTxt = new FileHandler(file);
			fileTxt.setFormatter(new SimpleFormatter());
			fileTxt.setLevel(Level.FINER);
			logger.addHandler(fileTxt);
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
}
