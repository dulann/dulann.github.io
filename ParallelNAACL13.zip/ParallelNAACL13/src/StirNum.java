import gnu.trove.list.array.TFloatArrayList;

import java.io.*;
//import java.util.logging.*;

/**
 * The following code pre-compute Stirling numbers
 * in log space, tabulates the values in a table
 * and loads the table in memory.
 * 
 * @author Du Lan
 *
 */
public final class StirNum {
//	private final static Logger logger = Logger.getLogger(StirNum.class.getName());
	public static final int EXPSIZE = 500;
	private static int maxN;
	private static int maxM;
	private static double a;
	private static TFloatArrayList stirlingTable;
	private static TFloatArrayList stirRatioOne;
	private static TFloatArrayList stirRatioTwo;
	private static TFloatArrayList stirRatioThree;

	/**
	 * Build a Stirling table with given parameters.
	 * 
	 * @param N
	 * @param M
	 * @param val
	 */
	public static void initialize(int N, int M, double val) {
		System.out.println("Make all the caches for stirling number with MAXN = "+N + ", MAXM = "+M);
		maxN = N;
		maxM = M;
		a = val;
		makeStirlingTable();
		makeCaches();
		System.out.println("Finished initializing stirling numbers!!!");
	}
	
	public static int maxN() {
		return maxN;
	}
	
	public static int maxM() {
		return maxM;
	}
	
	/**
	 * Return the log Stirling number, 
	 * \mathcal{S}^{N}_{M, a}
	 * 
	 * @param N
	 * @param M
	 * @return
	 */
	public static double logSN(int N, int M) {
		if (N > maxN || M > maxM) {
			System.err.println("Need to extend the cached stiriling numbers, set the cached maxN and maxM larger!!!");
			System.err.println("maxN = "+maxN +", N = "+N+", maxM = "+maxM+", M = "+M);
			System.exit(0);
		}
		return getValue(N, M);
	}
	
	/**
	 * Clear the memory allocated to the Stirling table.
	 */
	public static void clear() {
		stirlingTable.clear();
		stirRatioOne.clear();
		stirRatioTwo.clear();
		stirRatioThree.clear();
	}
	
	/**
	 * Return \frac{\mathcal{S}^{N+1}_{M+1, a}}{\mathcal{S}^{N}_{M, a}}
	 * 
	 * @param N
	 * @param M
	 * @return
	 */
	public static double ratioOne(int N, int M) {
		if (N >= maxN || M >= maxM) {
			System.err.println("Need to extend the cached stiriling numbers, set the cached maxN and maxM larger!!!");
			System.err.println("maxN = "+maxN +", N = "+N+", maxM = "+maxM+", M = "+M);
			System.exit(0);
		}
		return stirRatioOne.get(index(N, M));
	}
	
	/**
	 * Return \frac{\mathcal{S}^{N+1}_{M, a}}{\mathcal{S}^{N}_{M, a}}
	 * 
	 * @param N
	 * @param M
	 * @return
	 */
	public static double ratioTwo(int N, int M) {
		if (N >= maxN || M >= maxM) {
			System.err.println("Need to extend the cached stiriling numbers, set the cached maxN and maxM larger!!!");
			System.err.println("maxN = "+maxN +", N = "+N+", maxM = "+maxM+", M = "+M);
			System.exit(0);
		}
		return stirRatioTwo.get(index(N, M));
	}
	
	
	/**
	 * Return \frac{\mathcal{S}^{N}_{M, a}}{\mathcal{S}^{N}_{M-1, a}}
	 * 
	 * @param N
	 * @param M
	 * @return
	 */
	public static double ratioThree(int N, int M) {
		if (N >= maxN || M >= maxM) {
			System.err.println("Need to extend the cached stiriling numbers, set the cached maxN and maxM larger!!!");
			System.err.println("maxN = "+maxN +", N = "+N+", maxM = "+maxM+", M = "+M);
			System.exit(0);
		}
		return stirRatioThree.get(index(N, M));
	}
	
	/**
	 * Pre-compute all the three caches.
	 */
	private static void makeCaches() {
		int size = (maxM + 1) * (maxN + 1);
		stirRatioOne = new TFloatArrayList(size);
		stirRatioTwo = new TFloatArrayList(size);
		stirRatioThree = new TFloatArrayList(size);
		for (int i = 0; i < size; i++) {
			stirRatioOne.add(Float.NaN);
			stirRatioTwo.add(Float.NaN);
			stirRatioThree.add(Float.NaN);
		}
		double val;
		for(int N = 0; N <= maxN-1; N++) {
			for(int M = 0; M <= maxM-1 && M <= N; M++) {
				val = Math.exp(StirNum.logSN(N+1, M+1) - StirNum.logSN(N, M));
				stirRatioOne.set(index(N, M), (new Double(val)).floatValue());
			}
		}
		
		for(int N = 1; N <= maxN-1; N++) {
			for(int M = 1; M <= maxM-1 && M <= N; M++) {
				val = Math.exp(StirNum.logSN(N+1, M) - StirNum.logSN(N, M));
				stirRatioTwo.set(index(N, M), (new Double(val)).floatValue());
			}
		}
		
		for(int N = 2; N <= maxN; N++) {
			for(int M = 2; M <= maxM && M <= N; M++) {
				val = Math.exp(StirNum.logSN(N, M) - StirNum.logSN(N, M-1));
				stirRatioThree.set(index(N, M), (new Double(val)).floatValue());
			}
		}
	}

	/**
	 * Compute Stirling table
	 */
	private static void makeStirlingTable() {
		int size = (maxM + 1) * (maxN + 1);
		stirlingTable = new TFloatArrayList(size);
		for (int i = 0; i < size; i++) 
			stirlingTable.add(Float.NaN);

		for (int N = 1; N < maxN; N++) {
			setValue(N, 0, Float.NEGATIVE_INFINITY);
			for (int M = N + 1; M < maxM; M++) {
				setValue(N, M, Float.NEGATIVE_INFINITY);
			}
		}
		setValue(0, 0, 0);
		setValue(1, 1, 0);
		double value = 0.0;
		for (int N = 2; N <= maxN; N++) {
			for (int M = 1; M <= maxM && M <= N; M++) {
				if (N == M) {
					setValue(N, M, 0);
				} else {
					value = logSum(getValue((N - 1), (M - 1)), (Math.log((N
							- (M * a) - 1.0)) + getValue((N - 1), M)));
					setValue(N, M, new Double(value).floatValue());
				}
				if (new Double(value).isInfinite()) {
					System.err.format(
							"S_NM(%d, %d) gone infinit during adding\n", N, M);
					System.exit(0);
				}
			}
		}

	}

	private static double logSum(double V, double lp) {
		if (lp > V) {
			double t = lp;
			lp = V;
			V = t;
		}
		return V + Math.log(1.0 + Math.exp(lp - V));
	}
	
	private static int index(int N, int M) {
		return M * (maxN + 1) + N;
	}

	private static void setValue(int N, int M, float value) {
		stirlingTable.set(index(N, M), value);
	}

	private static float getValue(int N, int M) {
		return stirlingTable.get(index(N, M));
	}
	
	/**
	 * Save the stirling table
	 * @param fileName
	 */
	public static void save(String fileName) {
		try {
			FileWriter writer = new FileWriter(fileName);
			for (int N = 1; N <= maxN; N++) {
				for (int M = 1; M <= maxM && M <= N; M++) {
					writer.write(String.format("%.3f ", getValue(N, M)));
				}
				writer.write("\n");
			}
			writer.close();
		} catch (IOException ioe) {
		}
	}
	
	public static void saveRatioOne(String fileName) {
		try {
			FileWriter writer = new FileWriter(fileName);
			for (int N = 1; N <= maxN; N++) {
				for (int M = 1; M <= maxM && M <= N; M++) {
					writer.write(String.format("%.3f ", ratioOne(N, M)));
				}
				writer.write("\n");
			}
			writer.close();
		} catch (IOException ioe) {
		}
	}
	
	public static void saveRatioTwo(String fileName) {
		try {
			FileWriter writer = new FileWriter(fileName);
			for (int N = 1; N <= maxN; N++) {
				for (int M = 1; M <= maxM && M <= N; M++) {
					writer.write(String.format("%.3f ", ratioTwo(N, M)));
				}
				writer.write("\n");
			}
			writer.close();
		} catch (IOException ioe) {
		}
	}
	
	public static void saveRatioThree(String fileName) {
		try {
			FileWriter writer = new FileWriter(fileName);
			for (int N = 2; N <= maxN; N++) {
				for (int M = 2; M <= maxM && M <= N; M++) {
					writer.write(String.format("%.3f ", ratioThree(N, M)));
				}
				writer.write("\n");
			}
			writer.close();
		} catch (IOException ioe) {
		}
	}
	
//	public static void main(String[] args) {
//		StirNum.initialize(2000, 500, 0.2);
//		StirNum.save("./results/test/striling.log");
//		StirNum.saveRatioOne("./results/test/ratioOne.log");
//		StirNum.saveRatioTwo("./results/test/ratioTwo.log");
//		StirNum.saveRatioThree("./results/test/ratioThree.log");
//	}
}
