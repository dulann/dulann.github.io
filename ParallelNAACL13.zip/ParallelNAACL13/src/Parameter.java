import java.io.*;
import java.util.Arrays;

/**
 * 
 * @author Du Lan
 *
 */
public final class Parameter {
	//
	public static final int MAXN = 4000;
	public static final int MAXM = 3500;
	public static final int NUMTOPWORDS = 50;
	//
	public static boolean debug;
	//
	public static String root;
	public static int numTopics;
	//How to initialize segment
	public static int segInitCode;
	//Gamma parameter for learning b
	public static double scale = 1.0;
	public static double shape = 1.0;
	//Two shape parameters for Beta
	public static double lambda1;
	public static double lambda0;
	//Parameters for PDP
	public static double a;
	public static double b;
	public static boolean doOneTable;
	public static boolean sampleConcentration;
	//Dirichlet parameter for bag of topics
	public static double[] alpha;
	public static boolean learnAlpha = false;
	public static boolean usingSymmetricAlpha = false;
	public static double alphaSum;
	//Dirichlet parameter for bag of word
	public static double[] beta;
	public static double betaSum;
	//Gibbs parameters
	public static int maxItes;
	public static int burnIn;
	public static int lag;
	//number of threads
	public static int numThreads = 1;
	//
	public static int optAlphaLag = 1;
	public static int optConcentrationLag = 1;
	
	public static void setAlpha(double val) {
		alpha = new double[numTopics];
		Arrays.fill(alpha, val);
		alphaSum = numTopics*val;
	}
	
	public static void setBeta(double val, int vocSize) {
		beta = new double[vocSize];
		Arrays.fill(beta, val);
		betaSum = vocSize*val;
	}
	
	public static String getAlphaAsString() {
		String str = "";
		for(int i = 0; i < alpha.length; i++) {
			str += String.format("%.4f", alpha[i]);
			if(i < alpha.length -1)
				str+=",";
		}
		return str;
	}
	
	public static void createRoot(int chainIdx) {
		String str = String.format("k-%d-thread-%d-r-%d", numTopics, numThreads, chainIdx);
		root = root + File.separator + str;
		File file = new File(root);
		if(!file.exists())
			file.mkdirs();		
	}
	
	public static void save() {
		String str = root + File.separator+ "parameters.log";
		try{
			BufferedWriter writer = new BufferedWriter(new FileWriter(str));
			writer.write("root = "+root); writer.newLine();
			writer.write("numThreads = "+numThreads); writer.newLine();
			writer.write("numTopics = "+numTopics); writer.newLine();
			writer.write("segInitCode = "+segInitCode); writer.newLine();
			writer.write("scale = " + scale); writer.newLine();
			writer.write("shape = " + shape); writer.newLine();
			writer.write("lambda0 = " + lambda0); writer.newLine();
			writer.write("lambda1 = " + lambda1); writer.newLine();
			writer.write("alpha = " + alpha[0]); writer.newLine();
			writer.write("alphaSum = " + alphaSum); writer.newLine();
			writer.write("beta = " + beta[0]); writer.newLine();
			writer.write("betaSum = " + betaSum); writer.newLine();
			writer.write("a = " + a); writer.newLine();
			writer.write("b = "+b); writer.newLine();
			writer.write("doOneTable = "+doOneTable); writer.newLine();
			writer.write("learnB = "+sampleConcentration); writer.newLine();
			writer.write("maxItes = "+maxItes); writer.newLine();
			writer.write("burnIn = "+burnIn); writer.newLine();
			writer.write("lag = "+lag); writer.newLine();
			writer.write("optParamLag = "+optAlphaLag); writer.newLine();
			writer.write("learnAsyAlpha = "+learnAlpha); writer.newLine();
			writer.write("MAXN = "+MAXN); writer.newLine();
			writer.write("MAXM = "+MAXM); writer.newLine();
			writer.flush();
			writer.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
}
