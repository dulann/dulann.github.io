import gnu.trove.list.array.TIntArrayList;
import gnu.trove.map.hash.TIntObjectHashMap;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Logger;

/**
 * 
 * @author Du Lan
 *
 */
public final class DocLevelStats {
	private final static Logger logger = Logger.getLogger(DocLevelStats.class.getName());
	// segmentation
	public TIntObjectHashMap<ArrayList<Segment>> docSegsMap;
	public int[][] rhos;
	// topic assignment
	public int[][][] topics;
	// table counts at doc level
	public int[] td;
	public int[][] tdk;
	// boundary counts for each doc
	public int[] c1;
	public int[] c0;

	/**
	 * Allocate memory for counts.
	 * 
	 * @param corpus
	 * @param voc
	 */
	public DocLevelStats(Corpus corpus, Vocabulary voc) {
		logger.fine("initalise document level counts....");
		// Segmentation
		docSegsMap = new TIntObjectHashMap<ArrayList<Segment>>(corpus.numDocs()*4/3);
		rhos = new int[corpus.numDocs()][];
		for (int d = 0; d < corpus.numDocs(); d++) {
			docSegsMap.put(d, new ArrayList<Segment>(corpus.numSents(d)*4/3));
			rhos[d] = new int[corpus.numSents(d)];
			Arrays.fill(rhos[d], 0);
		}
		// Topic assignments
		topics = new int[corpus.numDocs()][][];
		for (int d = 0; d < corpus.numDocs(); d++) {
			topics[d] = new int[corpus.numSents(d)][];
			for (int s = 0; s < corpus.numSents(d); s++)
				topics[d][s] = new int[corpus.numTokens(d, s)];
		}
		// Table counts at doc level
		td = new int[corpus.numDocs()];
		Arrays.fill(td, 0);
		tdk = new int[corpus.numDocs()][Parameter.numTopics];
		for (int d = 0; d < corpus.numDocs(); d++)
			Arrays.fill(tdk[d], 0);
		// boundary counts for each doc
		c1 = new int[corpus.numDocs()];
		Arrays.fill(c1, 0);
		c0 = new int[corpus.numDocs()];
		Arrays.fill(c0, 0);
	}
	
	/**
	 * Function for debugging the model.
	 * 
	 * @param d
	 */
	public void checkDocSegList(int d) {
		ArrayList<Segment> docSegList = docSegsMap.get(d);
		TIntArrayList segIdxList = new TIntArrayList(docSegList.size());
		for(int i = 0; i < docSegList.size(); i++) {
			segIdxList.add(i);
		}
		assert docSegList.size() <= rhos[d].length;
		int segStart = 0;
		while(segStart < rhos[d].length) {
			Segment seg = findSegment(d, segStart);
			int segIdx = docSegList.indexOf(seg);
			segIdxList.remove(segIdx);;
			segStart = seg.end + 1;
		}
		assert segIdxList.size() == 0;
	}

	/**
	 * Function for debugging the model.
	 * 
	 * @param d
	 * @param corpus
	 */
	public void checkDoc(int d, Corpus corpus) {
		ArrayList<Segment> docSegList = docSegsMap.get(d);
		int sumT = 0;
		int sumN = 0;
		int sumtk[] = new int[Parameter.numTopics];
		Arrays.fill(sumtk, 0);
		for(int i = 0; i < docSegList.size(); i++) {
			Segment seg = docSegList.get(i);
			seg.validate();
			sumT += seg.T;
			sumN += seg.N;
			for(int k = 0; k < Parameter.numTopics; k++)
				sumtk[k] += seg.tk[k];
		}
		assert Arrays.equals(sumtk, tdk[d]);
		assert sumT == td[d];
		assert sumN == corpus.numTokens(d);
		assert sumN >= sumT;
		assert docSegList.size() == c1[d];
		assert c1[d] + c0[d] == corpus.numSents(d);
	}
	
	/**
	 * Average number of hypothetical segments per doc.
	 * 
	 * @return
	 */
	public double segRatio() {
		return (double) totalSegs()/c1.length;
	}
	
	/**
	 * The total number of hypothetical segments.
	 * 
	 * @return
	 */
	public int totalSegs() {
		int total = 0;
		for(int d = 0; d < c1.length; d++)
			total += c1[d];
		return total;
	}

	/**
	 * Return the segment that contains a given sentence/paragraph.
	 * 
	 * @param d
	 * @param s
	 * @return
	 */
	public Segment findSegment(int d, int s) {
		ArrayList<Segment> docSegList = docSegsMap.get(d);
		Segment seg;
		for (int i = 0; i < docSegList.size(); i++) {
			seg = docSegList.get(i);
			if (seg.contains(s))
				return seg;
		}
		return null;
	}
	
	/**
	 * 
	 * @param file
	 */
	public void saveRhoSample(String file) {
		try{
			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			for (int d = 0; d < rhos.length; d++) {
				StringBuffer buffer = new StringBuffer();
				for (int s = 0; s < rhos[d].length; s++) {
					buffer.append(rhos[d][s]);
					if (s < rhos[d].length - 1)
						buffer.append(",");
				}
				writer.write(buffer.toString());
				writer.newLine();
			}
			writer.flush();
			writer.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void saveTopicAssignment(String file) {
		logger.info("Save topic assignemnts......");
		try{
			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			writer.write("D=" + topics.length);
			writer.newLine();
			for (int d = 0; d < topics.length; d++) {
				writer.write("S=" + topics[d].length);
				writer.newLine();
				for (int s = 0; s < topics[d].length; s++) {
					for (int w = 0; w < topics[d][s].length; w++) {
						writer.write(topics[d][s][w]+"");
						if (w < topics[d][s].length - 1)
							writer.write(",");
					}
					writer.newLine();
				}
			}
			writer.flush();
			writer.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
}
