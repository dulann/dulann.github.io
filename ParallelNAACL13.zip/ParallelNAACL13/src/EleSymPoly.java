import java.util.*;

/**
 * The following code is rewritten from the C code
 * by Dr. Wray Buntine.
 * 
 * @author Du Lan
 *
 */
public class EleSymPoly
{
	private static final boolean debug = false;
	
	private MTRandom rand;
	
	public EleSymPoly(MTRandom rand) {
		this.rand = rand;
	}

	public int sympoly(List<Double> val, double[] res, double[] overFlow)
	{
		if(debug){
			assert overFlow.length == 1;
			assert val.size() + 1 == res.length;
		}

		int h, k;
		double mult = 1.0; // keeps scaled res[0]
		int K = val.size();
		/*
		 * e_0=1 regardless
		 */
		overFlow[0] = 0;
		res[0] = 1.0;
		if (K == 0)
			return 0;

		for (k = 1; k <= K; k++)
			res[k] = 0.0;

		res[1] = val.get(0).doubleValue();
		for (k = 1; k < K; k++) {
			double vk = val.get(k).doubleValue();
			if (vk > 1) {
				double lastv = mult;
				mult /= vk;
				overFlow[0] += Math.log(vk);
				for (h = 1; h <= k; h++) {
					double thisv = res[h];
					res[h] = thisv / vk + lastv;
					lastv = thisv;
				}
				res[h] = lastv;
			} else {
				double lastv = mult;
				for (h = 1; h <= k; h++) {
					double thisv = res[h];
					res[h] += vk * lastv;
					lastv = thisv;
				}
				res[h] = vk * lastv;
			}
		}
		if (overFlow[0] < 15) {
			/*
			 * remove overflow if doesn't appear useful
			 */
			double eo = Math.exp(overFlow[0]);
			for (h = 1; h <= K; h++)
				res[h] *= eo;
			overFlow[0] = 0;
		}
		return 0;
	}
	
	public int[] sympoly_sampled_index(int H, List<Double> val)
	{
		if (debug)
			assert H <= val.size() : "Error: H > val.size()";

		long res = sympoly_sample(H, val);
		String bits = Long.toBinaryString(res);

		if (debug)
			System.out.println(bits);

		int[] bitVector = new int[val.size()];
		Arrays.fill(bitVector, 0);
		int lastIndex = bits.length() - 1;
		for (int i = lastIndex; i >= 0; i--) {
			if (bits.charAt(i) == '0') {
				bitVector[lastIndex - i] = 0;
			} else if (bits.charAt(i) == '1') {
				bitVector[lastIndex - i] = 1;
			}
		}
		return bitVector;
	}
	
	public long sympoly_sample(int H, List<Double> val)
	{
		int k;
		int K = val.size();
		double sum;
		if (H > K || K == 0 || H == 0)
			return 0L;
		if (H == K) {
			return (1L << H) - 1;
		}
		if (H > 1) {
			return sympoly_sample_full(H, val);
		}
		if(debug)
			assert H == 1 : "Error: H != 1";
		/*
		 * standard vector sampler for H=1 case
		 */
		sum = 0;
		for (k = 0; k < K; k++) {
			sum += val.get(k).doubleValue();
		}
		sum *= rand.nextDouble();
		for (k = 0; k < K && sum > 0; k++) {
			sum -= val.get(k).doubleValue();
		}
		if(debug){
			yap("k = "+k);
			assert k > 0 : "Error: k <= 0";
		}
		return 1L << (k - 1);
	}

	private long sympoly_sample_full(int H, List<Double> val)
	{
		int h, k;
		int K = val.size();
		double[] esp = new double[K * K];
		double mult = 1.0;
		if (debug) {
			assert K > 1;
			assert H > 1;
			assert H < K;
		}

		/*
		 * fill up matrix, O(HK)
		 */
		esp[0] = val.get(0).doubleValue();
		for (k = 1; k < K; k++) {
			double vk = val.get(k).doubleValue();
			if (vk > 1.0) {
				double lastv = mult;
				mult /= vk;
				for (h = 0; h < k && h < H; h++) {
					double thisv = esp[k - 1 + h * K];
					esp[k + h * K] = thisv / vk + lastv;
					lastv = thisv;
				}
				if (h == k)
					esp[k + h * K] = lastv;
			} else {
				double lastv = mult;
				for (h = 0; h < k && h < H; h++) {
					double thisv = esp[k - 1 + h * K];
					esp[k + h * K] = thisv + vk * lastv;
					lastv = thisv;
				}
				if (h == k)
					esp[k + h * K] = vk * lastv;
			}
		}
		/*
		 * recurse back
		 */
		long wr = 0;
		for (k = K - 1, h = H; k >= h && h > 0; k--) {
			if (debug) {
				assert k >= 1 : "Error: k < 1";
				assert isnormal(esp[k + (h - 1) * K]) : "Error: esp is not normal";
				assert isnormal(esp[k - 1 + (h - 1) * K]) : "Error: esp is not normal";
			}
			if (val.get(k).doubleValue() <= 1.0) {
				if (esp[k + (h - 1) * K] * rand.nextDouble() >= esp[k - 1 + (h - 1) * K]) 
				{
					if(debug)
						yap("k = "+k);
					wr |= 1L << k;
					h--;
				}
			} else {
				if (esp[k + (h - 1) * K] * rand.nextDouble() >= esp[k - 1 + (h - 1) * K]/ val.get(k).doubleValue()) 
				{
					if(debug)
						yap("k = "+k);
					wr |= 1L << k;
					h--;
				}
			}
		}

		if (debug)
			assert h == (k + 1) || h == 0;
		if (h > 0)
			wr |= (1L << h) - 1;
		return wr;
	}
	
	private boolean isnormal(double val) {
		return !Double.isInfinite(val) && !Double.isNaN(val)
				&& Math.abs(val) >= Double.MIN_NORMAL;
	}

	void yap(Object obj) {
		System.out.println(obj);
	}
}
