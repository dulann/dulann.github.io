import java.io.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;
import cc.mallet.types.Dirichlet;
import cc.mallet.util.Maths;

/**
 * 
 * @author Du Lan
 *
 */
public class NAACL13STSM {
	private final static Logger logger = Logger.getLogger(NAACL13STSM.class.getName());
	private Corpus corpus;
	private Vocabulary voc;
	private DocLevelStats dls;
	private CorpusLevelStats globalCLS;
	private ConcentrationSampler csampler;
	private StopWordList stopWordList;
	private int margCounts[][]; // where to keep samples;
	// for Dirichlet estimation
	public int[] docLengthCounts; // histogram of document sizes
	public int[][] topicDocCounts; // histogram of document/topic counts, indexed by <topic index, sequence position index>
	
	public NAACL13STSM(Corpus corpus, Vocabulary voc) {
		this.corpus = corpus;
		this.voc = voc;
		dls = new DocLevelStats(corpus, voc);
		globalCLS = new CorpusLevelStats(voc.size(), Parameter.numTopics);
		initialise();
		//Create three different samplers
		csampler = new ConcentrationSampler(dls);
		//allocate space for holding boundary samples
		margCounts = new int[corpus.numDocs()][];
		for(int d = 0; d < corpus.numDocs(); d++) {
			margCounts[d] = new int[corpus.numSents(d)];
			Arrays.fill(margCounts[d], 0);
		}
		if(Parameter.learnAlpha) {
			docLengthCounts = new int[corpus.maxNumTokenPerDoc()+1];
			topicDocCounts = new int[Parameter.numTopics][corpus.maxNumTokenPerDoc()+1];
		}
		stopWordList = new StopWordList();
	}
	
	/**
	 * Run parallel Gibbs sampling algorithm.
	 * 
	 * @param ite
	 */
	public void estimate() {
		long startTime = System.currentTimeMillis();
		SegmenterRunnable[] runnables = new SegmenterRunnable[Parameter.numThreads];
		int docsPerThread = corpus.numDocs()/Parameter.numThreads;
		logger.fine("docsPerThread = "+docsPerThread);
		int offset = 0;
		/*
		 * Create threads
		 */
		if(Parameter.numThreads > 1) {
			for(int thread = 0; thread < Parameter.numThreads; thread++) {
				CorpusLevelStats threadCLSCopy = new CorpusLevelStats(globalCLS);
				if(thread == Parameter.numThreads - 1) {
					docsPerThread = corpus.numDocs() - offset;
				}
				MTRandom rand = new MTRandom(System.currentTimeMillis());
				runnables[thread] = new SegmenterRunnable(corpus, dls, threadCLSCopy, rand, offset, docsPerThread);
				if(Parameter.learnAlpha)
					runnables[thread].initializeAlphaStatistics(docLengthCounts.length);
				offset += docsPerThread;
			}
			assert offset == corpus.numDocs();
		} else {
			runnables[0] = new SegmenterRunnable(corpus, dls, globalCLS, new MTRandom(), offset, docsPerThread);
			if(Parameter.learnAlpha)
				runnables[0].initializeAlphaStatistics(docLengthCounts.length);
			runnables[0].makeOnlyThread();
		}
		ExecutorService executor = Executors.newFixedThreadPool(Parameter.numThreads);
		/*
		 * Start parallel Gibbs sampling
		 */
		int numSamples = 0;
		for (int ite = 1; ite <= Parameter.maxItes; ite++) {
			long iterationStart = System.currentTimeMillis();
			if(Parameter.numThreads > 1) {
				for (int thread = 0; thread < Parameter.numThreads; thread++) {
					if(Parameter.learnAlpha && ite % Parameter.optAlphaLag == 0) {
						runnables[thread].collectAlphaStatistics();
					}
					logger.log(Level.FINEST, "ite = "+ite+", submitting thread: " + thread);
					executor.submit(runnables[thread]);
				}
				try {
					Thread.sleep(20);
				} catch (InterruptedException e) {}
				
				boolean finished = false;
				while (!finished) {
					try {
						Thread.sleep(20);
					} catch (InterruptedException e) {}
					finished = true;
					for (int thread = 0; thread < Parameter.numThreads; thread++) {
						finished = finished && runnables[thread].isFinished;
					}
				}
				//update the global CorpusLevelState
				sumTypeTopicCounts(runnables);
				//update the thread's copy of CorpusLevelState
				for (int thread = 0; thread < Parameter.numThreads; thread++) {
					CorpusLevelStats threadCLS = runnables[thread].getThreadCLS();
					System.arraycopy(globalCLS.MK, 0, threadCLS.MK, 0, Parameter.numTopics);
					for(int w = 0; w < voc.size(); w++) {
						System.arraycopy(globalCLS.MWK[w], 0, threadCLS.MWK[w], 0, Parameter.numTopics);
					}
				}
				
			} else {
				if(Parameter.learnAlpha && ite % Parameter.optAlphaLag == 0) {
					runnables[0].collectAlphaStatistics();
				}
				runnables[0].run();
			}
			long elapsedMillis = System.currentTimeMillis() - iterationStart;
			double eclapsedSecs = elapsedMillis/1000.0;
			
			//printout other diagnostic information: model log likelihood
			double lll = modelLogLikelihood();
			if(lll >= 20.0)
				logger.log(Level.WARNING, String.format("ite = %d, -likelihood = %.6f", ite, lll));
			logger.log(Level.INFO, String.format("ite=%d, eclapsedSecs=%.6f, -likelihood=%.6f, numSegs=%d, "
						+ "hypoAvgSegs=%.5f,  trueAvgSegs=%.5f, b=%.5f\n",
						ite, eclapsedSecs, lll, dls.totalSegs(), dls.segRatio(),
						corpus.aveNumSegPerDoc(), Parameter.b));
			//optimizing hyper-parameters
			if (Parameter.sampleConcentration && ite % Parameter.optConcentrationLag == 0)
				csampler.sample_b();
			if(Parameter.learnAlpha && ite % Parameter.optAlphaLag == 0)
				optimizeAlpha(runnables);
			// Draw samples
			if (ite > Parameter.burnIn && ite % Parameter.lag == 0) {
				for (int d = 0; d < corpus.numDocs(); d++) {
					for (int s = 0; s < corpus.numSents(d); s++)
						margCounts[d][s] += dls.rhos[d][s];
				}
				numSamples++;
				saveStats(Parameter.root+File.separator+"sample-"+numSamples);
				logger.info("alpha="+Parameter.getAlphaAsString());
				logger.info("alphaSum="+Parameter.alphaSum);
			}
			
		}
		executor.shutdownNow();
		
		if (Parameter.debug) {
			for (int d = 0; d < corpus.numDocs(); d++)
				assert margCounts[d][corpus.numSents(d) - 1] == numSamples;
		}
		
		long seconds = Math.round((System.currentTimeMillis() - startTime)/1000.0);
		long minutes = seconds / 60;	seconds %= 60;
		long hours = minutes / 60;	minutes %= 60;
		long days = hours / 24;	hours %= 24;

		StringBuilder timeReport = new StringBuilder();
		timeReport.append("\nTotal time: ");
		if (days != 0) { timeReport.append(days); timeReport.append(" days "); }
		if (hours != 0) { timeReport.append(hours); timeReport.append(" hours "); }
		if (minutes != 0) { timeReport.append(minutes); timeReport.append(" minutes "); }
		timeReport.append(seconds); timeReport.append(" seconds");
//		logger.info(timeReport.toString());
//		logger.info("alpha="+Parameter.getAlphaAsString());
	}
	
	/**
	 * Reduce step
	 * 
	 * @param runnables
	 */
	private void sumTypeTopicCounts(SegmenterRunnable[] runnables) {
		Arrays.fill(globalCLS.MK, 0);
		for(int w = 0; w < voc.size(); w++) {
			Arrays.fill(globalCLS.MWK[w], 0);
		}
		
		for (int thread = 0; thread < Parameter.numThreads; thread++) {
			CorpusLevelStats threadCLS = runnables[thread].getThreadCLS();
			//update MK
			for(int k = 0; k < Parameter.numTopics; k++)
				globalCLS.MK[k] += threadCLS.MK[k];
			//update MWK
			for(int w = 0; w < voc.size(); w++) {
				for(int k = 0; k < Parameter.numTopics; k++)
					globalCLS.MWK[w][k] += threadCLS.MWK[w][k];
			}
		}
		if(Parameter.debug) {
			globalCLS.debug(corpus);
		}
	}
	
	public void saveFinalStats(String folder) {
		try {
			File fileFolder = new File(folder);
			if(!fileFolder.exists())
				fileFolder.mkdir();
			// save marginal rho counts
			String str = folder + File.separator + "sampled_marginal_rhos.log";
			BufferedWriter writer = new BufferedWriter(new FileWriter(str));
			for (int d = 0; d < margCounts.length; d++) {
				StringBuffer buffer = new StringBuffer();
				for (int s = 0; s < margCounts[d].length; s++) {
					buffer.append(margCounts[d][s]);
					if (s < margCounts[d].length - 1)
						buffer.append(",");
				}
				writer.write(buffer.toString());
				writer.newLine();
			}
			writer.flush();
			writer.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		// save sampled rho values
		dls.saveRhoSample(folder + File.separator + "final_rhos_at_last_ite.log");
		// save topic-by-word count matrix
		globalCLS.saveTopicWordCountMatrix(voc, folder + File.separator + "final_word_topic_counts.log");
		// save counts for computing PMI scores
		globalCLS.saveCountsForPMIscores(voc, stopWordList, folder + File.separator + "final_count4pmiscores.log");
		// save top words for each topic
		globalCLS.saveTopWord4Topic(voc, stopWordList, folder + File.separator + "final_top_words_for_topics.log");
		// save topic assignment
		dls.saveTopicAssignment(folder + File.separator + "final_topicAssignments.log");
	}
	
	private void saveStats(String folder) {
		File fileFolder = new File(folder);
		if(!fileFolder.exists())
			fileFolder.mkdir();
		// save sampled rho values
		dls.saveRhoSample(folder + File.separator + "rhos.log");
		// save topic-by-word count matrix
//		globalCLS.saveTopicWordCountMatrix(voc, folder + File.separator + "word_topic_counts.log");
		// save counts for computing PMI scores
		globalCLS.saveCountsForPMIscores(voc, stopWordList, folder + File.separator + "count4pmiscores.log");
		// save top words for each topic
//		globalCLS.saveTopWord4Topic(voc, stopWordList, folder + File.separator + "top_words_for_topics.log");
		// save topic assignment
		dls.saveTopicAssignment(folder + File.separator + "topicAssignments.log");
	}
	
	private double modelLogLikelihood() {
		double logProb = 0.0;
		for (int d = 0; d < corpus.numDocs(); d++) {
			logProb += Maths.logBeta(Parameter.lambda1 + dls.c1[d], Parameter.lambda0 + dls.c0[d]);
			logProb -= Maths.logBeta(Parameter.lambda1, Parameter.lambda0);
			logProb += Dirichlet.logGamma(Parameter.alphaSum) - Dirichlet.logGamma(Parameter.alphaSum + dls.td[d]);
			for (int k = 0; k < Parameter.numTopics; k++)
				logProb += Dirichlet.logGamma(Parameter.alpha[k] + dls.tdk[d][k]) - Dirichlet.logGamma(Parameter.alpha[k]);
			ArrayList<Segment> docSegList = dls.docSegsMap.get(d);
			for (int s = 0; s < docSegList.size(); s++) {
				Segment seg = docSegList.get(s);
				logProb += logPochSym(Parameter.b, Parameter.a, seg.T) - logPochSym(Parameter.b, 1.0, seg.N);
				// assert Maths.isnormal(logProb) : "logProb = " + logProb;
				for (int k = 0; k < Parameter.numTopics; k++) {
					logProb += StirNum.logSN(seg.nk[k], seg.tk[k]);
					logProb -= logChoose(seg.nk[k], seg.tk[k]);
				}
				// assert Maths.isnormal(logProb) : "logProb = " + logProb;
			}
		}
		for (int k = 0; k < Parameter.numTopics; k++) {
			logProb += Dirichlet.logGamma(Parameter.betaSum)
							- Dirichlet.logGamma(Parameter.betaSum + globalCLS.MK[k]);
			for (int w = 0; w < voc.size(); w++) {
				logProb += Dirichlet.logGamma(Parameter.beta[w] + globalCLS.MWK[w][k])
							- Dirichlet.logGamma(Parameter.beta[w]);
			}
		}
		logProb = -logProb / corpus.numTokens();

		if (Double.isInfinite(logProb) || Double.isNaN(logProb)) {
			System.err.println("modelLogLikelihood(): logProb is infinite or NaN!!!");
			System.exit(0);
		}

		return logProb;
	}
	
	/**
	 * Log choose function
	 * 
	 * @param n
	 * @param r
	 * @return
	 */
	public static double logChoose(int n, int r) {
		return Maths.logFactorial(n) - Maths.logFactorial(r) - Maths.logFactorial(n - r);
	}
	
	/**
	 * This function computes the log of Pochhammer symbol.
	 * 
	 * @param x
	 * @param y
	 * @param n
	 * @return
	 */
    public static double logPochSym(double x, double y, double n) {
        double logValue;
        if (y == 0.0) {
            logValue = n * Math.log(x);
        } else {
            double tmp = x / y;
            logValue = Dirichlet.logGamma(tmp + n) - Dirichlet.logGamma(tmp) + n * Math.log(y);
        }
        return logValue;
    }
	
    /**
     * The code is adapted from ParallelTopicModel.java in Mallet. But 
     * I did not used in my experiments.
     * 
     * @param runnables
     */
	private void optimizeAlpha(SegmenterRunnable[] runnables) {
		Arrays.fill(docLengthCounts, 0);
		for (int topic = 0; topic < topicDocCounts.length; topic++) {
			Arrays.fill(topicDocCounts[topic], 0);
		}
		//collect counts from threads, and reset thread's counts to 0
		for (int thread = 0; thread < Parameter.numThreads; thread++) {
			int[] sourceLengthCounts = runnables[thread].getDocLengthCounts();
			int[][] sourceTopicCounts = runnables[thread].getTopicDocCounts();
			for (int count=0; count < sourceLengthCounts.length; count++) {
				if (sourceLengthCounts[count] > 0) {
					docLengthCounts[count] += sourceLengthCounts[count];
					sourceLengthCounts[count] = 0;
				} else assert docLengthCounts[count] == 0;
			}
			for (int topic=0; topic < Parameter.numTopics; topic++) {
				if (!Parameter.usingSymmetricAlpha) {
					for (int count=0; count < sourceTopicCounts[topic].length; count++) {
						if (sourceTopicCounts[topic][count] > 0) {
							topicDocCounts[topic][count] += sourceTopicCounts[topic][count];
							sourceTopicCounts[topic][count] = 0;
						} else assert sourceTopicCounts[topic][count] == 0;
					}
				} else {
					for (int count=0; count < sourceTopicCounts[topic].length; count++) {
						if (sourceTopicCounts[topic][count] > 0) {
							topicDocCounts[0][count] += sourceTopicCounts[topic][count];
							sourceTopicCounts[topic][count] = 0;
						} else assert sourceTopicCounts[topic][count] == 0;
					}
				}
			}
		}

		if (Parameter.usingSymmetricAlpha) {
			Parameter.alphaSum = Dirichlet.learnSymmetricConcentration(topicDocCounts[0], docLengthCounts, 
									Parameter.numTopics, Parameter.alphaSum);
			for (int topic = 0; topic < Parameter.numTopics; topic++) {
				Parameter.alpha[topic] = Parameter.alphaSum / Parameter.numTopics;
			}
		} else {
			Parameter.alphaSum = Dirichlet.learnParameters(Parameter.alpha, topicDocCounts, docLengthCounts, 1.001, 1.0, 1);
		}
		logger.finer("alphaSum="+Parameter.alphaSum);
		logger.finer("alphas="+Parameter.getAlphaAsString());
	}
	
	/**
	 * Initialize the model.
	 * 
	 * @param corpus
	 * @param rand
	 */
	public void initialise() {
		System.out.println("Start initialise topic assignments and topic boundaries....");
		MTRandom rand = new MTRandom(System.currentTimeMillis());
		int d, sIdx, s, n, m, wIdx;
		int w, k;
		ArrayList<Segment> docSegList;
		Segment seg;
		// initialize segmentation
		initSeg();
		// initialize topic assignments
		for (d = 0; d < corpus.numDocs(); d++) {
			docSegList = dls.docSegsMap.get(d);
			for (sIdx = 0; sIdx < docSegList.size(); sIdx++) { // for each segment
				seg = docSegList.get(sIdx);
				for (s = seg.start; s <= seg.end; s++) { // for each sentence
					wIdx = 0;
					for (n = 0; n < corpus.numTypes(d, s); n++) { // for each type
						w = corpus.type(d, s, n);
						for (m = 0; m < corpus.count(d, s, n); m++) {
							k = rand.nextInt(Parameter.numTopics);
							dls.topics[d][s][wIdx] = (short) k;
							seg.N++;
							seg.nk[k]++;
							globalCLS.MK[k]++;
							globalCLS.MWK[w][k]++;
							wIdx++;
						}
					}
					assert wIdx == corpus.numTokens(d, s);
				}
				if (Parameter.doOneTable) {// one table per exiting topic
					for (k = 0; k < Parameter.numTopics; k++) {
						if (seg.nk[k] > 0) {
							seg.tk[k] = 1;
							seg.T++;
							dls.td[d]++;
							dls.tdk[d][k]++;
						}
					}
				} else {
					for (k = 0; k < Parameter.numTopics; k++) {
						seg.tk[k] = seg.nk[k];
						seg.T += seg.nk[k];
						dls.td[d] += seg.nk[k];
						dls.tdk[d][k] += seg.nk[k];
					}
				}
			}
			dls.checkDoc(d, corpus);
			dls.checkDocSegList(d);
		}
		globalCLS.debug(corpus);
		System.out.println("Finished initialization!!");
	}

	/***********************************************************************
	 * Initialize segmentation. For each doc, 
	 * code = 0: put all paragraphs/sentences in one segment. 
	 * code = 1: put each paragraph in a segment.
	 * code = 2: do true segmentation
	 * 
	 * @param code
	 **********************************************************************/
	private void initSeg() {
		if (Parameter.segInitCode == 0) {
			initOneSeg();
		} else if (Parameter.segInitCode == 1) {
			initAllSeg();
		} else if (Parameter.segInitCode == 2) {
			initTrueSeg();
		}
	}

	private  int initOneSeg() {
		for (int d = 0; d < corpus.numDocs(); d++) {
			dls.rhos[d][corpus.numSents(d) - 1] = 1;
			dls.docSegsMap.get(d).add(new Segment(0, corpus.numSents(d) - 1, d));
			dls.c1[d] = 1;
			dls.c0[d] = corpus.numSents(d) - 1;
		}
		return corpus.numDocs();
	}

	private  int initAllSeg() {
		ArrayList<Segment> docSegList;
		for (int d = 0; d < corpus.numDocs(); d++) {
			docSegList = dls.docSegsMap.get(d);
			assert docSegList.isEmpty();
			for (int s = 0; s < corpus.numSents(d); s++) {
				dls.rhos[d][s] = 1;
				docSegList.add(new Segment(s, s, d));
			}
			assert docSegList.size() == corpus.numSents(d);
			dls.c1[d] = corpus.numSents(d);
			dls.c0[d] = 0;
		}
		return corpus.numSents();
	}

	private int initTrueSeg() {
		int spanLength, start, end, numSents, goldSegs[];
		ArrayList<Segment> docSegList;
		for (int d = 0; d < corpus.numDocs(); d++) {
			docSegList = dls.docSegsMap.get(d);
			assert docSegList.isEmpty();
			numSents = corpus.numSents(d);
			goldSegs = corpus.getGoldSeg(d);
			start = 0;
			while (start < numSents) {
				for (spanLength = 1; start + spanLength < numSents
						&& goldSegs[start + spanLength] == goldSegs[start]; 
						spanLength++) {}
				end = start + spanLength - 1;
				docSegList.add(new Segment(start, end, d));
				dls.rhos[d][end] = 1;
				dls.c1[d]++;
				start += spanLength;
			}
			dls.c0[d] = numSents - dls.c1[d];
		}
		return corpus.numGoldSegs();
	}
}
