import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Logger;


public class CorpusLevelStats {
	private final static Logger logger = Logger.getLogger(CorpusLevelStats.class.getName());
	// bag of word model
	public  int[][] MWK;
	public  int[] MK;
	public  double[][] phis;
	public int startDoc;
	public int numDocs;
	
	/**
	 * 
	 * @param numTypes
	 * @param numTopics
	 */
	public CorpusLevelStats(int numTypes, int numTopics) {
		MWK = new int[numTypes][numTopics];
		for (int w = 0; w < numTypes; w++)
			Arrays.fill(MWK[w], 0);
		MK = new int[Parameter.numTopics];
		Arrays.fill(MK, 0);
		phis = new double[numTopics][numTypes];
	}
	
	/**
	 * Make a deep copy of an existing corpus-level state
	 * 
	 * @param state
	 */
	public CorpusLevelStats(CorpusLevelStats state) {
		int numTypes = state.MWK.length;
		int numTopics = state.MK.length;
		MWK = new int[numTypes][numTopics];
		for (int w = 0; w < numTypes; w++)
			System.arraycopy(state.MWK[w], 0, MWK[w], 0, numTopics);
		MK = new int[Parameter.numTopics];
		System.arraycopy(state.MK, 0, MK, 0, numTopics);
	}
	
	/**
	 * 
	 * @param corpus
	 */
	public void debug(Corpus corpus) {
		int total = 0;
		for(int k = 0; k < Parameter.numTopics; k++)
			total += MK[k];
		if(total != corpus.numTokens()) {
			System.err.println("corpus.numTokens != sum over MK!!! " +corpus.numTokens() +" != "+total);
			System.exit(1);
		}
		total = 0;
		int typeTotal;
		for(int w = 0; w < MWK.length; w++) { 
			typeTotal = 0;
			for(int k = 0; k < Parameter.numTopics; k++) {
				total += MWK[w][k];
				typeTotal += MWK[w][k];
			}
			if(typeTotal != corpus.typeTotal(w)) {
				System.err.println("corpus.typeTotal != sum over MWK[w]!!!");
				System.err.println("corpus.typeTotal(w) = " +corpus.typeTotal(w)+"==> typeTotal ="+ typeTotal);
				System.exit(1);
			}
		}
		if(total != corpus.numTokens()) {
			System.err.println("corpus.numTokens != sum over MWK!!!");
			System.err.println("corpus.numTokens = " + corpus.numTokens()+"==>total = "+total);
			System.exit(1);
		}
	}
		
	/**
	 * Compute the posterior word probabilities in each topic.
	 */
	public void commpute_phis() {
		for (int w = 0; w < MWK.length; w++) {
			for (int k = 0; k < MWK[w].length; k++) {
				phis[k][w] = (Parameter.beta[w] + MWK[w][k]) / (Parameter.betaSum + MK[k]);
			}
		}
	}
	
	/**
	 * Save word-by-topic count matrix
	 * 
	 * @param file
	 */
	public void saveTopicWordCountMatrix(Vocabulary voc, String file) {
		logger.info("Save topic-word count matrix.....");
		try{
			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			for (int w = 0; w < MWK.length; w++) {
				StringBuffer buffer = new StringBuffer();
				buffer.append(voc.getType(w)+",");
				for (int k = 0; k < Parameter.numTopics; k++) {
					buffer.append(MWK[w][k]);
					if (k < Parameter.numTopics - 1)
						buffer.append(",");
				}
				writer.write(buffer.toString());
				writer.newLine();
			}
			writer.flush();
			writer.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	/**
	 * Save topic-word counts in the format used in computing PMI scores
	 * 
	 * @param voc	vocabulary
	 * @param swl	stop-words list
	 * @param file 
	 */
	public void saveCountsForPMIscores(Vocabulary voc, StopWordList swl, String file) {
		logger.info("Save stats for computing PMI Scores......");
		try{
			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			Map<String, Integer> treeMap = new TreeMap<String, Integer>();
			for (int k = 0; k < Parameter.numTopics; k++) {
				for (int w = 0; w < voc.size(); w++) {
					String type = voc.getType(w);
					if(!swl.contains(type))
						treeMap.put(type, new Integer(MWK[w][k]));
				}
				treeMap = this.sortByValueDecending(treeMap);
				int count = 0;
				for (String key : treeMap.keySet()) {
					writer.write(treeMap.get(key).intValue() + " 1 T_"+k+" "+key);
					writer.newLine();
					count++;
					if (count == 20)
						break;
				}
				treeMap.clear();
			}
			writer.flush();
			writer.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
		
	/**
	 * Save top words for each topic.
	 * 
	 * @param voc
	 * @param fileName
	 */
	public void saveTopWord4Topic(Vocabulary voc, StopWordList swl, String fileName) {
		logger.info("Save top "+Parameter.NUMTOPWORDS+" for each topic......");
		commpute_phis();
		try {
			FileWriter fwriter = new FileWriter(new File(fileName));
			Map<String, Double> treeMap = new TreeMap<String, Double>();
			for (int k = 0; k < Parameter.numTopics; k++) {
				for (int w = 0; w < voc.size(); w++) {
					String type = voc.getType(w);
					if(!swl.contains(type))
						treeMap.put(type, new Double(phis[k][w]));
				}
				treeMap = this.sortByValueDecending(treeMap);
				fwriter.write("Topic-" + k + " ");
				int count = 0;
				for (String key : treeMap.keySet()) {
					if (count == Parameter.NUMTOPWORDS - 1) {
						fwriter.write(key + ":" + treeMap.get(key).doubleValue() + "\n");
					} else {
						fwriter.write(key + ":" + treeMap.get(key).doubleValue() + " ");
					}
					count++;
					if (count == Parameter.NUMTOPWORDS)
						break;
				}
				fwriter.write("\n");
				fwriter.flush();
				treeMap.clear();
			}
			fwriter.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
		
	private <K, V extends Comparable<? super V>> Map<K, V> sortByValueDecending(Map<K, V> map) {
		List<Map.Entry<K, V>> list = new LinkedList<Map.Entry<K, V>>(map.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<K, V>>() {
			public int compare(Map.Entry<K, V> o1, Map.Entry<K, V> o2) {
				int compare = (o1.getValue()).compareTo(o2.getValue());
				return -compare;
			}
		});

		Map<K, V> result = new LinkedHashMap<K, V>();
		for (Map.Entry<K, V> entry : list) {
			result.put(entry.getKey(), entry.getValue());
		}
		return result;
	}
}
