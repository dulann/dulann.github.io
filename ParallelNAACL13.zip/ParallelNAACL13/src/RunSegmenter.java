import java.io.File;
import java.io.FilenameFilter;
//import java.util.Arrays;
import java.util.logging.Logger;

import org.apache.commons.cli.*;


public class RunSegmenter {
	
	private final static Logger logger = Logger.getLogger(RunSegmenter.class.getName());
	
	public static void run(Corpus corpus, Vocabulary voc) {
		logger.info("#types = "+voc.size());
		logger.info("#docs = "+corpus.numDocs());
		logger.info("#sents = "+corpus.numSents());
		logger.info("#gold segs = "+corpus.numGoldSegs());
		logger.info("avarege #gold segs per doc = "+corpus.aveNumSegPerDoc());
		logger.info("max #tokens per doc = "+corpus.maxNumTokenPerDoc());
		logger.info("max #sents per doc = " + corpus.maxNumSentPerDoc());
		logger.info("max #segs per doc = " + corpus.maxDocLenSeg());	
		StirNum.initialize(Parameter.MAXN, Parameter.MAXM, Parameter.a);
		NAACL13STSM segmenter = new NAACL13STSM(corpus, voc);
		segmenter.estimate();
		segmenter.saveFinalStats(Parameter.root+File.separator+"final");
	}
	
	private static Options buildOption() {
		Options options = new Options();
		options.addOption(new Option("h", "print the help message"));
		options.addOption(new Option("debug", false, "turn on debugging"));
		//data set
		options.addOption(new Option("data", true, "the folder where data are stored"));
		//the number of thread
		options.addOption(new Option("thread", true, "the number of threads"));
		//number of topics
		options.addOption(new Option("k", true, "the number of topics"));
		options.addOption(new Option("init", true, "segment initialization: for each document, " +
				"\n\t 0: all sentences/paragraphs in one segment" +
				"\n\t 1: one sentence/paragraph per segment" +
				"\t\t 2: use true segmentation"));
		//CRP settings
		options.addOption(new Option("a", true, "the discount parameter"));
		options.addOption(new Option("b", true, "the concentration parameter"));
		options.addOption(new Option("s", false, "sample concentration parameter"));
		options.addOption(new Option("optblag", true, "the lag for sampling concentration parameter"));
		options.addOption(new Option("all", false, "initialization with one customer per table"));
		//Beta setting
		options.addOption(new Option("l", true, "lambda0 parameter for Beta distribution"));
		options.addOption(new Option("L", true, "lambda1 parameter for Beta distribution"));
		//Dirichlet setting
		options.addOption(new Option("alpha", true, "Dirichlet parameter for topic proportion vectors"));
		options.addOption(new Option("beta", true, "Dirichlet parameter for the langauge model"));
		options.addOption(new Option("optalpha", false, "learning alphas"));
		options.addOption(new Option("symalpha", false, "learning symmetric alphas"));
		options.addOption(new Option("optalphalag", true, "the lag for optimizing alphas"));
		//Gibbs settings
		options.addOption(new Option("maxite", true, "maximum Gibbs iterations"));
		options.addOption(new Option("burnin", true, "Gibbs burnin"));
		options.addOption(new Option("lag", true, "sampling lag"));
		
		//output file directory
		options.addOption(new Option("root", true, "the root folder where to save output files"));
		options.addOption(new Option("chain", true, "the Markov chain index"));
		
		return options;
	}

	public static void main(String[] args) throws Exception {
		Options options = buildOption();
		CommandLineParser parser = new GnuParser();
		HelpFormatter formatter = new HelpFormatter();
		CommandLine commands = null;
		try {
			commands = parser.parse(options, args);
		} catch (ParseException exp) {
			System.err.println("Unexpected exception:" + exp.getMessage());
			formatter.printHelp("Ordering Experiment:", options);
			System.exit(1);
		}

		if (commands.hasOption("h")) {
			formatter.printHelp("Structured topic segmentation", options);
			System.exit(0);
		}
		/*
		 * For model debugging
		 */
		Parameter.debug = false;
		if(commands.hasOption("debug")){
			Parameter.debug = true;
		}
		/*
		 * Read vocabulary and corpus
		 */
		Vocabulary voc = null;
		Corpus corpus = null;
		if(commands.hasOption("data")) {
			String dataFolder = commands.getOptionValue("data");
			File folder = new File(dataFolder);
			if(!folder.exists()){
				System.err.println("Data folder given does not exist!!!");
				System.exit(1);
			}
			File[] files = folder.listFiles(new FilenameFilter() {
		        public boolean accept(File dir, String name) {
		            return name.toLowerCase().endsWith(".data")
		            		|| name.toLowerCase().endsWith(".meta")
		            		|| name.toLowerCase().endsWith(".seg")
		            		|| name.toLowerCase().endsWith(".vocab");
		        }
		    });
			assert files.length == 4;
			File[] dataFiles = new File[3];
			for(int i = 0; i < files.length; i++) {
				if(files[i].getName().toLowerCase().endsWith(".vocab"))
					voc = new Vocabulary(files[i]);
				if(files[i].getName().toLowerCase().endsWith(".meta"))
					dataFiles[0] = files[i];
				if(files[i].getName().toLowerCase().endsWith(".data"))
					dataFiles[1] = files[i];
				if(files[i].getName().toLowerCase().endsWith(".seg"))
					dataFiles[2] = files[i];
			}
			corpus = new Corpus(dataFiles, voc.size());
		} else {
			System.err.println("Please specify the data folder: -data <directory>!!!");
			System.exit(1);
		}
		/*
		 * Set the number of threads
		 */
		Parameter.numThreads = 1;
		if(commands.hasOption("thread")) {
			Parameter.numThreads = Integer.parseInt(commands.getOptionValue("thread"));
		} 
		/*
		 * Number of topics
		 */
		if(commands.hasOption("k")) {
			Parameter.numTopics = Integer.parseInt(commands.getOptionValue("k"));
		} else {
			System.err.println("Please specify the number of topcis: -k <value>!!!");
			System.exit(1);
		}
		/*
		 * Initialization code
		 */
		Parameter.segInitCode = 0;
		if(commands.hasOption("init")) {
			Parameter.segInitCode = Integer.parseInt(commands.getOptionValue("init"));
		}
		/*
		 * Parameters for CRP 
		 */
		Parameter.a = 0.2;
		if(commands.hasOption("a")) {
			Parameter.a = Double.parseDouble(commands.getOptionValue("a"));
		}
		Parameter.b = 10.0;
		if(commands.hasOption("b")) {
			Parameter.b = Double.parseDouble(commands.getOptionValue("b"));
		}
		Parameter.sampleConcentration = false;
		if(commands.hasOption("s")) {
			Parameter.sampleConcentration = true;
			Parameter.optConcentrationLag = 1;
			if(commands.hasOption("optblag")) {
				Parameter.optConcentrationLag = Integer.parseInt(commands.getOptionValue("optblag"));
			}
		}
		Parameter.doOneTable = true;
		if(commands.hasOption("all")) {
			Parameter.doOneTable = false;
		}
		/*
		 * Beta shape parameters
		 */
		Parameter.lambda0 = 0.1;
		if(commands.hasOption("l")) {
			Parameter.lambda0 = Double.parseDouble(commands.getOptionValue("l"));
		}
		Parameter.lambda1 = 0.1;
		if(commands.hasOption("L")) {
			Parameter.lambda1 = Double.parseDouble(commands.getOptionValue("L"));
		}
		/*
		 * Dirichlet Parameter
		 */
		double alpha = 0.1;
		if(commands.hasOption("alpha")) {
			alpha = Double.parseDouble(commands.getOptionValue("alpha"));
		}
		Parameter.setAlpha(alpha);
		if(commands.hasOption("optalpha")) {
			Parameter.learnAlpha = true;
			if(commands.hasOption("symalpha")) {
				Parameter.usingSymmetricAlpha = true;
			} else {
				Parameter.usingSymmetricAlpha = false;
			}
			Parameter.optAlphaLag = 5;
			if(commands.hasOption("optalphalag")) {
				Parameter.optAlphaLag = Integer.parseInt(commands.getOptionValue("optalphalag"));
			}
		}
		
		double beta = 0.01;
		if(commands.hasOption("beta")) {
			beta = Double.parseDouble(commands.getOptionValue("beta"));
		}
		Parameter.setBeta(beta, voc.size());
		/*
		 * Gibbs parameters
		 */
		if(commands.hasOption("maxite") && commands.hasOption("burnin") && commands.hasOption("lag") ) {
			Parameter.maxItes = Integer.parseInt(commands.getOptionValue("maxite"));
			Parameter.burnIn = Integer.parseInt(commands.getOptionValue("burnin"));
			Parameter.lag = Integer.parseInt(commands.getOptionValue("lag"));
		} else {
			System.err.println("Please specify configurations for Gibbs sampling!!!");
			System.exit(1);
		}
		
		/*
		 * Output file directory where to save training files
		 */
		if(commands.hasOption("root")){
			Parameter.root = commands.getOptionValue("root");
		} else {
			System.err.println("Please specify the output file directory: -r <directory>!!!");
			System.exit(1);
		}
		int chainIndex = 0;
		if(commands.hasOption("chain")){
			chainIndex = Integer.parseInt(commands.getOptionValue("chain"));
		}
		Parameter.createRoot(chainIndex);
//		if(Parameter.debug){
//			corpus.write(Parameter.root+File.separator+"input_data");
//			voc.write(Parameter.root+File.separator+"input_data");
//		}
		Parameter.save();
		MyLogger.setup(Parameter.root+File.separator+"run.log");
		
//		int[] a = {1, 2, 3, 4};
//		int[] b = {-1,-2,-3,-4};
//		System.arraycopy(a, 0, b, 0, 4);
//		System.out.println(Arrays.toString(b));
//		System.exit(1);
		
		RunSegmenter.run(corpus, voc);
	}
}
