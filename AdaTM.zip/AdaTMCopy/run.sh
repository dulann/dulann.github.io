#!/bin/bash

clear

CLASSPATH="./libs/commons-collections-3.2.1.jar:./libs/commons-cli-1.2.jar:./libs/commons-configuration-1.9.jar"
CLASSPATH="${CLASSPATH}:./libs/commons-lang-2.6.jar:./libs/commons-logging-1.1.1.jar:./libs/commons-math3-3.2.jar"
CLASSPATH="${CLASSPATH}:./libs/mallet-deps.jar:./libs/mallet.jar:./bin"

echo "Running Adaptive Topic Model: compute testing perplexity"
#
# The configuration file
#
CONFIG=./configs/example.config
#
# The output directory
#
ROOT=./results/test
#
#Discount parameter in the PYP
#
A=0.20
#
#Concentration parameter in the PYP
#
B=10.0
#
# The number of topics. If you would like to run a list of numbers, you can
# use for example K="50 100". Then the program will run K = 50, then K = 100
#
KS="10"
#
# The Dirichlet parameter for the bag-of-topics model
#
ALPHA=0.5
#
# The Dirichlet parameter for the bag-of-words model
#
GAMMA=0.01
#
# The number of Gibbs chains you would like to run, which is usually set to 
# 1. Note the code is not multi-threaded. Therefore, it will run each chain sequentially.
#
RUN=1

for k in ${KS}; do
CMD="java -ea -cp ${CLASSPATH} AdaTMParam -config ${CONFIG} -root ${ROOT}"
CMD="${CMD} -grun ${RUN} -a ${A} -b ${B} -alpha ${ALPHA} -gamma ${GAMMA} -k ${k} -verbose 2000"
${CMD};

done

echo "Finish!!!" 
