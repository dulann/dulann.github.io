package optimizer;

import org.apache.commons.math3.random.RandomGenerator;

import states.ModelParams;
import states.StatsTables;
import util.SpecialFuns;

public class SliceBSampler extends SliceSampler {

	private static final double BMIN = 0.001;
	private static final double BMAX = 5000;

	private StatsTables stables;
	private int i;
	private double a;

	public SliceBSampler(StatsTables stables, RandomGenerator rand) {
		super(rand);
		this.stables = stables;
	}
	
	public SliceBSampler(StatsTables stables) {
		super();
		this.stables = stables;
	}

	public double logpdf(double b, Object params) {
		double val = 0;
		for(int j = 0; j < stables.TSIJ[i].length; j++){
			val += SpecialFuns.logPochSym(b, a, stables.TSIJ[i][j])
					- SpecialFuns.logPochSym(b, 1.0, stables.NTIJ[i][j]);
		}
		return val;
	}
	/**
	 * 
	 * @param oldBi
	 * @param a
	 * @param i
	 * @return
	 */
	public double sample(double oldBi, double a, int i) {
		this.i = i;
		this.a = a;
		double newBi = sliceSample1D(null, oldBi, BMIN, BMAX, oldBi / 32.0, 10, 32);
		if (ModelParams.verboseLevel >= 5000) {
			System.out.println("===> slice i = " + i + ", old bi: " + oldBi + ", new bi: " + newBi);
		}
		return newBi;
	}
}

//double lgg_b = Gamma.logGamma(b);
//double ba = b / a;
//double lgg_ba = Gamma.logGamma(ba);
//double log_b = Math.log(b);
//double log_a = Math.log(a);
//for (int j = 0; j < numTPs; j++) {
//	logpd += lgg_b - Gamma.logGamma(b + stables.NTIJ[i][j]);
//	if (a > 0.0) {
//		logpd += Gamma.logGamma(ba + stables.TSIJ[i][j]) - lgg_ba
//					+ stables.TSIJ[i][j] * log_a;
//	} else {
//		logpd += stables.TSIJ[i][j] * log_b;
//	}
//}