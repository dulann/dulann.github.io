package optimizer;

import org.apache.commons.math3.distribution.BetaDistribution;
import org.apache.commons.math3.distribution.GammaDistribution;
import org.apache.commons.math3.distribution.NormalDistribution;
import org.apache.commons.math3.special.Gamma;

import states.ModelParams;
import states.StatsTables;
import util.MTRandom;

public class ArmsBSampler extends ArmSampler
{
	private static final double BMIN = 0.01;
	private static final double BMAX = 5000;
	
	private double SCALE;
	private double SHAPE;
	
	private double a;
	
	private StatsTables stables;
	
	private double lgqSum;
	private int i;
	
	public ArmsBSampler(StatsTables stables, double scale, double shape){
		this.stables = stables;
		SCALE = scale; 
		assert scale > 0;
		SHAPE = shape;
	}
	
	public double logpdf(double b, Object params)
	{
		double val = (lgqSum - 1.0/SCALE) * b + (SHAPE - 1.0)*Math.log(b);
		double ba = b/a;
		double lggba = Gamma.logGamma(ba);
		for(int j = 0; j < stables.TSIJ[i].length; j++)
			val += Gamma.logGamma(ba + stables.TSIJ[i][j]) - lggba;
		return val;
	}
	
	/**
	 * 
	 * @param oldbi the current concentration parameter
	 * @param a the discount parameter
	 * @param i document index
	 * @return sampled concentration parameter
	 */
	public double sample(double oldbi, double a, int i){
		this.a = a;
		this.i = i;
		lgqSum = 0;
		for(int j = 0; j < stables.NTIJ[i].length; j++) {
			BetaDistribution betaDist = new BetaDistribution(MTRandom.generator(), 
															 oldbi, stables.NTIJ[i][j], 
											 BetaDistribution.DEFAULT_INVERSE_ABSOLUTE_ACCURACY);
			double q = 0;
			int ite = 50;
			while(q <= 0 && ite-- > 0)
				q = betaDist.sample();
			
			assert q > 0 : "Error: q <= 0 !!! q = "+q+", bi = "+oldbi+", " +
					"NTIJ = "+stables.NTIJ[i][j];
			
			if(q < 1e-10)
				q = 1e-10;
			lgqSum += Math.log(q);
		}
		double newBi = 0;
		if(a == 0){
			double totalT = SHAPE;
			for(int j = 0; j < stables.TSIJ[i].length; j++)
				totalT += stables.TSIJ[i][j];
			if(totalT > 400){
				NormalDistribution gaussian = new NormalDistribution(MTRandom.generator(),
																	 0, 1.0,
											 NormalDistribution.DEFAULT_INVERSE_ABSOLUTE_ACCURACY);
				do{
					newBi = totalT + gaussian.sample()*Math.sqrt(totalT);
				}while(newBi <= 0);
			}else{
				GammaDistribution gammaDist = new GammaDistribution(MTRandom.generator(), 
																	totalT, 1.0,
										GammaDistribution.DEFAULT_INVERSE_ABSOLUTE_ACCURACY);
				newBi = gammaDist.sample();
				newBi /= 1.0/SCALE - lgqSum;
			}
			if(newBi < BMIN)
				newBi = BMIN;
			if(newBi > BMAX)
				newBi = BMAX;
		}else{
			double initb = oldbi;
			if(Math.abs(initb-BMAX)/BMAX < 0.00001)
				initb = BMAX*0.999 + BMIN*0.001;
			if(Math.abs(initb-BMIN)/BMIN < 0.00001)
				initb = BMIN*0.999 + BMAX*0.001;
			double[] xl = {BMIN};
			double[] xr = {BMAX};
			double[] xprev = {initb};
			try{
				newBi = armsSimple(null, 8, xl, xr, true, xprev);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		if(ModelParams.verboseLevel >= 5000){
			System.out.println("Arms ===> doc-"+i+", old bi: "+oldbi+ ", new bi: "+ newBi);
		}
		return newBi;
	}

}
