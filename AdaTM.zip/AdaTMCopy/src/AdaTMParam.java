import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import model.GibbsFuns;
import model.ModelEstimator;

import org.apache.commons.cli.*;

import data.Corpus;
import data.Vocabulary;
import states.GibbsConfigs;
import states.ModelParams;
import util.MTRandom;
import util.StirNum;


public class AdaTMParam 
{
	private String root;
	private GibbsConfigs configs;
	
	public AdaTMParam(GibbsConfigs configs,
					  String root)
	{
		this.configs = configs;
		this.root = root;
		//make stirling table
		StirNum.initialize(configs.maxN, configs.maxM, configs.a);
		//set random number generator
		MTRandom.setSeed(configs.seed);
		GibbsFuns.initCachedValues();
	}
	
	/**
	 * Read topic-by-word matrix from a given file.
	 * @param numTypes
	 * @param phiFile
	 * @return
	 */
	private double[][] readPhiMatrix(int numTypes, String phiFile){
		double[][] phis = new double[configs.numTopics][numTypes];
		try{
			BufferedReader br = new BufferedReader(new FileReader(phiFile));
			for (int k = 0; k < configs.numTopics; k++) {
				String[] strs = br.readLine().split(", ");
				assert strs.length == numTypes;
				for (int w = 0; w < numTypes; w++)
					phis[k][w] = Double.parseDouble(strs[w]);
			}
			br.close();
		}catch(IOException ioe){
			ioe.printStackTrace();
		}
		return phis;
	}
	
	/**
	 * Run AdaTM model.
	 * @param numRuns
	 * @param phiFile
	 * @throws Exception
	 */
	public void run(int numRuns) throws Exception {
		String[] exts = new String[2];
		exts[0] = configs.trFileExt;
		exts[1] = configs.teFileExt;	
		Vocabulary voc;
		voc = new Vocabulary(configs.corpusFile, null, exts, 
							 configs.minDocFreq, configs.numTopFreq);
		Corpus trCorpus = new Corpus(configs.corpusFile, voc, 
											configs.trFileExt, 
											configs.segIndicator);	
		Corpus teCorpus = null;
		if(configs.teFileExt != null)
			teCorpus = new Corpus(configs.corpusFile, voc, 
									   configs.teFileExt, 
									   configs.segIndicator);	
		
		if(ModelParams.verboseLevel >= 1000){
			configs.printConfiguration();
			System.out.println("=====================================");
			yap("voc size = "+voc.size());
			yap("train size = "+trCorpus.numDocs());
			trCorpus.printCorpusStats();
			if(teCorpus != null)
				teCorpus.printCorpusStats();
			System.out.println("=====================================");
		}
		/*
		 * Read phi matrix. 
		 */
		double[][] phiMatrix = null;
		if(configs.phiFile != null){
			System.out.println("Reading phi matrix......");
			phiMatrix = readPhiMatrix(voc.size(), configs.phiFile);
		}
		/*
		 * Run the model with different parameters
		 */
		root = root+File.separator+String.format("k%03d-a%.2f-b%.2f-alpha%.2f-gamma%.2f", 
												 configs.numTopics, configs.a, configs.b,
												 configs.alpha, configs.gamma);
		File rootFile = new File(root);
		if(!rootFile.exists())
			rootFile.mkdirs();
		ModelEstimator trainingModel;
		for(int i = 0; i < configs.lambdaSs.length; i++) {
			for(int j = 0; j < configs.lambdaTs.length; j++) {
				double finalAvaPerplexity = 0.0;
				String folderName = String.format("Exp-lambdaS%.2f-lambdaT%.2f", 
  													configs.lambdaSs[i], configs.lambdaTs[j]);
				String rootFolder = root+File.separator+folderName;
				(new File(rootFolder)).mkdirs();
				
				FileWriter fw = new FileWriter(rootFolder + "-perplexity.log");
				for(int n = 0; n < numRuns; n++) {
					System.out.println(">>>lambdaS = "+configs.lambdaSs[i]+", lambdaT = "+configs.lambdaTs[j]+", n = "+n);
					String oFileDir = rootFolder + File.separator+"GibbsRun-" + n;
					File file = new File(oFileDir);
					if(!file.exists())
						file.mkdirs();
					ModelParams trParams = new ModelParams(voc.size(), configs.numTopics, 
																 trCorpus.numDocs(), 
																 oFileDir);
					if(phiMatrix == null)
						trParams.init(configs.a, configs.b, 
											configs.alpha, configs.gamma, 
											configs.lambdaSs[i], configs.lambdaTs[j]);
					else
						trParams.init(configs.a, configs.b, 
									configs.alpha, configs.gamma, 
									configs.lambdaSs[i], configs.lambdaTs[j],
									phiMatrix);
					
					trainingModel = new ModelEstimator(trCorpus, trParams, 
												       teCorpus, configs, voc);
					double perp = trainingModel.run();
					finalAvaPerplexity += perp;
					//save perplexity
					fw.write(String.format("%.3f\n", perp));
				}
				finalAvaPerplexity /= numRuns;
				fw.write(String.format("%.3f\n", finalAvaPerplexity));
				fw.flush(); fw.close();
				System.out.println("\nFinal average perpelxity over "+ numRuns
										+" Gibbs runs: "+finalAvaPerplexity);
			}
		}
	}
	
	public static void yap(Object obj){
		System.out.println(obj);
	}
	
	@SuppressWarnings("static-access")
	public static void main(String[] args) throws Exception {
		Options options = new Options();
		Option optHelp = new Option("h", "print the help message");
		options.addOption(optHelp);
		Option optConfig = OptionBuilder.withArgName("file")
									 .hasArg()
									 .withDescription("the model configuration file")
									 .create("config");
		options.addOption(optConfig);
		
		options.addOption(new Option("k", true, "number of topics"));
		options.addOption(new Option("a", true, "the discount parameter"));
		options.addOption(new Option("b", true, "the concentration parameter"));
		options.addOption(new Option("alpha", true, "Alpha (Dirichlet parameter)"));
		options.addOption(new Option("gamma", true, "Gamma (Dirichlet parameters)"));
		options.addOption(new Option("debug", "turn on debugging"));
		options.addOption(new Option("grun", true, "the number of Gibbs runs"));	
		options.addOption(new Option("verbose", true, "the verbose level"));
		options.addOption(new Option("root", true, "output file directory"));
		/*
		 * Parsing command line arguments
		 */
		CommandLineParser parser = new GnuParser();
		HelpFormatter formatter = new HelpFormatter();
		CommandLine line = null;
		try{
			line = parser.parse(options, args);
		}catch( ParseException exp ) {
		    System.err.println( "Unexpected exception:" + exp.getMessage() );
		    formatter.printHelp("AdaTM", options);
			System.exit(1);
		}

		if (line.hasOption("h")) {
			formatter.printHelp("AdaTM", options);
			System.exit(0);
		}
		
		String root = null;
		if(line.hasOption("root")){
			root = line.getOptionValue("root");		
		}else{
			System.err.println("Please specify the root directory to store the model with \'-root\'");
			System.exit(1);
		}
		
		String configFile = null;
		if(line.hasOption(optConfig.getOpt())){
			configFile = line.getOptionValue(optConfig.getOpt());		
		}else{
			System.err.println("Please specify the configuration file with \'-config\'");
			System.exit(1);
		}
		GibbsConfigs configs = new GibbsConfigs(configFile);
		
		if(line.hasOption("k"))
			configs.numTopics = Integer.parseInt(line.getOptionValue("k"));
		else {
			System.err.println("Please specify the number of topic with \'-k\'");
			System.exit(1);
		}
		
		if(line.hasOption("a"))
			configs.a = Double.parseDouble(line.getOptionValue("a"));
		else {
			System.err.println("Please specify the discount parameter with \'-a\'");
			System.exit(1);
		}
		
		if(line.hasOption("b"))
			configs.b = Double.parseDouble(line.getOptionValue("b"));
		else {
			System.err.println("Please specify the concentration parameter with \'-b\'");
			System.exit(1);
		}
		
		if(line.hasOption("alpha"))
			configs.alpha = Double.parseDouble(line.getOptionValue("alpha"));
		else {
			System.err.println("Please specify Dirichlet prior alpha with \'-alpha\'");
			System.exit(1);
		}
		
		if(line.hasOption("gamma"))
			configs.gamma = Double.parseDouble(line.getOptionValue("gamma"));
		else {
			System.err.println("Please specify Dirichlet prior gamma with \'-gamma\'");
			System.exit(1);
		}
	
		int numRuns = 1;
		if(line.hasOption("grun"))
			numRuns = Integer.parseInt(line.getOptionValue("grun"));

		
		if(line.hasOption("debug"))
			ModelParams.debug = true;
		else
			ModelParams.debug = false;
		
		if(line.hasOption("verbose")){
			ModelParams.verboseLevel = Integer.parseInt(line.getOptionValue("verbose"));
		}

		AdaTMParam adaTM = new AdaTMParam(configs, root);
		adaTM.run(numRuns);
	}
}
