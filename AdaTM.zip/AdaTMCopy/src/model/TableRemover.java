package model;

import java.io.Serializable;

import states.StatsTables;
import states.TableIndicator;
import util.MTRandom;

public class TableRemover implements Serializable {

	//Serialization
	private static final long serialVersionUID = 1L;
	
	private StatsTables stables;
	
	private double ps, pt, randVal;
	private int u1, u2;

	public TableRemover(StatsTables stables) {
		this.stables = stables;
	}

	/**
	 * Recurrsively remove tables.
	 * 
	 * @param i document index
	 * @param j text passage index
	 * @param k topic index
	 * @return if tables are removed sucessfully, return true, 
	 * 			otherwise return false.
	 */
	public boolean remove(int i, int j, int k) {
		TableIndicator tableIndicator = sampleTableIndicator(i, j, k);
		if (tableIndicator == null)
			return false;
		if (tableIndicator.getTSInd() != TableIndicator.indicator.O)
			remove(tableIndicator, i, j, k);
		return true;
	}
	/**
	 * 
	 * @param tInd table indicator
	 * @param i document index
	 * @param j text passage index
	 * @param k topic index
	 */
	private void remove(TableIndicator tInd, int i, int j, int k) {
		TableIndicator.indicator tsdInd = tInd.getTSInd();
		int pInd = tInd.getPInd();
		
		if (tsdInd == TableIndicator.indicator.T) {
			stables.TIJK[i][pInd][k]--; 
			stables.TIJ[i][pInd]--; 
			
			stables.NTIJK[i][pInd-1][k]--;
			stables.NTIJ[i][pInd-1]--;
			stables.TSIJK[i][pInd][k]--;
			stables.TSIJ[i][pInd]--;
		} else if (tsdInd == TableIndicator.indicator.S) {
			stables.SIJK[i][pInd][k]--; 
			stables.SIJ[i][pInd]--; 
			stables.SIK[i][k]--; 
			stables.SI[i]--; 
			
			stables.TSIJK[i][pInd][k]--;
			stables.TSIJ[i][pInd]--;
		} 
		for (int jj = pInd + 1; jj <= j; jj++) {
			stables.TIJK[i][jj][k]--;
			stables.TIJ[i][jj]--;
			
			stables.TSIJK[i][jj][k]--;
			stables.TSIJ[i][jj]--;
			
			stables.NTIJK[i][jj-1][k]--;
			stables.NTIJ[i][jj-1]--;
			
		}
	}
	/**
	 * Sample a table indicator to remove tables
	 * 
	 * @param i document index
	 * @param j text passage index
	 * @param k topic index
	 * @return
	 */
	private TableIndicator sampleTableIndicator(int i, int j, int k) {
		u1 = 0; 
		u2 = j;
		for (int jj = j; jj >= 0; jj--) {
			ps = (double) stables.SIJK[i][jj][k] / stables.NTIJK[i][jj][k];
			pt = (double) stables.TIJK[i][jj][k] / stables.NTIJK[i][jj][k] + ps;
			randVal = MTRandom.nextDouble();
			if(ps > randVal || pt > randVal){
				if (stables.TSIJK[i][jj][k] == 1 && stables.NTIJK[i][jj][k] > stables.TSIJK[i][jj][k])
					return null;
				if (ps > randVal) {
					u1 = -1;
					u2 = jj;
					break;
				} else {
					u1 = 1;
					u2 = jj;
				}
			}else{
				break;
			}
		}
		if (u1 == 0) {
			assert u2 == j;
			return new TableIndicator(TableIndicator.indicator.O, u2);
		} else if (u1 == 1) {
			assert u2 > 0;
			return new TableIndicator(TableIndicator.indicator.T, u2);
		} else {
			return new TableIndicator(TableIndicator.indicator.S, u2);
		}
	}
}
