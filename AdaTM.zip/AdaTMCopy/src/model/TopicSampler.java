package model;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

import optimizer.AGOptimizer;
import optimizer.ArmsBSampler;
import optimizer.SliceBSampler;

import data.Corpus;
import data.TextPassage;
import data.Vocabulary;

import gnu.trove.TIntObjectHashMap;
import states.*;
import util.ArrayFuns;
import util.MTRandom;
import util.SpecialFuns;
import util.StirNum;

public class TopicSampler  implements Serializable {
	//Serialization
	private static final long serialVersionUID = 1L;
	private static boolean doPolya = true;

	private Corpus corpus;
	private StatsTables stables;
	private TopicsAss ass;
	private ModelParams modelParams;
	private TopicDists topicDists;
	
	private GibbsFuns gibbsFuns;
	private TableRemover tableRemover;
	private TableAdder tableAdder;

	private TIntObjectHashMap<ArrayList<TableIndicator>> topicProbMap;
	private ArrayList<TableIndicator> indList;
	double[] topicProbs;

	public TopicSampler(Corpus corpus, 
					    ModelParams modelParams) 
	{
		this.corpus = corpus;
		this.modelParams = modelParams;
		stables = new StatsTables(modelParams.numTopics(), 
								  modelParams.numTypes(), 
								  corpus);
		ass = new TopicsAss(corpus);
		gibbsFuns = new GibbsFuns(stables, modelParams);
		tableRemover = new TableRemover(stables);
		tableAdder = new TableAdder(stables);
		topicDists = new TopicDists(corpus, modelParams.numTopics());
		topicProbMap = new TIntObjectHashMap<ArrayList<TableIndicator>>();
		topicProbs = new double[modelParams.numTopics()];
	}
	
	/**
	 * Run one Gibbs sampling iteration through all the documents.
	 * 
	 * @param c	
	 * 					Corpus
	 * @param ass
	 * 					TopicAssignment
	 * @param topicSampler
	 * 					TopicSampler
	 */
	public void runOneGibbsCycle() {
		int k;
		for (int i = 0; i < corpus.numDocs(); i++) {
			for (int j = 0; j < corpus.getDoc(i).numTPs(); j++) {
				TextPassage tp = corpus.getDoc(i).getTP(j);
				for (int n = 0; n < tp.size(); n++) {
					k = ass.getTopic(i, j, n);
					if(ModelParams.debug && ModelParams.verboseLevel >= 30000)
						System.out.println("======> i = "+i+", j = "+j+", w ="+tp.getWord(n)+", oldk = "+k);
					k = sample(i, j, tp.getWord(n), k);
					if(ModelParams.debug && ModelParams.verboseLevel >= 30000)
						System.out.println("sampled k = "+ k);
					if (k > -1)
						ass.setTopic(i, j, n, k);
				}
			}
		}
	}

	/**
	 * Sample a value from a double array;
	 * @param probs
	 * @return
	 */
	private int nextDiscrete(double[] probs) 
    {
        double sum = 0.0;
        double r =  MTRandom.nextDouble() * ArrayFuns.sum(probs);
        for (int i = 0; i < probs.length; i++) 
        {
            sum += probs[i];
            if (sum > r) 
                return i;
        }
        return probs.length - 1;
    }
	
	/**
	 * 
	 * @param i
	 * @param j
	 * @param w
	 * @param oldK
	 * @return
	 */
	private int sample(final int i, final int j, final int w, int oldK) 
	{
		if (!tableRemover.remove(i, j, oldK)) 
			return -1;
		stables.MKW[oldK][w]--;
		stables.MK[oldK]--;
		stables.NTIJK[i][j][oldK]--;
		stables.NTIJ[i][j]--;
		// Start sampling
		topicProbMap.clear();
		Arrays.fill(topicProbs, 0.0);
		double sum, topicProb;
		for (int k = 0; k < modelParams.numTopics(); k++) {
			sum = 0;
			indList = new ArrayList<TableIndicator>();
			gibbsFuns.preComputeProducts(i, j, k, w);
			//Consider not adding a table
			if (stables.NTIJK[i][j][k] > 0) {
				topicProb = gibbsFuns.probNotAddingTable(i, j, k, w);
				sum += topicProb;
				indList.add(new TableIndicator(TableIndicator.indicator.O, j, topicProb));
			}
			//all possible choice of t
			for (int jj = j; jj > 0; jj--) {
				if(stables.NTIJK[i][jj-1][k] > 0){
					topicProb = gibbsFuns.probAddingTable2PT(i, jj, k);
					sum += topicProb;
					indList.add(new TableIndicator(TableIndicator.indicator.T, jj, topicProb));
				}
			}
			//all possible choice of s
			for (int jj = 0; jj <= j; jj++) {
				topicProb = gibbsFuns.probAddingTable2PS(i, jj, k);
				sum += topicProb;
				indList.add(new TableIndicator(TableIndicator.indicator.S, jj, topicProb));
			}
			topicProbMap.put(k, indList);
			topicProbs[k] = sum;
		}
		//Sample a new topic
		int newK = nextDiscrete(topicProbs);
		// Sample to add tables
		tableAdder.add(topicProbMap.get(newK), i, j, newK);
		// add a customer;
		stables.MKW[newK][w]++;
		stables.MK[newK]++;
		stables.NTIJK[i][j][newK]++;
		stables.NTIJ[i][j]++;
		
		if(ModelParams.debug){
			stables.checkInvariance();
		}
		return newK;
	}
	
	public void optimiseConcentration(boolean doSlice) {
		if (doSlice) {
			SliceBSampler sliceB = new SliceBSampler(stables,
													 MTRandom.generator());
			for (int i = 0; i < stables.SI.length; i++)
				modelParams.setb(i, sliceB.sample(modelParams.getb(i), modelParams.geta(), i));
		} else {
			ArmsBSampler armsB = new ArmsBSampler(stables, 1.0, 1.0);
			for (int i = 0; i < stables.SI.length; i++)
				modelParams.setb(i, armsB.sample(modelParams.getb(i), modelParams.geta(), i));
		}
	}
	
	/**
	 * Optimise symetric alphas
	 * @param stables
	 */
	public void optimiseSymmetricAlpha(){
		assert corpus.numDocs() == stables.SIK.length;
		double[][] observations = new double[corpus.numDocs()][modelParams.numTopics()];
		double[] observationLengths = new double[corpus.numDocs()];
		for(int i = 0; i < corpus.numDocs(); i++){
			observationLengths[i] = stables.SI[i];
			for(int k = 0; k < modelParams.numTopics(); k++)
				observations[i][k] = stables.SIK[i][k];
		}
		double newAlpha = 0;
		if(doPolya){
			newAlpha = AGOptimizer.sym_polya_fit(observations, 
												observationLengths, 
												corpus.numDocs(), modelParams.numTopics(), 
												modelParams.getAlpha(0));
		}else{
			newAlpha = AGOptimizer.sym_polya_fit_newton(observations, 
														observationLengths, 
														corpus.numDocs(), modelParams.numTopics(), 
														modelParams.getAlpha(0));
		}
		modelParams.setAlpha(newAlpha);
		if(ModelParams.debug && ModelParams.verboseLevel >= 5000)
			System.out.printf("New alpha: %.6f\n", newAlpha);
	}
	
	/**
	 * Optimise symmetric gammas
	 * @param stables
	 * 					StatsTables
	 * @param mp 
	 * 					ModelParams
	 */
	public void optimiseSymmetricGamma()
	{
		double[][] observations = new double[modelParams.numTopics()][modelParams.numTypes()];
		double[] observationLengths = new double[modelParams.numTopics()];
		for(int k = 0; k < modelParams.numTopics(); k++){
			observationLengths[k] = stables.MK[k];
			for(int w = 0; w < modelParams.numTypes(); w++)
				observations[k][w] = stables.MKW[k][w];
		}
		double newGamma = 0;
		if(doPolya){
			newGamma = AGOptimizer.sym_polya_fit(observations, 
												observationLengths, 
												modelParams.numTopics(), modelParams.numTypes(), 
												modelParams.getGamma(0));
		}else{
			newGamma = AGOptimizer.sym_polya_fit_newton(observations, 
														observationLengths, 
														modelParams.numTopics(), modelParams.numTypes(), 
														modelParams.getGamma(0));
		}
		modelParams.setGamma(newGamma);
		if(ModelParams.debug && ModelParams.verboseLevel >= 5000)
			System.out.printf("new Gamma: %.6f\n", newGamma);
	}
	
	/**
	 * Compute the topics-by-words matrix, which is the
	 * learnt topic distributions.
	 * @param stables
	 */
	public void computePhis() {
		double val;
		for (int k = 0; k < modelParams.numTopics(); k++) {
			for (int w = 0; w < modelParams.numTypes(); w++) {
				val = (modelParams.getGamma(w) + stables.MKW[k][w]) 
								/ (modelParams.getGammaSum() + stables.MK[k]);
				assert val > 0 : "phis["+k+"]["+w+"] = "+ val;
				modelParams.setPhi(k, w, val);
			}
		}
	}
	
	public void initialiseStates() {
		int k;
		TextPassage tp;
		for (int i = 0; i < corpus.numDocs(); i++) {
			for (int j = corpus.getDoc(i).numTPs() - 1; j >= 0; j--) {
				tp = corpus.getDoc(i).getTP(j);
				for (int n = 0; n < tp.size(); n++) {
					k = MTRandom.nextInt(modelParams.numTopics());
					ass.setTopic(i, j, n, k);
					stables.MKW[k][tp.getWord(n)]++;
					stables.MK[k]++;
					stables.NTIJK[i][j][k]++;
					stables.NTIJ[i][j]++;
				}
				for (k = 0; k < modelParams.numTopics(); k++) {
					if (stables.NTIJK[i][j][k] > 0) {
						if (j == 0) {
							stables.SIJK[i][j][k]++;
							stables.SIJ[i][j]++;
							stables.SIK[i][k]++;
							stables.SI[i]++;

							stables.TSIJK[i][j][k]++;
							stables.TSIJ[i][j]++;
						} else {
							if (stables.NTIJK[i][j][k] > 10) {
								stables.SIJK[i][j][k]++;
								stables.SIJ[i][j]++;
								stables.SIK[i][k]++;
								stables.SI[i]++;
								stables.TIJK[i][j][k]++;
								stables.TIJ[i][j]++;

								stables.TSIJK[i][j][k] += 2;
								stables.TSIJ[i][j] += 2;

								stables.NTIJK[i][j-1][k]++;
								stables.NTIJ[i][j-1]++;
							} else {
								if (MTRandom.nextBoolean()) {
									stables.SIJK[i][j][k]++;
									stables.SIJ[i][j]++;
									stables.SIK[i][k]++;
									stables.SI[i]++;
								} else {
									stables.TIJK[i][j][k]++;
									stables.TIJ[i][j]++;

									stables.NTIJK[i][j-1][k]++;
									stables.NTIJ[i][j-1]++;
								}
								stables.TSIJK[i][j][k]++;
								stables.TSIJ[i][j]++;
							}
						}
					}
					if (j == 0)
						assert stables.TIJK[i][j][k] == 0;
				}
			}
		}
		if (ModelParams.debug)
			stables.checkInvariance();
	}
	
	public double perplexity(){
		return perplexity(corpus);
	}
	
	public double perplexity(Corpus c)
	{
		assert c.numDocs() == corpus.numDocs();
		double perp = 0;
		double val;
		if(!modelParams.isPhiGiven())
			this.computePhis();
		topicDists.compute(stables, modelParams);
		for(int i = 0; i < c.numDocs(); i++) {
			for(int j = 0; j < c.getDoc(i).numTPs(); j++) {
				TextPassage tp = c.getDoc(i).getTP(j);
				for(int n = 0; n < tp.size(); n++) {
					val = 0;
					for(int k = 0; k < modelParams.numTopics(); k++)
						val += modelParams.getPhi(k, tp.getWord(n)) 
									* topicDists.getPassageTopicDist(i, j, k);
					perp += Math.log(val);
				}
			}
		}
		perp = Math.exp(-perp/c.numWords());
		if(!SpecialFuns.isnormal(perp) || perp < 0){
			System.err.println("PerplexityTester: perp is illegal.");
			System.exit(1);
		}
		return perp;
	}
	
	public double modelLogLikelihood() {
		double logLikelihood = 0.0;
		
		if(modelParams.isPhiGiven())
			for (int k = 0; k < modelParams.numTopics(); k++) {
				logLikelihood += SpecialFuns.logGamma(modelParams.getGammaSum());
				for (int w = 0; w < modelParams.numTypes(); w++) 
					logLikelihood += (stables.MKW[k][w]+modelParams.getGamma(w)-1)
									 * Math.log(modelParams.getPhi(k, w))
									 - SpecialFuns.logGamma(modelParams.getGamma(w));
			}
		else
			for (int k = 0; k < modelParams.numTopics(); k++) {
				logLikelihood += SpecialFuns.logGamma(modelParams.getGammaSum())
									- SpecialFuns.logGamma(modelParams.getGammaSum() + stables.MK[k]);
				for (int w = 0; w < modelParams.numTypes(); w++)
					logLikelihood += SpecialFuns.logGamma(modelParams.getGamma(w) + stables.MKW[k][w])
										- SpecialFuns.logGamma(modelParams.getGamma(w));
			}
		
		for (int i = 0; i < corpus.numDocs(); i++) {
			logLikelihood += SpecialFuns.logGamma(modelParams.getAlphaSum());
			logLikelihood -= SpecialFuns.logGamma(modelParams.getAlphaSum() + stables.SI[i]);
			for (int k = 0; k < modelParams.numTopics(); k++) {
				logLikelihood += SpecialFuns.logGamma(modelParams.getAlpha(k) + stables.SIK[i][k]);
				logLikelihood -= SpecialFuns.logGamma(modelParams.getAlpha(k));
			}
			for (int j = 0; j < corpus.getDoc(i).numTPs(); j++) {
				logLikelihood += SpecialFuns.logBeta(stables.SIJ[i][j] + modelParams.getLambdaS(), 
													 stables.TIJ[i][j] + modelParams.getLambdaT())
								- SpecialFuns.logBeta(modelParams.getLambdaS(), modelParams.getLambdaT())
								+ SpecialFuns.logPochSym(modelParams.getb(i), modelParams.geta(), stables.TSIJ[i][j])
								- SpecialFuns.logPochSym(modelParams.getb(i), 1.0, stables.NTIJ[i][j]);
				for (int k = 0; k < modelParams.numTopics(); k++)
					logLikelihood += StirNum.logSN(stables.NTIJK[i][j][k], stables.TSIJK[i][j][k])
									 - SpecialFuns.logChoose(stables.NTIJK[i][j][k],stables.TSIJK[i][j][k]);
			}
		}

		logLikelihood /= corpus.numWords();
		logLikelihood = -logLikelihood;
		if (!SpecialFuns.isnormal(logLikelihood) || logLikelihood < 0) {
			throw new RuntimeException("Illegal log model likelihood.");
		}
		return logLikelihood;
	}

	public void writeSamplingInfo(Vocabulary voc){
		String folder = modelParams.oFileDir()
							+ File.separator
							+ "samplingInfo";
		(new File(folder)).mkdirs();
		//Save topic assignment
		ass.writeWordAndTopic(folder, voc);
		//save modelParams
		if(!modelParams.isPhiGiven())
			this.computePhis();
		modelParams.writeParameters(folder);
		String str = folder + File.separator + "top-words-per-topic.log";
		modelParams.saveTopicByWords(str, voc);
		//save topic distributions
		topicDists.compute(stables, modelParams);
		topicDists.writeTopicDistribution(folder);
	}
}
