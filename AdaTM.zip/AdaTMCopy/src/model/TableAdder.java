package model;

import java.io.Serializable;
import java.util.ArrayList;
import states.StatsTables;
import states.TableIndicator;
import util.MTRandom;

public class TableAdder implements Serializable {

	//Serialization
	private static final long serialVersionUID = 1L;

	private StatsTables stables;

	public TableAdder(StatsTables stables) {
		this.stables = stables;
	}

	/**
	 * Recurrsively add tables.
	 * 
	 * @param indList
	 *            a list of table indicators, for which a sample is drawn.
	 * @param i
	 *            document index
	 * @param j
	 *            text passage index
	 * @param k
	 *            topic index
	 */
	public void add(ArrayList<TableIndicator> indList, int i, int j, int k) {
		TableIndicator ind = sampleIndicator(indList);
		TableIndicator.indicator tsdInd = ind.getTSInd();
		int pInd = ind.getPInd();
		
		if (tsdInd == TableIndicator.indicator.T) {
			assert pInd > 0;
			stables.TIJK[i][pInd][k]++;
			stables.TIJ[i][pInd]++;
			
			stables.NTIJK[i][pInd-1][k]++;
			stables.NTIJ[i][pInd-1]++;
			stables.TSIJK[i][pInd][k]++;
			stables.TSIJ[i][pInd]++;
		} else if (tsdInd == TableIndicator.indicator.S) {
			stables.SIJK[i][pInd][k]++;
			stables.SIJ[i][pInd]++;
			stables.SIK[i][k]++;
			stables.SI[i]++;
			
			stables.TSIJK[i][pInd][k]++;
			stables.TSIJ[i][pInd]++;
		} 
		for (int jj = pInd + 1; jj <= j; jj++) {
			stables.TIJK[i][jj][k]++;
			stables.TIJ[i][jj]++;
			
			stables.TSIJK[i][jj][k]++;
			stables.TSIJ[i][jj]++;
			
			stables.NTIJK[i][jj-1][k]++;
			stables.NTIJ[i][jj-1]++;
		}
	}

	/**
	 * Sample an indicator from the given indicator list
	 * 
	 * @param indList
	 *            a list of table indicators, for which a sample is drawn.
	 * @return the sampled table indicator
	 */
	private TableIndicator sampleIndicator(ArrayList<TableIndicator> indList) {
		double sum = 0;
		for (int i = 0; i < indList.size(); i++)
			sum += indList.get(i).getProb();
		double randValue = MTRandom.nextDouble() * sum;
		
		sum = 0;
		for (int i = 0; i < indList.size(); i++) {
			sum += indList.get(i).getProb();
			if (sum > randValue)
				return indList.get(i);
		}
		return indList.get(indList.size() - 1);
	}
}
