package model;

import java.io.Serializable;

import states.ModelParams;
import states.StatsTables;
import util.ArrayFuns;
import util.SpecialFuns;
import util.StirNum;

public class GibbsFuns implements Serializable {
	//Serialization
	private static final long serialVersionUID = 1L;
	
	private StatsTables stables;
	private ModelParams modelParams;
	private double[] allProducts;
	private double product;
	private double prob;
	
	private static double[][] stirCacheOne;
	private static double[][] stirCacheTwo;

	/**
	 * All the Gibbs sampling functions
	 * 
	 * @param stables  recoded statistics tables.
	 * @param modelParams model parameters.
	 * @param doPerpTest boolean variable indicating if doing perplexity.
	 */
	public GibbsFuns(StatsTables stables, 
					 ModelParams modelParams) 
	{
		this.stables = stables;
		this.modelParams = modelParams;
	}
	
	/**
	 * Initialise all the cached values.
	 */
	public static void initCachedValues(){
		stirCacheOne = new double[StirNum.maxM()][StirNum.maxN()];
		ArrayFuns.fill(stirCacheOne, Double.NaN);
		stirCacheTwo = new double[StirNum.maxM()][StirNum.maxN()];
		ArrayFuns.fill(stirCacheTwo, Double.NaN);
		
		stirCacheOne[0][0] =  Math.exp(StirNum.logSN(1, 1) - StirNum.logSN(0, 0));
		for(int t = 1; t < stirCacheOne.length; t++) {
			for(int n = t; n < stirCacheOne[t].length; n++){
				stirCacheOne[t][n] = Math.exp(StirNum.logSN(n+1, t+1) - StirNum.logSN(n, t))
									*(t + 1.0)/(n + 1.0);
				stirCacheTwo[t][n] = Math.exp(StirNum.logSN(n+1, t) - StirNum.logSN(n, t))
									*(n - t + 1.0)/(n + 1.0);
			}
		}
	}
	
	/**
	 * Get a cached value.
	 * 
	 * @param n
	 *            the number of customers
	 * @param t
	 *            the number of tables
	 * @return
	 */
	private static double getCacheOne(final int n, final int t){
		if(t >= stirCacheOne.length || n >= stirCacheOne[0].length){
			double[][] tmp = stirCacheOne;
			int sizeM = tmp.length;
			int sizeN = tmp[0].length;
			if(t > sizeM)
				sizeM += StirNum.EXPSIZE;
			if(n > sizeN)
				sizeN += StirNum.EXPSIZE;
			stirCacheOne = new double[sizeM][sizeN];
			ArrayFuns.fill(stirCacheOne, Double.NaN);
			ArrayFuns.copy(tmp, stirCacheOne);
		}
		if(stirCacheOne[t][n] == Double.NaN)
			stirCacheOne[t][n] = Math.exp(StirNum.logSN(n+1, t+1) - StirNum.logSN(n, t))
							 	*(t + 1.0)/(n + 1.0);
		return stirCacheOne[t][n];
	}
	
	/**
	 * Get a cached value.
	 * @param n
	 * @param t
	 * @return
	 */
	private static double getCacheTwo(final int n, final int t){
		if(t >= stirCacheTwo.length || n >= stirCacheTwo[0].length){
			double[][] tmp = stirCacheTwo;
			int sizeM = tmp.length;
			int sizeN = tmp[0].length;
			if(t > sizeM)
				sizeM += StirNum.EXPSIZE;
			if(n > sizeN)
				sizeN += StirNum.EXPSIZE;
			stirCacheTwo = new double[sizeM][sizeN];
			ArrayFuns.fill(stirCacheTwo, Double.NaN);
			ArrayFuns.copy(tmp, stirCacheTwo);
		}
		if(stirCacheTwo[t][n] == Double.NaN)
			stirCacheTwo[t][n] = Math.exp(StirNum.logSN(n+1, t) - StirNum.logSN(n, t))
								*(n - t + 1.0)/(n + 1.0);
		return stirCacheTwo[t][n];
	}

	
	/**
	 * Precompute the products shared by all the formulas.
	 * @param i document index
	 * @param j text passage index
	 * @param k topic index
	 * @param w type index
	 */
	public void preComputeProducts(final int i, final int j, final int k, final int w) 
	{
		allProducts = new double[(j + 1)];
		if(modelParams.isPhiGiven())
			product = modelParams.getPhi(k, w);
		else
			product = (modelParams.getGamma(w) + stables.MKW[k][w])
						/ (modelParams.getGammaSum() + stables.MK[k]);

		int n, t;
		for (int jj = j; jj >= 0; jj--) {
			n = stables.NTIJK[i][jj][k];
			t = stables.TSIJK[i][jj][k];
			product *= ((stables.TIJ[i][jj] + modelParams.getLambdaT()) 
							* (modelParams.getb(i) + modelParams.geta() * stables.TSIJ[i][jj])
//							* (t + 1.0)
//							* Math.exp(StirNum.logSN(n + 1, t + 1) - StirNum.logSN(n, t))
							*getCacheOne(n, t)
						) / ((stables.TSIJ[i][jj] + modelParams.getLambdaSum()) 
								* (modelParams.getb(i) + stables.NTIJ[i][jj])
//								* (n + 1.0)
							);
			if (!SpecialFuns.isnormal(product) || product < 0){
				System.err.println("jj="+jj+", T = "+stables.TSIJ[i][jj] +
								", N = "+stables.NTIJ[i][jj] +
								", t = "+t + ", n = "+n +
								", product = "+ product);
				System.exit(1);
			}
			allProducts[jj] = product;
		}
	}

	/**
	 * The probability of not adding a table
	 * 
	 * @param i document index
	 * @param j text passage index
	 * @param k topic index
	 * @param w type index
	 * @return
	 */
	public double probNotAddingTable(int i, int j, int k, int w) 
	{
		if(modelParams.isPhiGiven()){
			prob = modelParams.getPhi(k, w);
		}else{
			prob = (modelParams.getGamma(w) + stables.MKW[k][w])	
					/ (modelParams.getGammaSum() + stables.MK[k]);
		}
//		int n = stables.NTIJK[i][j][k];
//		int t = stables.TSIJK[i][j][k];
		prob *= (1.0/(modelParams.getb(i) + stables.NTIJ[i][j]))
				* getCacheTwo(stables.NTIJK[i][j][k], stables.TSIJK[i][j][k]);
				//* (1.0 - t / (n + 1.0))
				//* Math.exp(StirNum.logSN(n + 1, t) -StirNum.logSN(n, t));
		
		if (!SpecialFuns.isnormal(prob) || prob < 0)
			throw new RuntimeException("probNotAddingTable is illegal. prob = "+prob);
		return prob;
	}	
	/**
	 * The probablity of adding a table to TIJK in the passage
	 * level restaurant
	 * 
	 * @param i document index
	 * @param j text passage index
	 * @param k topic index
	 * @return
	 */
	public double probAddingTable2PT(int i, int j, int k) {
		int jj = j-1;
//		int n = stables.NTIJK[i][jj][k];
//		int t = stables.TSIJK[i][jj][k];
		prob = (allProducts[j] / (modelParams.getb(i) + stables.NTIJ[i][jj]))
				//*(1.0 - t / (n + 1.0))
			   // * Math.exp(StirNum.logSN(n + 1, t) - StirNum.logSN(n, t))
				*getCacheTwo(stables.NTIJK[i][jj][k], stables.TSIJK[i][jj][k]) ;
		if (!SpecialFuns.isnormal(prob) || prob < 0){
			throw new RuntimeException("probAddingTable2PT is illegal. prob = "+prob);
		}
		return prob;
	}

	/**
	 * 
	 * @param i document index
	 * @param j text passage index
	 * @param k topic index
	 * @return
	 */
	public double probAddingTable2PS(int i, int j, int k){
		double prob = (allProducts[j] 
						* (modelParams.getAlpha(k) + stables.SIK[i][k]) 
						* (stables.SIJ[i][j] + modelParams.getLambdaS())
						) / ((modelParams.getAlphaSum() + stables.SI[i])
								* (stables.TIJ[i][j] + modelParams.getLambdaT())
							);
		if (!SpecialFuns.isnormal(prob) || prob < 0)
			throw new RuntimeException("probAddingTable2PSonly is illegal. prob = "+prob);
		return prob;
	}
}
