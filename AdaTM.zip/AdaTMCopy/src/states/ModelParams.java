package states;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap;

import data.Vocabulary;
import util.ArrayFuns;
import util.MapUtil;

/**
 * 
 * @author Lan Du
 * @version 2013-1-11 11:25
 * @serial 0
 */
public class ModelParams implements Serializable{
	// Serialization
	private static final long serialVersionUID = 1L;
	private static final int CURRENT_SERIAL_VERSION = 0;
	private static final int NUMTOPWORDS = 100;
	// debugging
	public static int verboseLevel = 500;
	public static boolean debug = false;
	// folder to save trained model
	private String oFileDir;
	/*
	 *  Dirichlet parameters
	 */
	private double[] gammas, alphas;
	private double gammaSum, alphaSum;
	//The learnt topic distributions
	private double[][] phis;
	private boolean isPhiGiven = false;
	// Parameters for generating rho
	private double lambdaS, lambdaT, lambdaSum;
	//Discount parameter
	private double a; 
	//Concentration parameters
	private double[] bs; 
	// the number of topics
	private int numTopics;
	// the vocabulary size
	private int numTypes;	
	// number of documents
	private int numDocs;
	
	/**
	 * @param numTypes
	 * @param numTopics
	 * @param numDocs
	 * @param oFileDir
	 */
	public ModelParams(int numTypes, 
					   int numTopics, 
					   int numDocs, 
					   String oFileDir) 
	{
		this.numTypes = numTypes;
		this.numTopics = numTopics;
		this.numDocs = numDocs;
		this.oFileDir = oFileDir;
		alphas = new double[numTopics];
		gammas = new double[numTypes];
		bs = new double[numDocs];
		phis = new double[numTopics][numTypes];
	}
	
	/**
	 * Initialize the model parameters
	 * @param a the initial discount parameter
	 * @param b the initial concentration parameter
	 * @param gamma the initial Dirichlet parameter
	 * @param lambdaS the Beta parameter
	 * @param lambdaT the Beat parameter
	 */
	public void init(double a, 
					double b, 
					double alpha,
					double gamma, 
					double lambdaS, 
					double lambdaT) 
	{
		this.a = a;
		Arrays.fill(bs, b);
		Arrays.fill(alphas, alpha);
		alphaSum = alpha*numTopics;
		Arrays.fill(gammas, gamma);
		gammaSum = gamma * numTypes;
		this.lambdaS = lambdaS;
		this.lambdaT = lambdaT;
		lambdaSum = lambdaS + lambdaT;
	}
	/**
	 * @param a
	 * @param b
	 * @param lambdaS
	 * @param lambdaT
	 * @param alphas
	 * @param gammas
	 * @param phis
	 */
	public void init(double a,
					double b,
					double lambdaS,
					double lambdaT,
					double[] alphas,
					double[] gammas,
					double[][] phis)
	{
		this.a = a;
		Arrays.fill(bs, b);
		this.lambdaS = lambdaS;
		this.lambdaT = lambdaT;
		lambdaSum = lambdaS + lambdaT;
		
		if(alphas.length != this.alphas.length)
			throw new RuntimeException("Illegal alpha parameters!!!");
		System.arraycopy(alphas, 0, this.alphas, 0, alphas.length);
		alphaSum = ArrayFuns.sum(this.alphas);
		
		if(gammas.length != this.gammas.length)
			throw new RuntimeException("Illegal gamma parameters!!!");
		System.arraycopy(gammas, 0, this.gammas, 0, gammas.length);
		gammaSum = ArrayFuns.sum(this.gammas);
		
		isPhiGiven = true;
		System.arraycopy(phis, 0, this.phis, 0, phis.length);
	}
	/**
	 * 
	 * @param a
	 * @param b
	 * @param alpha
	 * @param gamma
	 * @param lambdaS
	 * @param lambdaT
	 * @param phis
	 */
	public void init(double a, 
					double b, 
					double alpha,
					double gamma, 
					double lambdaS, 
					double lambdaT,
					double[][] phis)
	{
		this.a = a;
		Arrays.fill(bs, b);
		
		Arrays.fill(alphas, alpha);
		alphaSum = alpha*numTopics;
		
		Arrays.fill(gammas, gamma);
		gammaSum = gamma * numTypes;
		
		this.lambdaS = lambdaS;
		this.lambdaT = lambdaT;
		lambdaSum = lambdaS + lambdaT;
		
		isPhiGiven = true;
		System.arraycopy(phis, 0, this.phis, 0, phis.length);
	}
	
	public int numTopics(){
		return numTopics;
	}
	
	public int numTypes(){
		return numTypes;
	}
	
	public String oFileDir(){
		return oFileDir;
	}
	
	public double geta(){
		return a;
	}
	/*
	 * Concentration parameters
	 */
	public double getb(int i){
		return bs[i];
	}
	public void setb(int i, double val){
		bs[i] = val;
	}
	public void setb(double val){
		Arrays.fill(bs, val);
	}
	public double meanb() {
		return ArrayFuns.mean(bs);
	}
	/*
	 * Dirichlet parameter alpha
	 */
	public double getAlpha(int k){
		return alphas[k];
	}
	public double[] getAlpha(){
		return alphas;
	}
	public void setAlpha(double val, int k){
		alphaSum += val - alphas[k];
		alphas[k] = val;
	}
	public void setAlpha(double val){
		Arrays.fill(alphas, val);
		alphaSum = val*numTopics;
	}
	public double getAlphaSum(){
		return alphaSum;
	}
	/*
	 * Dirichlet parameter gamma
	 */
	public double getGamma(int w){
		return gammas[w];
	}
	public double[] getGamma(){
		return gammas;
	}
	public void setGamma(double val, int w){
		gammaSum += val - gammas[w];
		gammas[w] = val;
	}
	public void setGamma(double val){
		Arrays.fill(gammas, val);
		gammaSum = val*numTypes;
	}
	public double getGammaSum(){
		return gammaSum;
	}
	/*
	 * topic-by-word matrix
	 */
	public double getPhi(int k, int w){
		return phis[k][w];
	}
	public double[][] getPhi(){
		return phis;
	}
	public void setPhi(int k, int w, double val){
		phis[k][w] = val;
	}
	public boolean isPhiGiven(){
		return isPhiGiven;
	}
	/*
	 * Beta parameters
	 */
	public double getLambdaS(){
		return lambdaS;
	}
	
	public double getLambdaT(){
		return lambdaT;
	}
	
	public double getLambdaSum(){
		return lambdaSum;
	}
	
	/**
	 * Print the top words for each topic
	 * @param fileName
	 * @param phis
	 * @param voc
	 */
	public void saveTopicByWords(String fileName, Vocabulary voc){
		try {
			FileWriter fwriter = new FileWriter(new File(fileName));
			Map<String, Double> treeMap = new TreeMap<String, Double>();
			for (int k = 0; k < phis.length; k++) {
				for (int w = 0; w < phis[0].length; w++) 
					treeMap.put(voc.getType(w), new Double(phis[k][w]));
				treeMap = MapUtil.sortByValueDecending(treeMap);
				fwriter.write("Topic-" + k + ": ");
				int count = 0;
				for (String key : treeMap.keySet()) {
					if (count == NUMTOPWORDS - 1) 
						fwriter.write(String.format("%s(%.3f)\n", key, treeMap.get(key)));
					 else 
						fwriter.write(String.format("%s(%.3f) ", key, treeMap.get(key)));
					count++;
					if (count == NUMTOPWORDS)
						break;
				}
				fwriter.write("\n");
				fwriter.flush();
				treeMap.clear();
			}
			fwriter.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	/**
	 * Save parameters
	 */
	public void writeParameters(String folder){
		String str;
		str = folder+File.separator+"final-phiMatrix.dat";
		ArrayFuns.write(phis, str);
		str = folder+File.separator+"final-concentrations.dat";
		ArrayFuns.write(bs, str);
		str = folder + File.separator+"final-alphas.dat";
		ArrayFuns.write(alphas, str);
		str = folder + File.separator+"final-gammas.dat";
		ArrayFuns.write(gammas, str);
		//save in object format
		str = folder+File.separator+"final-modelParams.obj";
		writeObject(str);
	}
	
	/**
	 * Save parameters in Obj format
	 * @param fileName
	 */
	public void writeObject(String fileName){
		try{
			FileOutputStream fos = new FileOutputStream(fileName);
			ObjectOutputStream out = new ObjectOutputStream(fos);
			//write serial version
			out.writeInt(CURRENT_SERIAL_VERSION);
			//write parameters
			out.writeInt(numTopics);
			out.writeInt(numTypes);
			out.writeInt(numDocs);
			out.writeDouble(lambdaS);
			out.writeDouble(lambdaT);
			out.writeDouble(lambdaSum);
			out.writeDouble(alphaSum);
			out.writeDouble(gammaSum);
			out.writeDouble(a);
			//write concetration parameters
			for(int i = 0; i < bs.length; i++)
				out.writeDouble(bs[i]);
			//write alphas
			for(int i = 0; i < alphas.length; i++)
				out.writeDouble(alphas[i]);
			//write gammas
			for(int i = 0; i < gammas.length; i++)
				out.writeDouble(gammas[i]);
			//write phis
			for(int i = 0; i < phis.length; i++)
				for(int j = 0; j < phis[i].length; j++)
					out.writeDouble(phis[i][j]);
			
			out.flush(); out.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("unused")
	public void readObject(String fileName){
		try {
			FileInputStream fis = new FileInputStream(fileName);
			ObjectInputStream in = new ObjectInputStream(fis);
			//read serial version
			int version = in.readInt();
			//read parameters
			numTopics = in.readInt();
			numTypes = in.readInt(); 
			numDocs = in.readInt();
			lambdaS = in.readDouble();
			lambdaT = in.readDouble();
			lambdaSum = in.readDouble();
			alphaSum = in.readDouble();
			gammaSum = in.readDouble();
			a = in.readDouble();
			//write concetration parameters
			bs = new double[numDocs];
			for(int i = 0; i < bs.length; i++)
				bs[i] = in.readDouble();
			//read alphas
			alphas = new double[numTopics];
			for(int i = 0; i < alphas.length; i++)
				alphas[i] = in.readDouble();
			//read gammas
			gammas = new double[numTypes];
			for(int i = 0; i < gammas.length; i++)
				gammas[i] = in.readDouble();
			//read phis
			phis = new double[numTopics][numTypes];
			for(int i = 0; i < phis.length; i++)
				for(int j = 0; j < phis[i].length; j++)
					phis[i][j] = in.readDouble();
			in.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
