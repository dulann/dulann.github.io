package states;

import java.io.Serializable;

/**
 * 
 * @author Lan Du
 * @version 2013-01-08-16:58
 */
public class TableIndicator implements Serializable{
	
	private static final long serialVersionUID = 1L;
	/*
	 * table contribution indicator: 
	 * 		T: contribute a table to TIJK; 
	 * 		S: contribute a table to SIJK; 
	 * 		O: not contribute any table.
	 */
	public static enum indicator {
		T, S, O
	};

	private final indicator tsInd;
	/*
	 * Passage index
	 */
	private final int pInd;
	/*
	 * the indicator probability
	 */
	private final double prob;

	/**
	 * 
	 * @param tsdInd
	 *            table contribution indicator
	 * @param pInd
	 *            text passage indicator (i.e. text passage index)
	 */
	public TableIndicator(indicator tsInd, int pInd) {
		this.tsInd = tsInd;
		this.pInd = pInd;
		prob = Double.POSITIVE_INFINITY;
	}

	/**
	 * 
	 * @param tsdInd
	 *            table contribution indicator
	 * @param pInd
	 *            text passage indicator (i.e., text passage index)
	 * @param prob
	 *            table indicator probablity
	 */
	public TableIndicator(indicator tsdInd, int pInd, double prob) {
		this.tsInd = tsdInd;
		this.pInd = pInd;
		this.prob = prob;
	}

	/**
	 * 
	 * @return table indicator probability
	 */
	public double getProb() {
		return prob;
	}
	
	/**
	 * 
	 * @return table contribution indicator
	 */
	public indicator getTSInd(){
		return tsInd;
	}
	/**
	 * 
	 * @return text passage indicator
	 */
	public int getPInd(){
		return pInd;
	}
}
