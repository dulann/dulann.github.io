package states;

import java.io.*;

import data.*;

/**
 * 
 * @author Lan Du
 * @version 2013-1-11 11:25
 * @serial 0
 */
public class StatsTables implements Serializable{
	//Serialization
	private static final long serialVersionUID = 1L;
	private static final int CURRENT_SERIAL_VERSION = 0;
	
	private final Corpus corpus;
	private final int numTopics;
	private final int numTypes;
	// model level stats
	public int[][] MKW;
	public int[] MK;
	// t tables
	public int[][][] TIJK;
	public int[][] TIJ;
	//s tables
	public int[][][] SIJK;
	public int[][] SIJ;
	public int[][] SIK;
	public int[] SI;
	//total tables for topic k of i, j
	public int[][][] TSIJK;
	//total tables for i, j
	public int[][] TSIJ;
	//total customers for topic k in i, j
	public int[][][] NTIJK;
	//total customers in i, j
	public int[][] NTIJ;
	
	/**
	 * 
	 * @param numTopics 
	 * 						the number of topics
	 * @param numTypes 
	 * 						number of word types
	 * @param corpus 
	 * 						corpus
	 */
	public StatsTables(int numTopics, 
					   int numTypes, 
					   Corpus corpus) 
	{
		this.corpus = corpus;
		this.numTopics = numTopics;
		this.numTypes = numTypes;

		MKW = new int[numTopics][numTypes];
		MK = new int[numTopics];

		SI = new int[corpus.numDocs()];
		SIJ = new int[corpus.numDocs()][];
		SIK = new int[corpus.numDocs()][numTopics];
		SIJK = new int[corpus.numDocs()][][];
		
		TIJ = new int[corpus.numDocs()][];
		TIJK = new int[corpus.numDocs()][][];
		
		TSIJK = new int[corpus.numDocs()][][];
		TSIJ = new int[corpus.numDocs()][];
		
		NTIJK = new int[corpus.numDocs()][][];
		NTIJ = new int[corpus.numDocs()][];
		
		for (int i = 0; i < corpus.numDocs(); i++) {
			Document doc = corpus.getDoc(i);
			
			SIJ[i] = new int[doc.numTPs()];
			SIJK[i] = new int[doc.numTPs()][numTopics];
			
			TIJ[i] = new int[doc.numTPs()];
			TIJK[i] = new int[doc.numTPs()][numTopics];
			
			TSIJK[i] = new int[doc.numTPs()][numTopics];
			TSIJ[i] = new int[doc.numTPs()];
			
			NTIJK[i] = new int[doc.numTPs()][numTopics];
			NTIJ[i] = new int[doc.numTPs()];
		}
	}

	/**
	 * Check the constraints on the recorded statistics.
	 * 
	 * @param trueNumTopics 
	 * 					the true number of topics
	 */
	public void checkInvariance() 
	{
		int sumMK = 0;
		int sumMKW;
		for (int k = 0; k < numTopics; k++) {
			sumMKW = 0;
			for (int w = 0; w < numTypes; w++) {
				assert MKW[k][w] >= 0 : "MKW["+k+"]["+w+"] = "+ MKW[k][w];
				sumMKW += MKW[k][w];
			}
			assert MK[k] >= 0 : "MK["+k+"] = "+ MK[k];
			assert MK[k] == sumMKW : 
								"MK["+k+"] = "+ MK[k] +", Sum-MKW["+k+"] = " +sumMKW;
			sumMK += MK[k];
		}
		assert sumMK == corpus.numWords() :
						"Sum-of-MK = "+sumMK+", corpus-total = "+corpus.numWords();

		int sumNTIJ = 0;
		int sumTIJ = 0;
		for (int i = 0; i < corpus.numDocs(); i++) {
			Document doc = corpus.getDoc(i); 
			assert doc.getDocIndex() == i;
			assert SI[i] > 0 : "SI["+i+"] = "+ SI[i];
			double sumSIK = 0;
			for (int k = 0; k < numTopics; k++) {
				assert SIK[i][k] >= 0;
				sumSIK += SIK[i][k];
				double sumSIJK = 0;
				for (int j = 0; j < doc.numTPs(); j++) {
					sumSIJK += SIJK[i][j][k];
				}
				assert sumSIJK == SIK[i][k];
			}
			assert sumSIK == SI[i];

			int sumSIJ = 0;
			for (int j = 0; j < doc.numTPs(); j++) {
				assert doc.getTP(j).getTPIndex() == j;
				int sumTIJK = 0; 
				int sumSIJK = 0; 
				int sumTSIJK = 0;
				int sumNTIJK = 0;
				for (int k = 0; k < numTopics; k++) {
					assert NTIJK[i][j][k] >= 0;
					assert TSIJK[i][j][k] >= 0;
					assert NTIJK[i][j][k] >= TSIJK[i][j][k];
					if (NTIJK[i][j][k] == 0)
						assert TSIJK[i][j][k] == 0;
					if (TSIJK[i][j][k] == 0)
						assert NTIJK[i][j][k] == 0;
					sumNTIJK += NTIJK[i][j][k];
					sumTSIJK += TSIJK[i][j][k];
					assert TSIJK[i][j][k] == TIJK[i][j][k] + SIJK[i][j][k];
					
					assert TIJK[i][j][k] >= 0;
					if(j == 0)
						assert TIJK[i][j][k] == 0;
					assert SIJK[i][j][k] >= 0;
					sumTIJK += TIJK[i][j][k]; 
					sumSIJK += SIJK[i][j][k];
				}
				assert TIJ[i][j] >= 0;
				assert TIJ[i][j] == sumTIJK;
				assert SIJ[i][j] >= 0;
				assert SIJ[i][j] == sumSIJK;
				
				assert NTIJ[i][j] >= 0;
				assert sumNTIJK == NTIJ[i][j];
				assert TSIJ[i][j] >= 0;
				assert sumTSIJK == TSIJ[i][j];
				assert TSIJ[i][j] == TIJ[i][j] + SIJ[i][j];
				
				if (j == 0) {
					assert TIJ[i][j] == 0;
					assert SIJ[i][j] > 0;
					assert TSIJ[i][j] > 0;
				}
				sumSIJ += SIJ[i][j];
				sumTIJ += TIJ[i][j];
				sumNTIJ += NTIJ[i][j];
			}
			assert SI[i] == sumSIJ;
		}
		assert (sumNTIJ - sumTIJ) == corpus.numWords();
	}
	
	/**
	 * Save statistics.
	 * 
	 * @param fileName
	 */
	public void writeObject(String fileName) {
		try {
			FileOutputStream fos = new FileOutputStream(fileName);
			ObjectOutputStream out = new ObjectOutputStream(fos);
			//write serial version
			out.writeInt(CURRENT_SERIAL_VERSION);
			//write MK and MKW
			for(int k = 0; k < numTopics; k++){
				out.writeInt(MK[k]);
				for(int w = 0; w < numTypes; w++)
					out.writeInt(MKW[k][w]);
			}
			//write SI, NTIJ, TSIJ, TIJ, SIJ, NIJK, TIJK,
			for(int i = 0; i < corpus.numDocs(); i++){
				out.writeInt(SI[i]);
				for(int j = 0; j < corpus.getDoc(i).numTPs(); j++){
					out.writeInt(TIJ[i][j]);
					out.writeInt(SIJ[i][j]);
					out.writeInt(NTIJ[i][j]);
					out.writeInt(TSIJ[i][j]);
					for(int k = 0; k < numTopics; k++){
						out.writeInt(NTIJK[i][j][k]);
						out.writeInt(TSIJK[i][j][k]);
						out.writeInt(TIJK[i][j][k]);
						out.writeInt(SIJK[i][j][k]);
					}
				}
			}
			//wirte SIK
			for(int i = 0; i < corpus.numDocs(); i++)
				for(int k = 0; k < numTopics; k++)
					out.writeInt(SIK[i][k]);
			out.flush();out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Read StatsTables object from a file.
	 * @param fileName
	 * @return
	 */
	@SuppressWarnings("unused")
	public void readObject(String fileName) {
		try {
			FileInputStream fis = new FileInputStream(fileName);
			ObjectInputStream in = new ObjectInputStream(fis);
			//read serial version
			int version = in.readInt();
			//write MK and MKW
			for(int k = 0; k < numTopics; k++){
				MK[k] = in.readInt();
				for(int w = 0; w < numTypes; w++)
					MKW[k][w] = in.readInt();
			}
			//write SI, NIJ, TIJ, SIJ, NIJK, TIJK, SIJK
			for(int i = 0; i < corpus.numDocs(); i++){
				SI[i] = in.readInt();
				for(int j = 0; j < corpus.getDoc(i).numTPs(); j++){
					TIJ[i][j] = in.readInt();
					SIJ[i][j] = in.readInt();
					NTIJ[i][j] = in.readInt();
					TSIJ[i][j] = in.readInt();
					for(int k = 0; k < numTopics; k++){
						NTIJK[i][j][k] = in.readInt();
						TSIJK[i][j][k] = in.readInt();
						TIJK[i][j][k] = in.readInt();
						SIJK[i][j][k] = in.readInt();
					}
				}
			}
			//wirte SIK
			for(int i = 0; i < corpus.numDocs(); i++)
				for(int k = 0; k < numTopics; k++)
					SIK[i][k] = in.readInt();
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Save topic-by-word count matrix in format required by topic evaluation.
	 */
	public void saveTopicByWordCountMatrix(String file, Vocabulary voc){
		try{
			FileWriter fw = new FileWriter(file);
			for(int k = 0; k < MKW.length; k++) {
				for(int w = 0; w < MKW[k].length; w++)
					fw.write(String.format("%d 1 t_%d %s\n", MKW[k][w], (k+1), voc.getType(w)));
				fw.flush();
			}
			fw.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
}
