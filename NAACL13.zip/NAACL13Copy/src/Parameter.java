import java.io.*;
import java.util.Arrays;

/**
 * 
 * @author Du Lan
 *
 */
public final class Parameter {
	//
	public static final int MAXN = 3000;
	public static final int MAXM = 2000;
	public static final int NUMTOPWORDS = 100;
	//
	public static boolean debug;
	public static int verbose;
	//
	public static String root;
	public static int numTopics;
	//How to initialize segment
	public static int segInitCode;
	//Gamma parameter for learning b
	public static double scale = 1.0;
	public static double shape = 1.0;
	//Two shape parameters for Beta
	public static double lambda1;
	public static double lambda0;
	//Parameters for PDP
	public static double a;
	public static double b;
	public static boolean doOneTable;
	public static boolean learnB;
	//Dirichlet parameter for bag of topics
	public static double[] alpha;
	public static double alphaSum;
	//Dirichlet parameter for bag of word
	public static double[] beta;
	public static double betaSum;
	//Gibbs parameters
	public static int maxItes;
	public static int burnIn;
	public static int lag;
	//Simulated annealing parameters
	public static boolean doAnnealing;
	public static double startTemp;
	public static double endTemp;
	public static int annealItes;
	public static double coolingTemp;
	public static int coolingItes;
	
	public static void setAlpha(double val) {
		alpha = new double[numTopics];
		Arrays.fill(alpha, val);
		alphaSum = numTopics*val;
	}
	
	public static void setBeta(double val, int vocSize) {
		beta = new double[vocSize];
		Arrays.fill(beta, val);
		betaSum = vocSize*val;
	}
	
	public static void createRoot(int chainIdx) {
		String str = String.format("k(%d)-a(%.2f)-b(%.2f)-alpha(%.2f)" +
				"-beta(%.2f)-lambda0(%.2f)-lambda1(%.2f)-r-%d", 
				numTopics, a, b, alpha[0], beta[0], lambda0, lambda1, chainIdx);
		root = root + File.separator + str;
		File file = new File(root);
		if(!file.exists())
			file.mkdirs();		
	}
	
	public static void save() {
		String str = root + File.separator+ "parameters.log";
		try{
			BufferedWriter writer = new BufferedWriter(new FileWriter(str));
			writer.write("root = "+root); writer.newLine();
			writer.write("numTopics = "+numTopics); writer.newLine();
			writer.write("segInitCode = "+segInitCode); writer.newLine();
			writer.write("scale = " + scale); writer.newLine();
			writer.write("shape = " + shape); writer.newLine();
			writer.write("lambda0 = " + lambda0); writer.newLine();
			writer.write("lambda1 = " + lambda1); writer.newLine();
			writer.write("alpha = " + alpha[0]); writer.newLine();
			writer.write("alphaSum = " + alphaSum); writer.newLine();
			writer.write("beta = " + beta[0]); writer.newLine();
			writer.write("betaSum = " + betaSum); writer.newLine();
			writer.write("a = " + a); writer.newLine();
			writer.write("b = "+b); writer.newLine();
			writer.write("doOneTable = "+doOneTable); writer.newLine();
			writer.write("learnB = "+learnB); writer.newLine();
			writer.write("maxItes = "+maxItes); writer.newLine();
			writer.write("burnIn = "+burnIn); writer.newLine();
			writer.write("lag = "+lag); writer.newLine();
			writer.write("doAnnealing = "+doAnnealing); writer.newLine();
			if(doAnnealing) {
				writer.write("startTemp = "+startTemp); writer.newLine();
				writer.write("endTemp = "+endTemp); writer.newLine();
				writer.write("annealItes = "+annealItes); writer.newLine();
				writer.write("coolingTemp = "+coolingTemp); writer.newLine();
				writer.write("coolingItes = "+coolingItes); writer.newLine();
			}
			writer.flush();
			writer.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
}
