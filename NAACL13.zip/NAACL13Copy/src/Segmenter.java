import gnu.trove.list.array.TIntArrayList;
import java.io.*;
import java.util.*;

/**
 * 
 * @author Du Lan
 *
 */
public class Segmenter {
	private Corpus corpus;
	private Vocabulary voc;
	private MTRandom rand;
	private TopicSampler tsampler;
	private BoundarySampler bsampler;
	private ConcentrationSampler csampler;
	private int margCounts[][]; // where to keep samples;
	//caches
	TIntArrayList sentList;
	
	public Segmenter(Corpus corpus, Vocabulary voc, MTRandom rand) {
		this.corpus = corpus;
		this.voc = voc;
		this.rand = rand;
		//initialize state
		State.alloc(corpus, voc);
		State.initialise(corpus, rand);
		//Create three different samplers
		tsampler = new TopicSampler(corpus, rand);
		bsampler = new BoundarySampler(corpus, rand);
		csampler = new ConcentrationSampler(rand);
		//allocate space for holding boundary samples
		margCounts = new int[corpus.numDocs()][];
		for(int d = 0; d < corpus.numDocs(); d++) {
			margCounts[d] = new int[corpus.numSents(d)];
			Arrays.fill(margCounts[d], 0);
		}
		//allocate cache
		sentList = new TIntArrayList(corpus.maxNumSentPerDoc());
	}
	
	public void runSegment() {
		int numSamples = 0;
		if(Parameter.doAnnealing)
			Annealer.set();
		for (int ite = 1; ite <= Parameter.maxItes; ite++) {	
			oneGibbsCycle(ite);
			if(Parameter.verbose >= 5000 || ite == Parameter.maxItes) {
				System.out.printf("ite = %d, likilihood = %.3f, numSegs = %d, " +
						"hypoSegRatio = %.3f,  trueSegRation = %.3f, annealingTemp = %.4f\n",
						ite, this.modelLogLikelihood(), State.totalSegs(), 
						State.segRatio(), corpus.aveNumSegPerDoc(),Annealer.temp());
			}
			if(Parameter.doAnnealing)
				Annealer.update();
			learnParameters(ite);
			//Draw samples
			if (ite > Parameter.burnIn && ite % Parameter.lag == 0) {
				for(int d = 0; d < corpus.numDocs(); d++) {
					for(int s = 0; s < corpus.numSents(d); s++) 
						margCounts[d][s] += State.rhos[d][s];
				}
				numSamples++;
			}
			if(Parameter.verbose >= 5000)
				System.out.println();
		}
		//
		if(Parameter.debug) {
			for(int d = 0; d < corpus.numDocs(); d++) 
				assert margCounts[d][corpus.numSents(d)-1] == numSamples;
		}
	}
	
	/**
	 * Run one Gibbs cycle through all documents.
	 * 
	 * @param ite
	 */
	private void oneGibbsCycle(int ite) {
		long startTime = System.currentTimeMillis();
		int d, s, i;
		for (d = 0; d < corpus.numDocs(); d++) {
			sentList.clear();
			for(s = 0; s < corpus.numSents(d); s++)
				sentList.add(s);
			sentList.shuffle(rand);
			for(i = 0; i < sentList.size(); i++){
				s = sentList.get(i);
				tsampler.sample(d, s);
				if(s < corpus.numSents(d)-1)
					bsampler.sample(d, s);
			}				
		}
		if(Parameter.verbose >= 5000)
			System.out.printf("ite = %d, gibbs running time: %.3f\n", 
					ite, (System.currentTimeMillis() - startTime)/1000.0);
	}
	
	private void learnParameters(int ite) {
		long startTime = System.currentTimeMillis();
		if(Parameter.learnB)
			csampler.sample_b(ite);
		if(Parameter.verbose >= 5000)
			System.out.printf("ite = %d, parameter leaning time: %.3f\n", 
					ite, (System.currentTimeMillis() - startTime)/1000.0);
	}
	
	public void save() {
		BufferedWriter writer;
		String str;
		StringBuffer buffer;
		try{
			//save marginal rho counts
			str = Parameter.root+File.separator+"sampled_rhos.log";
			writer = new BufferedWriter(new FileWriter(str));
			for(int d = 0; d < margCounts.length; d++) {
				buffer = new StringBuffer();
				for(int s = 0; s < margCounts[d].length; s++) {
					buffer.append(margCounts[d][s]);
					if(s < margCounts[d].length - 1)
						buffer.append(",");
				}
				writer.write(buffer.toString());
				writer.newLine();
			}
			writer.flush();
			writer.close();
			//save topic-by-word count matrix
			str = Parameter.root+File.separator+"topic_word_counts.log";
			writer = new BufferedWriter(new FileWriter(str));
			for(int k = 0; k < State.MKW.length; k++) {
				buffer = new StringBuffer();
				for(int w = 0; w < State.MKW[k].length; w++) {
					buffer.append(State.MKW[k][w]);
					if(w < State.MKW[k].length - 1)
						buffer.append(",");
				}
				writer.write(buffer.toString());
				writer.newLine();
			}
			writer.flush();
			writer.close();
			//save top words for each topic
			State.commpute_phis();
			str = Parameter.root+File.separator+"top_words_for_topics.log";
			this.saveTopWord4Topic(str);
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	private double modelLogLikelihood() {
		double logProb = 0.0;
		for (int d = 0; d < corpus.numDocs(); d++) {
			logProb += Maths.logBeta(Parameter.lambda1 + State.c1[d], Parameter.lambda0 + State.c0[d]);
			logProb -= Maths.logBeta(Parameter.lambda1, Parameter.lambda0);
			logProb += Maths.logGamma(Parameter.alphaSum) - Maths.logGamma(Parameter.alphaSum + State.td[d]);
			for (int k = 0; k < Parameter.numTopics; k++)
				logProb += Maths.logGamma(Parameter.alpha[k] + State.tdk[d][k]) - Maths.logGamma(Parameter.alpha[k]);
			ArrayList<Segment> docSegList = State.docSegsMap.get(d);
			for (int s = 0; s < docSegList.size(); s++) {
				Segment seg = docSegList.get(s);
				logProb += Maths.logPochSym(Parameter.b, Parameter.a, seg.T) 
							- Maths.logPochSym(Parameter.b, 1.0, seg.N);
//				assert Maths.isnormal(logProb) : "logProb = " + logProb;
				for (int k = 0; k < Parameter.numTopics; k++) {
					logProb += StirNum.logSN(seg.nk[k], seg.tk[k]);
					logProb -= Maths.logChoose(seg.nk[k], seg.tk[k]);
				}
//				assert Maths.isnormal(logProb) : "logProb = " + logProb;
			}
		}
		for(int k = 0; k < Parameter.numTopics; k++) {
			logProb += Maths.logGamma(Parameter.betaSum) 
						- Maths.logGamma(Parameter.betaSum + State.MK[k]);
			for(int w = 0; w < voc.size(); w++) {
				logProb += Maths.logGamma(Parameter.beta[w] + State.MKW[k][w]) 
						- Maths.logGamma(Parameter.beta[w]);
			}
		}
		logProb = -logProb / corpus.numTokens();

		if (Double.isInfinite(logProb) || Double.isNaN(logProb)) {
			System.err.println("modelLogLikelihood(): logProb is infinite or NaN!!!");
			System.exit(0);
		}

		return logProb;
	}
	
	private void saveTopWord4Topic(String fileName) {
		try {
			FileWriter fwriter = new FileWriter(new File(fileName));
			Map<String, Double> treeMap = new TreeMap<String, Double>();
			for (int k = 0; k < Parameter.numTopics; k++) {
				for (int w = 0; w < voc.size(); w++)
					treeMap.put(voc.getType(w), new Double(State.phis[k][w]));
				treeMap = this.sortByValueDecending(treeMap);
				fwriter.write("Topic-" + k + ": ");
				int count = 0;
				for (String key : treeMap.keySet()) {
					if (count == Parameter.NUMTOPWORDS - 1) {
						fwriter.write(key + "(" + treeMap.get(key) + ")\n");
					} else {
						fwriter.write(key + "(" + treeMap.get(key) + ") ");
					}
					count++;
					if (count == Parameter.NUMTOPWORDS)
						break;
				}
				fwriter.write("\n");
				fwriter.flush();
				treeMap.clear();
			}
			fwriter.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	private <K, V extends Comparable<? super V>> Map<K, V> sortByValueDecending(
			Map<K, V> map)
	{
		List<Map.Entry<K, V>> list = new LinkedList<Map.Entry<K, V>>(
				map.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<K, V>>() {
			public int compare(Map.Entry<K, V> o1, Map.Entry<K, V> o2)
			{
				int compare = (o1.getValue()).compareTo(o2.getValue());
				return -compare;
			}
		});

		Map<K, V> result = new LinkedHashMap<K, V>();
		for (Map.Entry<K, V> entry : list) {
			result.put(entry.getKey(), entry.getValue());
		}
		return result;
	}
}
