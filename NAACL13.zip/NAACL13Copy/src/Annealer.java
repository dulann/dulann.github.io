/**
 * 
 * @author Du Lan
 *
 */
public final class Annealer {
	private static int ite;
	private static double currentTmp;

	public static void set() {
		ite = 0;
	}
	
	public static void update() {
		ite++;
	}
	
	public static double temp() {
		return currentTmp;
	}
	
	/**
	 * which is usually used
	 * @param prob
	 * @return
	 */
	public static double annealScheduelOne(double prob) {
		currentTmp = 1.0;
		if(ite < Parameter.annealItes){
			currentTmp = 1.0 + ((double) Parameter.startTemp - 1.0) 
								* (1.0 - (double) ite / Parameter.annealItes);
//			currentTmp = Parameter.startTemp*Math.pow(Parameter.endTemp/Parameter.startTemp, 
//							(double)ite/(Parameter.annealItes-1.0));
		} else if (ite + Parameter.coolingItes > Parameter.maxItes) {
			currentTmp = Parameter.coolingTemp;
		} else {
			currentTmp = Parameter.endTemp;
		}
		return Math.pow(prob, 1.0 / currentTmp); 
	}
	
	public static double annealScheduleTwo(double prob) {
		currentTmp = 1.0;
		if(ite < Parameter.annealItes/2) {
			currentTmp = 2.0;
		}
		return Math.pow(prob, 1.0 / currentTmp); 
	}
	
	public static double annealScheduleThree(double prob) {
		currentTmp = 1.0;
		if(ite < Parameter.annealItes){
			currentTmp = 1.0 + ((double) Parameter.startTemp - 1.0) * (1.0 - (double) ite / Parameter.annealItes);
		} else if (ite + Parameter.coolingItes > Parameter.maxItes) {
			currentTmp = ((double) Parameter.maxItes - ite + 1) / ((double) Parameter.coolingItes);
		} else {
			currentTmp = Parameter.endTemp;
		}
		return Math.pow(prob, 1.0 / currentTmp); 
	}
}
