import java.util.ArrayList;

/**
 * Learn the concentration parameter using
 * Adaptive rejection Metropolis sampler (ARMS).
 * 
 * @author Du Lan
 *
 */
public class ConcentrationSampler extends ArmSampler
{
	private static final double BMIN = 0.01;
	private static final double BMAX = 2000;
	private static final int QITES = 5;
	
	private double SCALE;
	private double SHAPE;
	private MTRandom rand;
	
	private double lgqSum;
	
	/**
	 * 
	 * @param rand
	 */
	public ConcentrationSampler(MTRandom rand){
		this.rand = rand;
		SCALE = Parameter.scale; 
		assert Parameter.scale > 0;
		SHAPE = Parameter.shape;
	}
	
	public double logpdf(double b, Object params) {
		double val = (lgqSum - 1.0/SCALE) * b + (SHAPE - 1.0)*Math.log(b);
		double lba = Maths.logGamma(b/Parameter.a);
		for(int d = 0; d < State.docSegsMap.size(); d++) {
			ArrayList<Segment> docSegList = State.docSegsMap.get(d);
			for(int s = 0; s < docSegList.size(); s++) {
				Segment seg = docSegList.get(s);
				val += Maths.logGamma(b/Parameter.a + seg.T) - lba;
			}
		}
		return val;
	}
	
	public void sample_b(int iteration) {
		double old_b = Parameter.b;
		lgqSum = 0;
		for(int d = 0; d < State.docSegsMap.size(); d++) {
			ArrayList<Segment> docSegList = State.docSegsMap.get(d);
			for(int s = 0; s < docSegList.size(); s++) {
				double q = 0;
				int ite = 10;
				while(q <= 0 && ite-- > 0) 
					q = rand.nextBeta(old_b, docSegList.get(s).N);
				assert q > 0 : "Error: q <= 0 !!! q = "+q+", b = "+old_b+", seg.N = "+docSegList.get(s).N;
				
				if(q < 1e-10)
					q = 1e-10;
				lgqSum += Math.log(q);
			}
		}
		double new_b = 0;
		if(Parameter.a == 0){
			double totalT = SHAPE;
			for(int d = 0; d < State.docSegsMap.size(); d++)
				totalT += State.td[d];
			if(totalT > 400){
				do{
					new_b = totalT + rand.nextGaussian()*Math.sqrt(totalT);
				}while(new_b <= 0);
			}else{
				for(int i = 0; i < QITES; i++)
					new_b = rand.nextGamma(totalT, 1.0);
				new_b /= 1.0/SCALE - lgqSum;
			}
			if(new_b < BMIN)
				new_b = BMIN;
			if(new_b > BMAX)
				new_b = BMAX;
		}else{
			double initb = old_b;
			if(Math.abs(initb-BMAX)/BMAX < 0.00001){
				initb = BMAX*0.999 + BMIN*0.001;
			}
			if(Math.abs(initb-BMIN)/BMIN < 0.00001){
				initb = BMIN*0.999 + BMAX*0.001;
			}
			double[] xl = {BMIN};
			double[] xr = {BMAX};
			double[] xprev = {initb};
			try{
				new_b = armsSimple(null, 5, xl, xr, false, xprev);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		if(Parameter.verbose >= 5000){
			System.out.printf("ite = %d, old b = %.3f, Arm sampled b = %.3f\n", iteration, old_b, new_b);
		}
		Parameter.b = new_b;
	}
}
