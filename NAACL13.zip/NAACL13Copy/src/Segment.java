import java.util.*;
import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 * 
 * @author Du Lan
 *
 */
public final class Segment {
	public final int d;
	public final int start; 
	public final int end;
	//CRP counts
	public int T;
	public int N;
	public int[] tk;
	public int[] nk;

	public Segment(int start, int end, int d) {
		this.d = d;
		this.start = start;
		this.end = end;
		assert start <= end;
		N = 0;
		nk = new int[Parameter.numTopics];
		Arrays.fill(nk, 0);
		T = 0;
		tk = new int[Parameter.numTopics];
		Arrays.fill(tk, 0);
	}

	/**
	 * Return true if the segment contains the given sentence/paragraph.
	 * 
	 * @param s
	 * @return
	 */
	public boolean contains(int s) {
		return s >= start && s <= end;
	}
	
	/**
	 * For debugging.
	 * 
	 */
	public void validate() {
		assert T > 0;
		assert N >= T; 
		int sumtk = 0, sumnk = 0;
		for (int k = 0; k < nk.length; k++) {
			assert tk[k] >= 0;
			assert nk[k] >= tk[k];
			if(tk[k] == 0)
				assert nk[k] == 0;
			if(nk[k] == 0)
				assert tk[k] == 0;
			sumtk += tk[k];
			sumnk += nk[k];
		}
		assert sumtk == T;
		assert sumnk == N;
	}

	/**
	 * 
	 */
	public boolean equals(Object o) {
		if (o instanceof Segment) {
			Segment seg = (Segment) o;
			if (d != seg.d
					|| start != seg.start 
					|| end != seg.end 
					|| N != seg.N
					|| !Arrays.equals(nk, seg.nk) 
					|| T != seg.T
					|| !Arrays.equals(tk, seg.tk)) {
				return false;
			}
			return true;
		}
		return false;
	}

	/**
	 * 
	 */
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}
}
