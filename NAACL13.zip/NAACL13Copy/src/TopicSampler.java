import java.util.ArrayList;
import java.util.Collections;

/**
 * 
 * @author Du Lan
 *
 */
public class TopicSampler {
	private Corpus corpus;
	private MTRandom rand;
	//caches
	double[] topicProbs;
	double[] indOneProbs;
	double[] indZeroProbs;
	
	/**
	 * 
	 * @param corpus
	 * @param rand
	 */
	public TopicSampler(Corpus corpus, MTRandom rand) {
		this.corpus = corpus;
		this.rand = rand;
		// cache
		topicProbs = new double[Parameter.numTopics];
		indOneProbs = new double[Parameter.numTopics];
		indZeroProbs = new double[Parameter.numTopics];
	}

	/**
	 * Sample topics for all sentences/paragraphs in a document
	 *  
	 * @param d
	 */
	public void sample(int d) {
		ArrayList<Segment> docSegList = State.docSegsMap.get(d);
		Collections.shuffle(docSegList, rand);
		for(int sIdx = 0; sIdx < docSegList.size(); sIdx++)
			sample(d, docSegList.get(sIdx));
	}
	
	/**
	 * Sample topics for a given segment.
	 * 
	 * @param d
	 * @param seg
	 */
	private void sample(int d, Segment seg) {
		for(int s = seg.start; s <= seg.end; s++)
			sample(d, s, seg);
		if(Parameter.debug) {
			seg.validate();
			State.checkBagOfWord(corpus);
		}
	}
	
	/**
	 * Sample topics for a given sentence/paragraph.
	 * 
	 * @param d
	 * @param s
	 */
	public void sample(int d, int s) {
		Segment seg = State.findSegment(d, s);
		sample(d, s, seg);
		if(Parameter.debug) {
			seg.validate();
			State.checkBagOfWord(corpus);
		}
	}

	/**
	 * Sample topics for a given sentence/paragraph.
	 * 
	 * @param d
	 * @param s
	 * @param seg
	 */
	public void sample(final int d, final int s, Segment seg) {
		int n, m, w, k;
		int wIdx = 0;
		for(n = 0; n < corpus.numTypes(d, s); n++) {
			w = corpus.type(d, s, n);
			for(m = 0; m < corpus.count(d, s, n); m++) {
				k = State.topics[d][s][wIdx];
				k = sampleWord(d, s, w, k, seg);
				State.topics[d][s][wIdx] = (new Integer(k)).shortValue();
				wIdx ++;
			}
		}
	}
	
	/**
	 * Sample a topic for a given word.
	 * 
	 * @param d
	 * @param s
	 * @param w
	 * @param k
	 * @param seg
	 * @return
	 */
	private int sampleWord(final int d, final int s, final int w, int k, Segment seg) {
		int indicator = 0;
		if(((double)seg.tk[k]/seg.nk[k]) > rand.nextDouble())
			indicator = 1;
		if(seg.nk[k] == 1 || seg.tk[k] > 1 || indicator == 0){
			if(indicator == 1) {
				seg.tk[k]--;
				seg.T--;
				State.td[d]--;
				State.tdk[d][k]--;
			}
			seg.N--;
			seg.nk[k]--;
			State.MK[k]--;
			State.MKW[k][w]--;
			double sum = 0;
			for (k = 0; k < Parameter.numTopics; k++) {
				indOneProbs[k] = probIndOne(d, k, w, seg);
				if (seg.tk[k] == 0) {
					assert seg.nk[k] == 0;
					indZeroProbs[k] = 0.0;
				} else {
					assert seg.nk[k] > 0 && seg.nk[k] >= seg.tk[k];
					indZeroProbs[k] = probIndZero(k, w, seg);
				}
				topicProbs[k] = indOneProbs[k] + indZeroProbs[k];
				sum += topicProbs[k];
			}
			k = rand.nextDiscrete(topicProbs, sum);		
			if ((indOneProbs[k] / topicProbs[k]) > rand.nextDouble()) {
				seg.tk[k]++;
				seg.T++;
				State.td[d]++;
				State.tdk[d][k]++;
			} 
			seg.N++;
			seg.nk[k]++;
			State.MK[k]++;
			State.MKW[k][w]++;
		}
		return k;
	}
	
	/**
	 * The joint probability of assigning a topic to a word and this
	 * word is a table head.
	 * 
	 * @param d
	 * @param k
	 * @param w
	 * @param seg
	 * @return
	 */
	private double probIndOne(final int d, final int k, final int w, Segment seg) {
		double prob = ((Parameter.alpha[k] + State.tdk[d][k]) 
						/ (Parameter.alphaSum + State.td[d]))
					* ((Parameter.b + Parameter.a * seg.T) 
							/ (Parameter.b + seg.N))
					* StirNum.ratioOne(seg.nk[k], seg.tk[k])
					* ((seg.tk[k] + 1.0) / (seg.nk[k] + 1.0))		
					* ((Parameter.beta[w] + State.MKW[k][w]) 
						/ (Parameter.betaSum + State.MK[k]));
		
		assert Maths.isnormal(prob) : "tdk = "+ State.tdk[d][k]+", td =" +  State.td[d]
						+", seg.T = "+seg.T+", seg.N = "+seg.N+", seg.nk = "+seg.nk[k]
						+", seg.tk ="+seg.tk[k]
						+", ratioOne = "+StirNum.ratioOne(seg.nk[k], seg.tk[k]);
		return prob;
	}
	
	/**
	 * The joint probability of assigning a topic to a word and this
	 * word is not a table head.
	 * 
	 * @param k
	 * @param w
	 * @param seg
	 * @return
	 */
	private double probIndZero(int k, int w, Segment seg) {
		double prob = StirNum.ratioTwo(seg.nk[k], seg.tk[k]) / (Parameter.b + seg.N);
		prob *= (seg.nk[k] - seg.tk[k] + 1.0) / (seg.nk[k] + 1.0);
		prob *= (Parameter.beta[w] + State.MKW[k][w]) 
			/ (Parameter.betaSum + State.MK[k]);
		assert Maths.isnormal(prob) : "seg.T = "+seg.T+", seg.N = "+seg.N
					+", seg.nk = "+seg.nk[k]+", seg.tk ="+seg.tk[k]
					+", ratioOne = "+StirNum.ratioOne(seg.nk[k], seg.tk[k]);
		return prob;
	}
	
	/**
	 * 
	 * @param obj
	 */
	void yap(Object obj){
		System.out.println(obj);
	}
}