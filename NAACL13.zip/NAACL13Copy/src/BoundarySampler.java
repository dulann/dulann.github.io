import gnu.trove.list.array.TIntArrayList;
import java.util.*;
/**
 * 
 * @author Du Lan
 *
 */
public class BoundarySampler {	
	private Corpus corpus;
	private MTRandom rand;
	private EleSymPoly esp;
	private final double LOG2 = Math.log(2.0);
	//caches
	private ArrayList<Integer> topicsForPoly;
	private ArrayList<Double> elementsForPoly;
	private ArrayList<Double> hLogProbs;
	private TIntArrayList sentList;
	private double yes;
	private double no;
	
	public BoundarySampler(Corpus corpus, MTRandom rand) {
		this.corpus = corpus;
		this.rand = rand;
		esp = new EleSymPoly(rand);
		topicsForPoly = new ArrayList<Integer>(Parameter.numTopics);
		elementsForPoly = new ArrayList<Double>(Parameter.numTopics);
		hLogProbs = new ArrayList<Double>(Parameter.numTopics+1);
		sentList = new TIntArrayList(corpus.maxNumSentPerDoc());
	}
	
	/**
	 * Sample topic boundaries for a document
	 * 
	 * @param d
	 */
	public void sample(int d){
		int s;
		sentList.clear();
		for(s = 0; s < corpus.numSents(d); s++)
			sentList.add(s);
		sentList.shuffle(rand);
		for(s = 0; s < corpus.numSents(d); s++)
			sample(d, sentList.get(s));	
	}
	
	/**
	 * Sample a topic boundary after a sentence.
	 * 
	 * @param d
	 * @param s
	 */
	public void sample(int d, int s) {
		topicsForPoly.clear();
		elementsForPoly.clear();
		hLogProbs.clear();
		if (State.rhos[d][s] == 1)
			sampleFromSplitCase(d, s);
		else
			sampleFromMergeCase(d, s);	
	}
	
	/**
	 * Sample to merge two segments.
	 * 
	 * @param d
	 * @param s
	 */
	private void sampleFromSplitCase(int d, int s) {
		Segment segL = State.findSegment(d, s);
		Segment segR = State.findSegment(d, s+1);
		//remove boundary count
		State.c1[d]--;
		if(Parameter.debug){
			assert segL.end == s;
			assert segR.start == s + 1;
		}		
		yes = logYesBoundaryProb(segL, segR, State.td[d], State.tdk[d], d);
		Segment segM = new Segment(segL.start, segR.end,  d);//Create an empty segment
		no = logNoBoundaryProb(segL, segR, segM, d);
		yes = 1.0 / (1.0 + Math.exp(no - yes));
		if(Parameter.verbose >= 20000) {
			yap("From split case logYesBoundaryProb = " + yes);
			yap("From split case logNoBoundaryProb = " + no);
			yap("From split case, Yesprob = " + yes);
		}
		//do simulated Annealing???
		if(Parameter.doAnnealing) {
			no = Annealer.annealScheduelOne(1.0 - yes);
			yes = Annealer.annealScheduelOne(yes);
			yes = yes/(yes + no);
		}
		if (yes > rand.nextDouble()) {
			State.rhos[d][s] = 1;
			State.c1[d]++;			
		}else{
			State.docSegsMap.get(d).remove(segR);
			State.docSegsMap.get(d).remove(segL);
			if(topicsForPoly.size() > 0){
				int h = sampleH(hLogProbs);
				int[] bitVector = esp.sympoly_sampled_index(h, elementsForPoly);
				if(Parameter.verbose >= 20000){
					yap("Sampled h = " + h);
					yap("Sampled bitVector: "+Arrays.toString(bitVector));
				}
				segM.T += h;
				State.td[d] += segM.T - segL.T - segR.T;
				for(int i = 0; i < topicsForPoly.size(); i++) {
					int k = topicsForPoly.get(i).intValue();
					if(bitVector[i] == 1)
						segM.tk[k]++;
					State.tdk[d][k] += segM.tk[k] - segL.tk[k] - segR.tk[k];
				}
			}
			State.docSegsMap.get(d).add(segM);
			State.rhos[d][s] = 0;
			State.c0[d]++;			
		}	
		if(Parameter.debug) {
			State.checkDoc(d, corpus);
			State.checkDocSegList(d);
		}
	}
	
	/**  
	 * Sample to split a segment.
	 * 
	 * @param d
	 * @param s
	 */
	private void sampleFromMergeCase(int d, int s) {
		Segment segM = State.findSegment(d, s);
		//remove boundary count
		State.c0[d]--;
		// Create two partitions, segL and segR		
		Segment segL = new Segment(segM.start, s, d);
		Segment segR = new Segment(s+1, segM.end, d);
		sampleTableInidcators(d, segM, segL, segR);
		/*
		 * Given the two partitions, compute the probability of a merged state.
		 * For this, we create a temporary merge segment from segL and segR.
		 */
		Segment segMNew = new Segment(segM.start, segM.end, d);//create an empty segment
		no = logNoBoundaryProb(segL, segR, segMNew, d);
		/*
		 * Given the two partitions, compute the probability of a split move
		 */
		int td = State.td[d];
		int[] tdk = Arrays.copyOf(State.tdk[d], Parameter.numTopics);
		for(int k = 0; k < Parameter.numTopics; k++) {
			if (segL.nk[k] > 0 && segL.tk[k] == 0) {
				segL.tk[k]++;
				segL.T++;
				tdk[k]++;
				td++;
			} else {
				assert (segL.nk[k] == 0 && segL.tk[k] == 0)
						|| (segL.nk[k] > 0 && segL.tk[k] > 0);
			}
			if (segR.nk[k] > 0 && segR.tk[k] == 0) {
				segR.tk[k]++;
				segR.T++;
				tdk[k]++;
				td++;
			} else {
				assert (segR.nk[k] == 0 && segR.tk[k] == 0)
						|| (segR.nk[k] > 0 && segR.tk[k] > 0);
			}
		}
		yes = logYesBoundaryProb(segL, segR, td, tdk, d);
		/*
		 * Sample to either split or merge
		 */
		yes = 1.0 / (1.0 + Math.exp(no - yes));
		if(Parameter.verbose >= 20000) {
			yap("From merged case, logNoBoundaryProb = " + no);
			yap("From merged case, logYesBoundaryProb = " + yes);
			yap("From merged case, YesProb ==== " + yes);
		}
		//do simulated Annealing???
		if(Parameter.doAnnealing) {
			no = Annealer.annealScheduelOne(1.0 - yes);
			yes = Annealer.annealScheduelOne(yes);
			yes = yes/(yes + no);
		}
		/*
		 * Recompute the state
		 */
		if (yes > rand.nextDouble()) {
			State.docSegsMap.get(d).remove(segM);
			State.docSegsMap.get(d).add(segR);
			State.docSegsMap.get(d).add(segL);
			State.td[d] = td;
			for(int k = 0; k < Parameter.numTopics; k++)
				State.tdk[d][k] = tdk[k];
			State.rhos[d][s] = (short) 1;
			State.c1[d]++;
		}else{
			State.rhos[d][s] = (short) 0;
			State.c0[d]++;
		}
		
		if(Parameter.debug) {
			State.checkDoc(d, corpus);
			State.checkDocSegList(d);
		}
	}
	
	private void sampleTableInidcators(final int d, Segment segM, Segment segR, Segment segL) {
		Segment seg;
		int wIdx, k, s;
		int[] tk = Arrays.copyOf(segM.tk, segM.tk.length);
		int[] nk = Arrays.copyOf(segM.nk, segM.nk.length);
		//Randomly shuffle the sentences
		TIntArrayList sList = new TIntArrayList();
		for(s = segM.start; s <= segM.end; s++)
			sList.add(s);
		sList.shuffle(rand);
		//reconstruct customer/table counts
		for(int i = 0; i < sList.size(); i++){//For each sentence
			s = sList.get(i);
			if(s >= segR.start && s <= segR.end)
				seg = segR;
			else
				seg = segL;
			wIdx = 0;
			for(int n = 0; n < corpus.numTypes(d, s); n++) {//For each type
				for(int m = 0 ; m < corpus.count(d, s, n); m++){
					k = State.topics[d][s][wIdx];
					if(((double)tk[k]/nk[k]) > rand.nextDouble()){
						seg.tk[k]++;
						seg.T++;
						tk[k]--;
					}
					seg.N++;
					seg.nk[k]++;
					nk[k]--;
					wIdx++;
				}
			}
		}
		if(Parameter.debug) {
			assert segR.N + segL.N == segM.N;
			assert segR.T + segL.T == segM.T;
			for(k = 0; k < tk.length; k++) {
				assert segR.nk[k] + segL.nk[k] == segM.nk[k];
				assert segR.tk[k] + segL.tk[k] == segM.tk[k];
			}
		}
	}
	
	private double logYesBoundaryProb(Segment segOne, Segment segTwo, 
			final int td, int[] tdk, final int d) 
	{
		double logProb = Math.log((State.c1[d] + Parameter.lambda1) 
							/ (State.c0[d] + State.c1[d] + Parameter.lambda1+Parameter.lambda0))
							- Maths.logGamma(Parameter.alphaSum + td)
							+ Maths.logPochSym(Parameter.b, Parameter.a, segOne.T)
							- Maths.logPochSym(Parameter.b, 1.0, segOne.N)
							+ Maths.logPochSym(Parameter.b, Parameter.a, segTwo.T)
							- Maths.logPochSym(Parameter.b, 1.0, segTwo.N);
		for (int k = 0; k < Parameter.numTopics; k++) {
			logProb += Maths.logGamma(Parameter.alpha[k] + tdk[k])
						+ StirNum.logSN(segOne.nk[k], segOne.tk[k])
						+ StirNum.logSN(segTwo.nk[k], segTwo.tk[k]);
		}
		assert Maths.isnormal(logProb) : "logYesProb = " + logProb;
		return logProb;
	}

	private double logNoBoundaryProb(Segment segOne, Segment segTwo, 
			Segment segM, final int d) 
	{
		if(Parameter.debug){//to make sure segM is an "empty" segment.
			assert segM.N == 0;
			assert segM.T == 0;
			for(int k = 0; k < Parameter.numTopics; k++) {
				assert segM.nk[k] == 0;
				assert segM.tk[k] == 0;
			}
		}
		
		double prob, alphatdk;
		int tprim; // for double case
		boolean doCases;
		
		segM.N = segOne.N + segTwo.N;
		double logProb = Math.log((Parameter.lambda0 + State.c0[d]) 
							/(Parameter.lambda0 + Parameter.lambda1 + State.c1[d] + State.c0[d]))
						 - Maths.logPochSym(Parameter.b, 1.0, segM.N);
		for(int k = 0; k < Parameter.numTopics; k++) {
			segM.nk[k] = segOne.nk[k] + segTwo.nk[k];
			alphatdk = Parameter.alpha[k] + State.tdk[d][k];
			doCases = segOne.nk[k] > 0 && segTwo.nk[k] > 0;
			if(doCases && segOne.tk[k] <= 1 && segTwo.tk[k] > 1){
				/*
				 * Single case
				 * 		segOne.segt[k] <= 1
				 * 		segTwo.segt[k] > 1
				 */
				segM.tk[k] = segTwo.tk[k];
				segM.T += segTwo.tk[k];
				prob = alphatdk - segOne.tk[k];
				logProb += Maths.logGamma(prob) + StirNum.logSN(segM.nk[k], segM.tk[k]);
				// Symmetric Polynomial element
				prob *= StirNum.ratioThree(segM.nk[k], segM.tk[k]+1);
				elementsForPoly.add(new Double(prob));
				topicsForPoly.add(new Integer(k));
				//
				if(Parameter.debug){
					assert Maths.isnormal(logProb) : "logProb = "+logProb;
					assert prob > 0;
					assert Maths.isnormal(prob) : "prob = "+prob;
				}	
			}else if(doCases && segOne.tk[k] > 1 && segTwo.tk[k] <= 1 ){
				/*
				 * Single case
				 * 		segOne.segt[k] > 1
				 * 		segTwo.segt[k] <= 1
				 */
				segM.tk[k] = segOne.tk[k];
				segM.T += segOne.tk[k];				
				prob = alphatdk - segTwo.tk[k];
				logProb += Maths.logGamma(prob) + StirNum.logSN(segM.nk[k], segM.tk[k]);
				// polynomial element
				prob *= StirNum.ratioThree(segM.nk[k], segM.tk[k]+1);
				elementsForPoly.add(new Double(prob));
				topicsForPoly.add(new Integer(k));
				//
				if(Parameter.debug){
					assert Maths.isnormal(logProb) : "logProb = "+logProb;
					assert prob > 0;
					assert Maths.isnormal(prob) : "prob = "+prob;
				}	
			}else if(doCases && segOne.tk[k] <= 1 && segTwo.tk[k] <= 1){
				/*
				 * Double case
				 */
				tprim = segOne.tk[k] + segTwo.tk[k] - 1;
				segM.tk[k] = 1;
				segM.T += 1;
				prob = alphatdk - tprim;
				logProb += Maths.logGamma(prob) + StirNum.logSN(segM.nk[k], 1) + LOG2;
				// Polynomial elements
				prob *=  StirNum.ratioThree(segM.nk[k], 2) * 0.5;
				elementsForPoly.add(new Double(prob));
				topicsForPoly.add(new Integer(k));
				//
				if(Parameter.debug){
					assert  tprim >= 0 && tprim <= 1 : "tprim = "+tprim;
					assert Maths.isnormal(logProb) : "logProb = "+logProb;
					assert prob > 0;
					assert Maths.isnormal(prob) : "prob = "+prob;
				}
			}else{
				/*
				 * None case
				 */
				segM.tk[k] = segOne.tk[k] + segTwo.tk[k];
				segM.T += segM.tk[k];
				logProb += Maths.logGamma(alphatdk) + StirNum.logSN(segM.nk[k], segM.tk[k]);
				if(Parameter.debug)
					assert Maths.isnormal(logProb) : "logProb = "+logProb;
			}
		}
		int unAffected_td = State.td[d] - segOne.T - segTwo.T + segM.T;
		
		if(topicsForPoly.size() == 0){			
			logProb += Maths.logPochSym(Parameter.b, Parameter.a, segM.T)
						- Maths.logGamma(Parameter.alphaSum + State.td[d]);			
			if(Parameter.debug){
				assert segM.T == segOne.T + segTwo.T;
				assert unAffected_td == State.td[d];
				assert Maths.isnormal(logProb) : "logNoProb = "+logProb;
			}			
		}else{
			if(Parameter.debug)
				assert unAffected_td <= State.td[d];
			// To compute elementary symmetric polynomial
			double[] elemSymPolyRes = new double[elementsForPoly.size()+1];
			double[] overFlow = new double[1];
			esp.sympoly(elementsForPoly, elemSymPolyRes, overFlow);
			
			if(Parameter.verbose >= 20000){
				yap("Do elem.sym.poly!!!");
				yap("Size of topicsForPoly: "+topicsForPoly.size());
				yap(elementsForPoly.toString());
				yap(Arrays.toString(elemSymPolyRes));
			}
			
			for(int h = 0; h <= topicsForPoly.size(); h++) {
				prob = Maths.logPochSym(Parameter.b, Parameter.a, segM.T+h)
				        - Maths.logGamma(Parameter.alphaSum + unAffected_td + h);	
				if(h == 0){
					prob += Math.log(elemSymPolyRes[h]);
				}else{
					prob += Math.log(elemSymPolyRes[h]*Math.exp(overFlow[0]));
				}
				assert Maths.isnormal(prob) : "prob = "+prob + ", segM.T = "+segM.T
												+", h = "+h
												+", unAffectedDocT = "+ unAffected_td
												+", elemSymPolyRes[h] = "+elemSymPolyRes[h];				
				hLogProbs.add(new Double(prob));
			}
			logProb += logSumOverList(hLogProbs);
		}
		assert Maths.isnormal(logProb) : "logNoProb = "+logProb;
		return logProb;
	}
	
	private int sampleH(List<Double> hLogProbabilities) {	
		assert hLogProbabilities.size() > 0;
		double[] probs = new double[hLogProbabilities.size()];
		double sum = 0;
		double max = Collections.max(hLogProbabilities).doubleValue();
		for(int i = 0; i < hLogProbabilities.size(); i++) {
			double tmp = hLogProbabilities.get(i).doubleValue() - max;
			if(tmp > -20.0){
				sum += Math.exp(tmp);
			}
		}
		for(int i = 0; i < hLogProbabilities.size(); i++) {
			double tmp = hLogProbabilities.get(i).doubleValue() - max;
			if(tmp > -20.0)
				probs[i] = Math.exp(tmp)/sum;
			else
				probs[i] = 0.0;
		}
		return rand.nextDiscrete(probs);
	}
	
	private double logSumOverList(List<Double> valueList) {
		double max = Collections.max(valueList).doubleValue();
		double sum = 0;
		for(int i = 0; i < valueList.size(); i++) {
			double tmp = valueList.get(i).doubleValue() - max;
			if(tmp > -20)
				sum += Math.exp(tmp);
		}
		sum = max + Math.log(sum);
		assert Maths .isnormal(sum) :"sum = "+sum;
		return sum;
	}	
	
	private void yap(Object obj) {
		System.out.println(obj);
	}
}
