import gnu.trove.list.array.TIntArrayList;
import java.io.*;

/**
 * 
 * @author Lan Du
 */
public class Corpus {

	private File[] files;
	private int numDocs;

	private TIntArrayList docSentCounts;
	private int[][] goldSegs;
	private int[][][] types;
	private int[][][] typeCounts;

	/**
	 * Create a new Corpus instance for a list of files.
	 * 
	 * @param files
	 *            an array of data files: 
	 *            	files[0] is ".meta" file, 
	 *            	files[1] is ".data" file, and
	 *            	files[2] is ".seg" file.
	 * 
	 * @param voc
	 *            Vocabulary
	 */
	public Corpus(File[] files) {
		this.files = files;
		// Read text passage count for each doc
		this.readMetaFile(files[0]);
		numDocs = docSentCounts.size();
		// Read data file
		this.readDataFile(files[1]);
		// Read seg file
		this.readSegFile(files[2]);
	}

	
	/**
	 * Return the segmentation of whole corpus.
	 * 
	 * @return
	 */
	public int[][] getGoldSeg() {
		return goldSegs;
	}
	
	/**
	 * Return the gold segmentation of a given document.
	 * 
	 * @param d
	 *            document index
	 * @return
	 */
	public int[] getGoldSeg(int d) {
		return goldSegs[d];
	}
	
	/**
	 * Return the total number of segments in gold standard segmentation.
	 * 
	 * @return
	 */
	public int numGoldSegs() {
		int total = 0;
		for(int i = 0; i < goldSegs.length; i++) 
				total += goldSegs[i][goldSegs[i].length-1]+1;
		return total;
	}
	
	/**
	 * Return the average number of true segments per document.
	 * 
	 * @return
	 */
	public double aveNumSegPerDoc() {
		return (double)numGoldSegs()/numDocs;
	}
	

	/**
	 * Return the maximum number of sentences/paragraphs
	 * in a doc.
	 * 
	 * @return
	 */
	public int maxNumSentPerDoc() {
		int max = Integer.MIN_VALUE;
		for(int i = 0; i < docSentCounts.size(); i++) {
			if(docSentCounts.get(i) > max)
				max = docSentCounts.get(i);
		}
		return max;
	}
	
	/**
	 * 
	 * @return
	 */
	public int maxNumTokenPerDoc() {
		int max = Integer.MIN_VALUE;
		for(int i = 0; i < docSentCounts.size(); i++) {
			int tmp = this.numTokens(i);
			if ( tmp > max)
				max = tmp;
		}
		return max;
	}

	
	/**
	 * Return the maximum number of true segments in
	 * a document.
	 * 
	 * @return
	 */
	public int maxDocLenSeg() {
		int max = Integer.MIN_VALUE;
		for(int i = 0; i < goldSegs.length; i++) {
			int length = goldSegs[i][goldSegs[i].length-1]+1;
			if(length > max)
				max = length;
		}
		return max;
	}
	
	/**
	 * Return the total number of documents.
	 * 
	 * @return
	 */
	public int numDocs() {
		return numDocs;
	}

	/**
	 * Return the total number of word tokens in corpus
	 * @return
	 */
	public int numTokens() {
		int totalTokens = 0;
		for(int d = 0; d < typeCounts.length; d++)
			totalTokens += numTokens(d);
		return totalTokens;
	}
	
	/**
	 * Return the total number of tokens in a document.
	 * 
	 * @return
	 */
	public int numTokens(int d) {
		int totalTokens = 0;
		for(int s = 0; s < typeCounts[d].length; s++)
			totalTokens += numTokens(d, s);
		return totalTokens;
	}
	
	/**
	 * Return the number of tokens in a sentence/paragraph.
	 * 
	 * @param d
	 * @param s
	 * @return
	 */
	public int numTokens(int d, int s) {
		int totalTokens = 0;
		for(int n = 0; n < typeCounts[d][s].length; n++)
			totalTokens += typeCounts[d][s][n];
		return totalTokens;
	}
	
	/**
	 * Return the total number of text passage in corpus.
	 * 
	 * @return
	 */
	public int numSents() {
		int totalSents = 0;
		for(int i = 0; i < docSentCounts.size(); i++)
			totalSents += docSentCounts.get(i);
		return totalSents;
	}

	/**
	 * Return the number of sentences in a document.
	 * 
	 * @param d
	 *            document index
	 * @return
	 */
	public int numSents(int d) {
		return docSentCounts.get(d);
	}

	/**
	 * Return the number of types in a sentence.
	 * 
	 * @param d
	 *            document index
	 * @param s
	 *            sentence index
	 * @return
	 */
	public int numTypes(int d, int s) {
		return types[d][s].length;
	}
	
	/**
	 * Return a type.
	 * 
	 * @param d
	 *            document index
	 * @param s
	 *            sentence index
	 * @param n
	 *            type position
	 * @return
	 */
	public int type(int d, int s, int n) {
		return types[d][s][n];
	}
	
	/**
	 * Return the number of instances of a type in a sentence.
	 * 
	 * @param d
	 *            document index
	 * @param s
	 *            sentence index
	 * @param n
	 * 			  type position
	 * @return
	 */
	public int count(int d, int s, int n) {
		return typeCounts[d][s][n];
	}

	/**
	 * Read meta data file. The number at each line is the number
	 * of sentences or paragraphs a doc has.
	 * 
	 */
	private void readMetaFile(File file) {
		docSentCounts = new TIntArrayList();
		System.out.println("Read "+file.getPath());
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			String str;
			while ((str = br.readLine()) != null)
				docSentCounts.add(Integer.parseInt(str));
			br.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	/**
	 * Read gold segmentation file, which contains the ground truth of
	 * segmentation.
	 */
	private void readSegFile(File file) {
		System.out.println("Read "+file.getPath());
		goldSegs= new int[numDocs][];
		int d = 0;
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			String str;
			while ((str = br.readLine()) != null){
				String[] strs = str.split(",");
				assert strs.length == docSentCounts.get(d);
				goldSegs[d] = new int[strs.length];
				int segIdx = 0;
				for(int s = 0; s < strs.length; s++) {
					goldSegs[d][s] = segIdx;
					if(Integer.parseInt(strs[s]) ==  1)
						segIdx++;
				}
//				System.out.println(str);
//				System.out.println(Arrays.toString(goldSegs[d])));
				d++;
			}
			br.close();
			assert d == numDocs;
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	/**
	 * Read documents store in the following format 1) each row corresponds to
	 * a text passage, e.g., paragraph or sentence. 2) each row consists of
	 * "int:int" separated by ",", in which the former is the word index in vocabulary
	 * the later is word count in the corresponding text passage
	 */
	private void readDataFile(File file) {
		System.out.println("Read "+file.getPath());
		types = new int[numDocs][][];
		typeCounts = new int[numDocs][][];
		for (int i = 0; i < numDocs; i++) {
			int np = docSentCounts.get(i);
			types[i] = new int[np][];
			typeCounts[i] = new int[np][];
		}
		try {
			InputStreamReader isr = new InputStreamReader(new FileInputStream(file), "UTF-8");
			BufferedReader br = new BufferedReader(isr);
			for (int i = 0; i < docSentCounts.size(); i++) {
				for (int j = 0; j < docSentCounts.get(i); j++) {
					String[] strs = br.readLine().split(",");
					types[i][j] = new int[strs.length];
					typeCounts[i][j] = new int[strs.length];
					for (int n = 0; n < strs.length; n++) {
						String[] kv = strs[n].split(":");
						assert kv.length == 2;
						types[i][j][n] = Integer.parseInt(kv[0]);
						typeCounts[i][j][n] = Integer.parseInt(kv[1]);
					}
				}
			}
			br.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	
	/**
	 * Save information of this corpus. Mainly for 
	 * debugging purpose.
	 * 
	 * @param dir
	 *            output file directory
	 */
	public void write(String dir) {
		File tmpFile = new File(dir);
		if(!tmpFile.exists())
			tmpFile.mkdirs();
		try {
			// write meta information
			String file = dir + File.separator + files[0].getName();
			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			for (int d = 0; d < docSentCounts.size(); d++) {
				writer.write(docSentCounts.get(d)+"");
				writer.newLine();
			}
			writer.flush();
			writer.close();
			// write data
			file = dir + File.separator + files[1].getName();
			writer = new BufferedWriter(new FileWriter(file));
			for (int d = 0; d < types.length; d++) {
				for (int s = 0; s < types[d].length; s++) {
					for (int n = 0; n < types[d][s].length; n++) {
						if (n == types[d][s].length - 1)
							writer.write(types[d][s][n] + ":" + typeCounts[d][s][n]);
						else
							writer.write(types[d][s][n] + ":" + typeCounts[d][s][n] + ",");
					}
					writer.newLine();
				}
			}
			writer.flush();
			writer.close();
			// write gold standard segmentation			
			file = dir + File.separator + files[2].getName();
			writer = new BufferedWriter(new FileWriter(file));
			for (int d = 0; d < goldSegs.length; d++) {
				for (int s = 0; s < goldSegs[d].length-1; s++) {
					if (goldSegs[d][s] != goldSegs[d][s+1])
						writer.write(1+ ",");
					else
						writer.write(0+ ",");
				}
				writer.write(1+"");
				writer.newLine();
			}
			writer.flush();
			writer.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
}
