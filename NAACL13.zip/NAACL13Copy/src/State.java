import gnu.trove.list.array.TIntArrayList;
import gnu.trove.map.hash.TIntObjectHashMap;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * 
 * @author Du Lan
 *
 */
public final class State {
	// segmentation
	public static TIntObjectHashMap<ArrayList<Segment>> docSegsMap;
	public static short[][] rhos;
	// topic assignment
	public static short[][][] topics;
	// bag of word model
	public static int[][] MKW;
	public static int[] MK;
	public static double[][] phis;
	// table counts at doc level
	public static int[] td;
	public static int[][] tdk;
	// boundary counts for each doc
	public static int[] c1;
	public static int[] c0;

	/**
	 * Allocate memory for counts.
	 * 
	 * @param corpus
	 * @param voc
	 */
	public static void alloc(Corpus corpus, Vocabulary voc) {
		// Segmentation
		docSegsMap = new TIntObjectHashMap<ArrayList<Segment>>(corpus.numDocs());
		rhos = new short[corpus.numDocs()][];
		for (int d = 0; d < corpus.numDocs(); d++) {
			docSegsMap.put(d, new ArrayList<Segment>(corpus.numSents(d)));
			rhos[d] = new short[corpus.numSents(d)];
			Arrays.fill(rhos[d], (short) 0);
		}
		// Topic assignments
		topics = new short[corpus.numDocs()][][];
		for (int d = 0; d < corpus.numDocs(); d++) {
			topics[d] = new short[corpus.numSents(d)][];
			for (int s = 0; s < corpus.numSents(d); s++)
				topics[d][s] = new short[corpus.numTokens(d, s)];
		}
		// Counts for Bag of words
		MKW = new int[Parameter.numTopics][voc.size()];
		phis = new double[Parameter.numTopics][voc.size()];
		for (int k = 0; k < Parameter.numTopics; k++)
			Arrays.fill(MKW[k], 0);
		MK = new int[Parameter.numTopics];
		Arrays.fill(MK, 0);
		// Table counts at doc level
		td = new int[corpus.numDocs()];
		Arrays.fill(td, 0);
		tdk = new int[corpus.numDocs()][Parameter.numTopics];
		for (int d = 0; d < corpus.numDocs(); d++)
			Arrays.fill(tdk[d], 0);
		// boundary counts for each doc
		c1 = new int[corpus.numDocs()];
		Arrays.fill(c1, 0);
		c0 = new int[corpus.numDocs()];
		Arrays.fill(c0, 0);
	}
	
	/**
	 * Function for debugging the model.
	 * 
	 * @param corpus
	 */
	public static void checkBagOfWord(Corpus corpus) {
		int sumMKW;
		int sumMK = 0;
		for(int k = 0; k < MKW.length; k++) {
			sumMKW = 0;
			for(int w = 0; w < MKW[k].length; w++) {
				assert MKW[k][w] >= 0;
				sumMKW += MKW[k][w];
			}
			assert sumMKW == MK[k];
			sumMK += MK[k];
		}
		assert sumMK == corpus.numTokens();
	}
	
	/**
	 * Function for debugging the model.
	 * 
	 * @param d
	 */
	public static void checkDocSegList(int d) {
		ArrayList<Segment> docSegList = docSegsMap.get(d);
		TIntArrayList segIdxList = new TIntArrayList(docSegList.size());
		for(int i = 0; i < docSegList.size(); i++) {
			segIdxList.add(i);
		}
		assert docSegList.size() <= rhos[d].length;
		int segStart = 0;
		while(segStart < rhos[d].length) {
			Segment seg = findSegment(d, segStart);
			int segIdx = docSegList.indexOf(seg);
//			System.out.println("segIdx = "+segIdx);
			segIdxList.remove(segIdx);;
//			System.out.println("seg.d = "+seg.d+", seg.start = "+seg.start+", seg.end = "+seg.end);
			segStart = seg.end + 1;
//			System.out.println("segStart = " + segStart);
		}
		assert segIdxList.size() == 0;
	}

	/**
	 * Function for debugging the model.
	 * 
	 * @param d
	 * @param corpus
	 */
	public static void checkDoc(int d, Corpus corpus) {
		ArrayList<Segment> docSegList = docSegsMap.get(d);
		int sumT = 0;
		int sumN = 0;
		int sumtk[] = new int[Parameter.numTopics];
		Arrays.fill(sumtk, 0);
		for(int i = 0; i < docSegList.size(); i++) {
			Segment seg = docSegList.get(i);
			seg.validate();
			sumT += seg.T;
			sumN += seg.N;
			for(int k = 0; k < Parameter.numTopics; k++)
				sumtk[k] += seg.tk[k];
		}
		assert Arrays.equals(sumtk, tdk[d]);
		assert sumT == td[d];
		assert sumN == corpus.numTokens(d);
		assert sumN >= sumT;
		assert docSegList.size() == c1[d];
		assert c1[d] + c0[d] == corpus.numSents(d);
	}
	
	/**
	 * Average number of hypothetical segments per doc.
	 * 
	 * @return
	 */
	public static double segRatio() {
		return (double) totalSegs()/c1.length;
	}
	
	/**
	 * The total number of hypothetical segments.
	 * 
	 * @return
	 */
	public static int totalSegs() {
		int total = 0;
		for(int d = 0; d < c1.length; d++)
			total += c1[d];
		return total;
	}

	/**
	 * Return the segment that contains a given sentence/paragraph.
	 * 
	 * @param d
	 * @param s
	 * @return
	 */
	public static Segment findSegment(int d, int s) {
		ArrayList<Segment> docSegList = docSegsMap.get(d);
		Segment seg;
		for (int i = 0; i < docSegList.size(); i++) {
			seg = docSegList.get(i);
			if (seg.contains(s))
				return seg;
		}
		return null;
	}

	/**
	 * Compute the posterior word probabilities in each topic.
	 */
	public static void commpute_phis() {
		for (int k = 0; k < MKW.length; k++) {
			for (int w = 0; w < MKW[k].length; w++) {
				phis[k][w] = (Parameter.beta[w] + MKW[k][w])
						/ (Parameter.betaSum + MK[k]);
			}
		}
	}

	/**
	 * Initialize the model.
	 * 
	 * @param corpus
	 * @param rand
	 */
	public static void initialise(Corpus corpus, MTRandom rand) {
		int d, sIdx, s, n, m, wIdx;
		int w, k;
		ArrayList<Segment> docSegList;
		Segment seg;
		// initialize segmentation
		initSeg(corpus, Parameter.segInitCode);
		// initialize topic assignments
		for (d = 0; d < corpus.numDocs(); d++) {
			docSegList = docSegsMap.get(d);
			for (sIdx = 0; sIdx < docSegList.size(); sIdx++) { // for each segment
				seg = docSegList.get(sIdx);
				for (s = seg.start; s <= seg.end; s++) { // for each sentence
					wIdx = 0;
					for (n = 0; n < corpus.numTypes(d, s); n++) { // for each type
						w = corpus.type(d, s, n);
						for (m = 0; m < corpus.count(d, s, n); m++) {
							k = rand.nextInt(Parameter.numTopics);
							topics[d][s][wIdx] = (short) k;
							seg.N++;
							seg.nk[k]++;
							MK[k]++;
							MKW[k][w]++;
							wIdx++;
						}
					}
					assert wIdx == corpus.numTokens(d, s);
				}
				if (Parameter.doOneTable) {
					for (k = 0; k < Parameter.numTopics; k++) {
						if (seg.nk[k] > 0) {
							seg.tk[k] = 1;
							seg.T++;
							td[d]++;
							tdk[d][k]++;
						}
					}
				} else {
					for (k = 0; k < Parameter.numTopics; k++) {
						seg.tk[k] = seg.nk[k];
						seg.T += seg.nk[k];
						td[d] += seg.nk[k];
						tdk[d][k] += seg.nk[k];
					}
				}
			}
			checkDoc(d, corpus);
			checkDocSegList(d);
		}
		checkBagOfWord(corpus);
	}

	/***********************************************************************
	 * Initialize segmentation. For each doc, 
	 * code = 0: put all paragraphs/sentences in one segment. 
	 * code = 1: put each paragraph in a segment.
	 * code = 2: do true segmentation
	 * 
	 * @param code
	 **********************************************************************/
	private static void initSeg(Corpus corpus, int code) {
		if (code == 0) {
			initOneSeg(corpus);
		} else if (code == 1) {
			initAllSeg(corpus);
		} else if (code == 2) {
			initTrueSeg(corpus);
		}
	}

	private static int initOneSeg(Corpus corpus) {
		for (int d = 0; d < corpus.numDocs(); d++) {
			rhos[d][corpus.numSents(d) - 1] = 1;
			docSegsMap.get(d).add(new Segment(0, corpus.numSents(d) - 1, d));
			c1[d] = 1;
			c0[d] = corpus.numSents(d) - 1;
		}
		return corpus.numDocs();
	}

	private static int initAllSeg(Corpus corpus) {
		ArrayList<Segment> docSegList;
		for (int d = 0; d < corpus.numDocs(); d++) {
			docSegList = docSegsMap.get(d);
			assert docSegList.isEmpty();
			for (int s = 0; s < corpus.numSents(d); s++) {
				rhos[d][s] = 1;
				docSegList.add(new Segment(s, s, d));
			}
			assert docSegList.size() == corpus.numSents(d);
			c1[d] = corpus.numSents(d);
			c0[d] = 0;
		}
		return corpus.numSents();
	}

	private static int initTrueSeg(Corpus corpus) {
		int spanLength, start, end, numSents, goldSegs[];
		ArrayList<Segment> docSegList;
		for (int d = 0; d < corpus.numDocs(); d++) {
			docSegList = docSegsMap.get(d);
			assert docSegList.isEmpty();
			numSents = corpus.numSents(d);
			goldSegs = corpus.getGoldSeg(d);
			start = 0;
			while (start < numSents) {
				for (spanLength = 1; start + spanLength < numSents
						&& goldSegs[start + spanLength] == goldSegs[start]; 
						spanLength++) {}
				end = start + spanLength - 1;
				docSegList.add(new Segment(start, end, d));
				rhos[d][end] = 1;
				c1[d]++;
				start += spanLength;
			}
			c0[d] = numSents - c1[d];
		}
		return corpus.numGoldSegs();
	}
}
