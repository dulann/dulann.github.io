import java.io.*;
import java.util.ArrayList;

/**
 * 
 * @author Lan Du
 */
public class Vocabulary {
	private File file;
	private ArrayList<String> types;

	/**
	 * Create an empty vocabulary.
	 */
	public Vocabulary() {
		types = new ArrayList<String>();
	}

	/**
	 * Create a vocabulary from a given file.
	 * 
	 * @param file
	 */
	public Vocabulary(File file) {
		this();
		this.file = file;
		this.read(file);
	}

	/**
	 * Return the size of the vocabulary.
	 * 
	 * @return 
	 */
	public int size() {
		return types.size();
	}

	/**
	 * Return the type index in vocabulary
	 * 
	 * @param type
	 *            token type
	 * @return
	 */
	public int getIndex(String type) {
		return types.indexOf(type);
	}

	/**
	 * Return the type string.
	 * 
	 * @param index
	 *            the type index
	 * @return
	 */
	public String getType(int index) {
		return types.get(index);
	}

	/**
	 * Read vocabulary from a given file, in which each line has either one of:
	 * the following format: "int,String" or "String".
	 * 
	 * @param vocFile
	 *            the file from which the vocabulary is loaded.
	 */
	public void read(File vocFile) {
		try {
			InputStreamReader isr = new InputStreamReader(new FileInputStream(
					vocFile), "UTF-8");
			BufferedReader br = new BufferedReader(isr);
			String line;
			while ((line = br.readLine()) != null) {
				String[] strs = line.split(",");
				if (strs.length == 2) {
					types.add(strs[1]);
					assert types.indexOf(strs[1]) == Integer.parseInt(strs[0]);
				} else if (strs.length == 1)
					types.add(strs[0]);
				else {
					br.close();
					throw new RuntimeException(
							"Illegal format in vocabulary file!!!");
				}
			}
			br.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	/**
	 * Write vocabulary into a file with the following format "int,String", in
	 * which the former is word index, the later is the word type string.
	 * 
	 * @param dir
	 *            the output file where to write the vocabulary
	 * @throws IOException
	 */
	public void write(String dir) {
		File tmpFile = new File(dir);
		if(!tmpFile.exists())
			tmpFile.mkdirs();
		String out = dir + File.separator + file.getName();
		try {
			OutputStreamWriter osw = new OutputStreamWriter(
					new FileOutputStream(out), "UTF-8");
			BufferedWriter bwriter = new BufferedWriter(osw);
			for (int i = 0; i < types.size(); i++) {
				bwriter.write(i + "," + types.get(i));
				bwriter.newLine();
			}
			bwriter.flush();
			bwriter.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
}
