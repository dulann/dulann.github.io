import java.util.*;
/**
 * 
 * @author Du Lan
 *
 */
public final class MarginalDecoder {
	
	public static int kernelRadius;
	public static Corpus corpus;
	
	public static void decode(double[][] marginal, int[] numSegs, int[][] hypSentSegs) {
		int d, s, n;
		assert marginal.length == hypSentSegs.length;
		assert corpus.numDocs() == marginal.length;
		int[][] hypos = new int[marginal.length][];
		for(d = 0; d < corpus.numDocs(); d++) {
			assert marginal[d].length == hypSentSegs[d].length;
			assert marginal[d][marginal[d].length-1] == 1.0;
			hypos[d] = new int[marginal[d].length];
			Arrays.fill(hypos[d], 0);
			assert hypos[d].length == corpus.numSents(d);
		}
		
		if(kernelRadius > 0) {
			System.out.println("Scores with Gaussian Kernel smoothing");
			double[] gaussianKernel = makeGaussianKernel(kernelRadius);
			System.out.println("Gaussian Kernel: "+Arrays.toString(gaussianKernel));
			marginal = convolveAndTranspose(marginal, gaussianKernel);
		} 
		Map<Integer, Double> treeMap = new TreeMap<Integer, Double>();
		for(d = 0; d < corpus.numDocs(); d++) {
			int docSegCount = numSegs[d] - 1;
			int numSents = corpus.numSents(d);
			hypos[d][numSents-1] = 1;
			if(docSegCount > 0) {
				treeMap.clear();
				for (s = 0; s < numSents-1; s++) {
					if (marginal[d][s] > 0)
						treeMap.put(new Integer(s), new Double(marginal[d][s]));
				}
				assert s == hypos[d].length-1;
				hypos[d][s] = 1;
				//put boundaries
				treeMap = sortByValueDecending(treeMap);
				n = 0;
				for(Integer key : treeMap.keySet()) {
					hypos[d][key.intValue()] = 1;
					n++;
					if(n == docSegCount)
						break;
				}
				if(treeMap.size() < docSegCount) {
					System.out.println("d = "+d+", #trueSegs = "+numSegs[d]
							+", #hypoSegs = "+(treeMap.size()+1));
				}
			}
			//
			int segIdx = 0;
			for(s = 0; s < hypos[d].length; s++) {
				hypSentSegs[d][s] = segIdx;
				if(hypos[d][s] ==  1)
					segIdx++;
			}
		}
		hypos = null;
	}
	
	private static double[][] convolveAndTranspose(double[][] in, double[] kernel) {
		double[][] cookedMarginal = new double[in.length][];
		for(int d = 0; d < in.length; d++) 
			cookedMarginal[d] = convolveAndTranspose(Arrays.copyOf(in[d], in[d].length-1), kernel);
		return cookedMarginal;
	}

	private static double[] convolveAndTranspose(double[] in, double[] kernel) {
		double[] cooked = new double[in.length];
		assert kernel.length % 2 == 1;
		int cols2 = (kernel.length - 1) / 2;
		int size = in.length;
		for (int i = 0; i < size; i++) {
			cooked[i] = 0.0;
			double norm = 0.0;
			for (int col = -cols2; col <= cols2; col++) {
				double f = kernel[cols2 + col];
				int ix = i + col;
				if (ix < 0) {
					cooked[i] += 0.0;
				} else if (ix >= size) {
					cooked[i] += 0.0;
				} else {
					norm += f;
					cooked[i] += f * in[ix];
				}
			}
			cooked[i] /= norm;
		}
		return cooked;
	}
	
	/**
     * Produce a 1-dimensional Gaussian convolution kernel
     * 
     * @author mpurver
     * @param n produces a kernel of length 2n+1
     * @return the kernel array
     */
	private static double[] makeGaussianKernel(int n) {
		double[] h = new double[2 * n + 1];
		double sigma = n / 5.0; // 5.0
		double sigmaTwo = 2.0 * sigma * sigma;
		double norm = Math.sqrt(2 * Math.PI) * sigma;
		double sum = 0.0;

		for (int i = 0; i < h.length; i++) {
			double x = i - n;
			h[i] = Math.exp(-(x * x) / sigmaTwo) / norm;
			sum += h[i];
		}
		for (int i = 0; i < h.length; i++) {
			h[i] = h[i] / sum;
		}
		return h;
	}
	
	public static <K, V extends Comparable<? super V>> Map<K, V> sortByValueDecending(
			Map<K, V> map)
	{
		List<Map.Entry<K, V>> list = new LinkedList<Map.Entry<K, V>>(
				map.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<K, V>>() {
			public int compare(Map.Entry<K, V> o1, Map.Entry<K, V> o2)
			{
				int compare = (o1.getValue()).compareTo(o2.getValue());
				return -compare;
			}
		});

		Map<K, V> result = new LinkedHashMap<K, V>();
		for (Map.Entry<K, V> entry : list) {
			result.put(entry.getKey(), entry.getValue());
		}
		return result;
	}
}
