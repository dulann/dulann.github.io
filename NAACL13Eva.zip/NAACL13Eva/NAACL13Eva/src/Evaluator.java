import java.io.*;
import java.util.Arrays;
import org.apache.commons.cli.*;

/**
 * 
 * @author Du Lan
 *
 */
public class Evaluator {
	public static boolean debug = false;
	private static int[][] hypSentSegs;
	private static double[][] marginal;
	
	/**
	 * Allocate memory space.
	 * 
	 * @param corpus
	 */
	private static void alloc(Corpus corpus) {
		hypSentSegs = new int[corpus.numDocs()][];
		marginal = new double[corpus.numDocs()][];
		for(int d = 0; d < corpus.numDocs(); d++) {
			hypSentSegs[d] = new int[corpus.numSents(d)];
			Arrays.fill(hypSentSegs[d], 0);
			marginal[d] = new double[corpus.numSents(d)];
			Arrays.fill(marginal[d], 0);
		}
	}
	
	/**
	 * Read "sampled_rhos.log" files
	 * 
	 * @param str
	 * @param corpus
	 */
	private static void readRhoSamples(String str, Corpus corpus) {
		try {
			File folder = new File(str);
			if(!folder.exists() || !folder.isDirectory()) {
				System.err.println(str+": not a folder");
				System.exit(1);
			}
			File[] subFolders = folder.listFiles(
					new FileFilter() {
							public boolean accept(File dir) {
									return dir.isDirectory() 
											&& !dir.isHidden();
		        }
		    });
			assert subFolders.length > 0;
			//Read sampled_rhos.log file in each subfolder
			int numMarkovChains = 0;
			for(int i = 0; i < subFolders.length; i++) {
				if(subFolders[i].isDirectory()) {
					File file = new File(subFolders[i].getPath() + File.separator + "sampled_rhos.log");
					if(file.exists()) {
						numMarkovChains ++;
						System.out.println("Read: "+file.getPath());
						BufferedReader reader = new BufferedReader(new FileReader(file));
						String line;
						int d = 0;
						while((line = reader.readLine()) != null) {
							String[] strs = line.split(",");
							assert strs.length == corpus.numSents(d);
							for(int s = 0; s < strs.length; s++)
								marginal[d][s] += Integer.parseInt(strs[s]);
							d++;
						}
						assert d == corpus.numDocs();
						reader.close();
					} else {
						System.out.println("Not exist: "+file.getName());
					}
				}
			}
			assert numMarkovChains > 0;
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		//Compute the marginal probabilities at each position.
		System.out.println("total samples: "+marginal[0][marginal[0].length - 1]);
		for(int d = 0; d < marginal.length; d++) {
			for(int s = 0; s < marginal[d].length; s++)
				marginal[d][s] /= marginal[d][marginal[d].length-1];
			assert marginal[d][marginal[d].length-1] == 1.0;
		}
	}
	
	public static void run(Corpus corpus, String resultFolder) {
		alloc(corpus);
		readRhoSamples(resultFolder, corpus);
		int[] numSegs = new int[corpus.numDocs()];
		for(int d = 0; d < corpus.numDocs(); d++)
			numSegs[d] = corpus.numGoldSegs(d);
		MarginalDecoder.corpus = corpus;
		MarginalDecoder.decode(marginal, numSegs, hypSentSegs);
		SegmentationEvaluator segEva = new SegmentationEvaluator(corpus);
		segEva.generateWordBased(hypSentSegs);
		double pk, wd, wde;
		pk = segEva.avepk(0, true);
		wd = segEva.avewd(0, true);
		wde = segEva.avewde(0, true);
		if(debug)
			segEva.printScores("word");
		System.out.printf("word:  pk = %.4f, wd = %.4f, wde = %.4f\n", pk, wd, wde);
		pk = segEva.avepk(0, false);
		wd = segEva.avewd(0, false);
		wde = segEva.avewde(0, false);
		if(debug)
			segEva.printScores("sent");
		System.out.printf("sent:  pk = %.4f, wd = %.4f, wde = %.4f\n", pk, wd, wde);
	}
	
	
	private static Options buildOption() {
		Options options = new Options();
		options.addOption(new Option("h", "print the help message"));
		options.addOption(new Option("debug", false, "turn on debugging"));
		options.addOption(new Option("c", true, "data folder that contains dataset"));
		options.addOption(new Option("d", true, "root where trained files stored"));
		options.addOption(new Option("k", true, "Kernel radius for smoothing by convolution"));
		return options;
	}

	public static void main(String[] args) throws Exception {
		
		Options options = buildOption();
		CommandLineParser parser = new GnuParser();
		HelpFormatter formatter = new HelpFormatter();
		CommandLine commands = null;
		try {
			commands = parser.parse(options, args);
		} catch (ParseException exp) {
			System.err.println("Unexpected exception:" + exp.getMessage());
			formatter.printHelp("Ordering Experiment:", options);
			System.exit(1);
		}

		if (commands.hasOption("h")) {
			formatter.printHelp("Ordering", options);
			System.exit(0);
		}
		
		if(commands.hasOption("debug"))
			Evaluator.debug = true;
		else
			Evaluator.debug = false;
		/*
		 * Input the corpus data
		 */
		Corpus corpus = null;
		String dataFolder = null;
		if(commands.hasOption("c")){
			dataFolder = commands.getOptionValue("c");
			File folder = new File(dataFolder);
			if(!folder.exists()){
				System.err.println("Data folder given does not exist!!!");
				System.exit(1);
			}
			File[] files = folder.listFiles(new FilenameFilter() {
		        public boolean accept(File dir, String name) {
		            return name.toLowerCase().endsWith(".data")
		            		|| name.toLowerCase().endsWith(".meta")
		            		|| name.toLowerCase().endsWith(".seg");
		        }
		    });
			assert files.length == 3;
			File[] dataFiles = new File[3];
			for(int i = 0; i < files.length; i++) {
				if(files[i].getName().toLowerCase().endsWith(".meta"))
					dataFiles[0] = files[i];
				if(files[i].getName().toLowerCase().endsWith(".data"))
					dataFiles[1] = files[i];
				if(files[i].getName().toLowerCase().endsWith(".seg"))
					dataFiles[2] = files[i];
			}
			corpus = new Corpus(dataFiles);
		} else {
			System.err.println("Please specifiy folder contains the " +
					"corpus with \'-c <file>\'");
			System.exit(1);
		}
		/*
		 * 
		 */
		String resultFolder = null;
		if(commands.hasOption("d")){
			resultFolder = commands.getOptionValue("d");
		} else {
			System.err.println("Please specifiy root of output files \'-d <String>\'");
			System.exit(1);
		}
		/*
		 * 
		 */
		MarginalDecoder.kernelRadius = 0;
		if(commands.hasOption("k")) {
			MarginalDecoder.kernelRadius = Integer.parseInt(commands.getOptionValue("k"));
		}
		Evaluator.run(corpus, resultFolder);
	}
}
